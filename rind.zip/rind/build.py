"""Builds dist/rind-offline.html: the whole app in one file, no network needed.
Run: python build.py"""
import re, pathlib
root = pathlib.Path(__file__).parent
h = (root / "index.html").read_text(encoding="utf-8")
css = (root / "css" / "rind.css").read_text(encoding="utf-8")
js = "\n".join((root / "js" / f).read_text(encoding="utf-8") for f in ["data.js", "rules.js", "app.js"])
link = '<link rel="stylesheet" href="css/rind.css">'
assert link in h
h = h.replace(link, "<style>\n" + css + "\n</style>")
m = re.search(r'<script src="js/data.js"></script>\s*<script src="js/rules.js"></script>\s*<script src="js/app.js"></script>', h)
assert m
h = h[:m.start()] + "<script>\n" + js + "\n</script>" + h[m.end():]
clean = h.replace("http://www.w3.org/2000/svg", "")  # an XML namespace name inside inline icons, never fetched
assert "http://" not in clean and "https://" not in clean, "the offline file must not reference the network"
out = root / "dist"; out.mkdir(exist_ok=True)
(out / "rind-offline.html").write_text(h, encoding="utf-8")
print("built", out / "rind-offline.html", len(h), "bytes")
