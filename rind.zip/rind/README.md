# Rind

**The layer that holds the rest together.**
National MedTech Hackathon 2026 · Respond track · Statement 6, *Lost Between Services*.

Every handover is a slice of Swiss cheese: each one has holes, and harm happens when the holes line up.
Rind reads a patient's whole record across services, lists what was **started and never closed**, and links every line back to the note it came from.

Built on the day (14 Nov 2026). Synthetic patient only. Not an NHS service.

## Run it

Open `index.html` in a browser. That's all: no install, no server, no internet.

In VS Code: open this folder, then right-click `index.html` → *Open with Live Server* (or just double-click the file).

```
node test/rules.test.js     # checks the engine against the planted answer key
```

## What it does

1. **Reads the notes.** One entry per line: `D12 04:30 | Role | free text`. The role tells it which service wrote the entry.
2. **Runs five checks**, each for something started and never closed:
   - drug held and not restarted
   - follow-up advised and not arranged
   - test sent with no result
   - referral with no reply
   - line or catheter with no removal
3. **Draws the journey.** Services along the bottom, handovers as slices. Green arcs are loops that closed. Red threads are loops that passed every handover and are still open.
4. **Builds one page.** Open loops first, then a short summary. Every statement has a chip that opens its source note. A field that isn't in the notes says *Not found in these notes*.
5. **Says what it did not check.** It counts the sentences its checks touched and marks the entries none of them touched.

Add the pre-filled GP entry and the open drug thread closes into an arc. Switch between two patients (ICU pneumonia; hip fracture and rehab) to see it is not tied to one story.

## Four synthetic patients

- **Margaret Stilton, 82**: the team's cross-provider pack (GP, care home, NHS 111, urgent community response, ambulance, ED, AMU). Her notes here are a reconstruction from the pack summary, to be replaced with the pack's own wording. Main demo.

- **Margaret Thompson, 82**: care home → GP → urgent community response → ambulance → ED. Her notes are the text of five source documents. This is the main demo.
- **Joan Ashby, 84**: pneumonia, intensive care, ward, then home visits.
- **Derek Bannon, 71**: hip fracture, surgery, rehab, then home visits.

The flow: find the patient, confirm who it is, then Rind reads the record. Loops can be marked as actioned and the page marked as reviewed; both go in the audit trail.

Fourteen checks now (the last four: a medicine against a recorded allergy, allergy recorded differently by two services, getting worse across services, essentials missing from the whole record). The first ten: the five above, plus medicine prescribed with no record it was given, a decision deferred and never made, something to confirm that nobody confirmed, a document the team could not see, and family to be told.

## Summary, medicines and handover

- **Problems, most important first.** Every sentence is filed under the problems it mentions (infection, heart, kidneys and so on). Problems with an open loop come first, then the most acute. Each opens to its own timeline.
- **Medicines.** Compares the home list with the latest discharge list and shows what is missing and what is new, with a full table behind it.
- **Handover by audience.** GP, community nurse, receiving ward, ED or a specialty: each sees the loops that are theirs to act on first.
- **Journey.** Every line is selectable and shows what it is, where it started and which handovers it passed.

## Messy notes

- Brand names map to the drug (Eliquis → apixaban). Common abbreviations are known (BCx, CVL, foley, TTE).
- A one-letter typo in a drug name is read as that drug ("Apixiban held" still opens the loop). The quote always shows the original spelling.
- Vague wording ("blood thinner back on") and typos can open a loop or add a *possible restart* note. They never close a loop: unclear evidence stays open for a person to confirm.
- Entries no check touched are counted and marked, so a reader knows what the page did not look at.
- Next step, not built: a language model to propose loops from free text, with these rules as the verifier and every claim tied to a quoted sentence.

## Safety position

- It can miss things. It is built so it can't be mistaken for a complete record.
- Rules only, no language model: the same notes always give the same page, and it cannot invent a sentence.
- It never says "all clear". Zero flags reads as "none found by these 5 checks".
- Known limit: it only knows the patterns it was given. Wording outside them is missed, which is why the untouched entries are shown.
- Decision support for a clinician who still has the notes in front of them.

## Privacy and offline use

- The page makes **no network requests**. There is no server, no analytics, no fonts or scripts loaded from elsewhere. Notes stay in the browser tab.
- This repository holds code and two **synthetic** patients only. Real patient notes must never be committed here or pasted into a hosted copy.
- `python build.py` writes `dist/rind-offline.html`: the whole app in one file. Copy that file to a device and open it; nothing else is needed. The hosted page has a **Download offline copy** button that saves the same thing.

## Files

| Path | What |
|---|---|
| `index.html` | the page |
| `css/rind.css` | styles, using NHS design system colours |
| `js/rules.js` | the engine: parsing, five checks, coverage, summary |
| `js/data.js` | two synthetic patients and their planted answer keys |
| `build.py` | builds the single-file offline copy |
| `js/app.js` | drawing only |
| `test/rules.test.js` | engine tests |

## Not in this build

No EPR or PACS connection, no real data, no accounts, no AI model.

## Credits

Team: Sofia Vidal, Kalvin, Yusuf, Mary Alam. Built with Claude (Anthropic). Colours from the NHS design system (service-manual.nhs.uk); no NHS logo or identity is used and this is not endorsed by the NHS.

## Plugging in a language model

The checks are rules. A language model can add suggestions through one hook, and nothing it says is shown unless it is backed by the notes.

```js
RindAI.notes()      // the open patient's entries: [{ entry: 'D1 09:30', index, service, who, text }]
RindAI.suggest([    // each item needs the text, the entry it came from, and a word-for-word quote (12+ characters)
  { text: 'Steroid dose may have been missed', entry: 'D1 15:30', quote: 'whether the first dose was given has not been confirmed' }
])                  // returns [{ text, kept }] ; items whose quote is not in the notes are dropped and counted
RindAI.clear()
```

AI lines appear in their own dashed box under the loops, labelled as AI. They never open or close a loop. With no model connected the page works exactly as before.
