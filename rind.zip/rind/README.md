# Rind

**The layer that holds the rest together.**
National MedTech Hackathon 2026 · Respond track · Statement 6, *Lost Between Services*.

Every handover is a slice of Swiss cheese: each one has holes, and harm happens when the holes line up.
Rind reads a patient's whole record across services, lists what was **started and never closed**, and links every line back to the note it came from.

Built on the day (14 Nov 2026). Synthetic patient only. Not an NHS service.

## Run it

Open `index.html` in a browser. That's all: no install, no server, no internet.

In VS Code: open this folder, then right-click `index.html` → *Open with Live Server* (or just double-click the file).

```
node test/rules.test.js     # checks the engine against the planted answer key
```

## What it does

1. **Reads the notes.** One entry per line: `D12 04:30 | Role | free text`. The role tells it which service wrote the entry.
2. **Runs five checks**, each for something started and never closed:
   - drug held and not restarted
   - follow-up advised and not arranged
   - test sent with no result
   - referral with no reply
   - line or catheter with no removal
3. **Draws the journey.** Services along the bottom, handovers as slices. Green arcs are loops that closed. Red threads are loops that passed every handover and are still open.
4. **Builds one page.** Open loops first, then a short summary. Every statement has a chip that opens its source note. A field that isn't in the notes says *Not found in these notes*.
5. **Says what it did not check.** It counts the sentences its checks touched and marks the entries none of them touched.

Add the pre-filled GP entry and the apixaban thread closes into an arc.

## Safety position

- It can miss things. It is built so it can't be mistaken for a complete record.
- Rules only, no language model: the same notes always give the same page, and it cannot invent a sentence.
- It never says "all clear". Zero flags reads as "none found by these 5 checks".
- Known limit, kept as a test: a restart written without the drug name ("blood thinner back on") is not recognised.
- Decision support for a clinician who still has the notes in front of them.

## Files

| Path | What |
|---|---|
| `index.html` | the page |
| `css/rind.css` | styles, using NHS design system colours |
| `js/rules.js` | the engine: parsing, five checks, coverage, summary |
| `js/data.js` | the synthetic patient and the planted answer key |
| `js/app.js` | drawing only |
| `test/rules.test.js` | engine tests |

## Not in this build

No EPR or PACS connection, no real data, no accounts, no AI model.

## Credits

Team: Sofia Vidal, Kalvin, Yusuf, Mary Alam. Built with Claude (Anthropic). Colours from the NHS design system (service-manual.nhs.uk); no NHS logo or identity is used and this is not endorsed by the NHS.
