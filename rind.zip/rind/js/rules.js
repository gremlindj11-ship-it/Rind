/* Rind engine. Rules only, no language model: same notes in, same page out.
   Five checks, each looking for something that was started and never closed. */
(function (root) {
  const DRUGS = ['apixaban','warfarin','rivaroxaban','edoxaban','dabigatran','bisoprolol','ramipril','amlodipine','metformin','amiodarone','digoxin','atorvastatin','clopidogrel','aspirin','levetiracetam','furosemide','insulin'];
  const STOP = /\b(held|hold|withheld|stopped|stop|suspended|omit(?:ted)?)\b/i;
  const RESTART = /\b(re-?start(?:ed)?|resum(?:e|ed)|recommenc(?:e|ed)|back on)\b/i;
  const FINDING = /\b(nodule|lesion|mass|aneurysm|polyp|incidental)\b/i;
  const FINDING_KEY = /\b(nodule|lesion|mass|aneurysm|polyp)\b/i;
  const FOLLOW = /\b(f\/u|follow[- ]?up|advise[ds]?|recommend(?:s|ed)?|suggest(?:s|ed)?)\b/i;
  const TESTS = [
    { name: 'blood cultures', re: /\b([Bb]lood cultures?|[Bb]lood cx|BCs?)\b/ },
    { name: 'sputum culture', re: /\bsputum\b/i },
    { name: 'echo', re: /\b(echo|TTE)\b/i },
    { name: 'urine culture', re: /\b(MSU|urine culture)\b/i },
    { name: 'histology', re: /\b(histology|cytology)\b/i }
  ];
  const SENT = /\b(sent|awaited|pending|requested|chase)\b/i;
  const RESULT = /\b(no growth|grew|negative|positive|resulted|shows|showed|reported|LVEF)\b|:/i;
  const SPECIALTIES = [
    { name: 'cardiology', re: /\bcardio(?:logy)?\b/i },
    { name: 'renal', re: /\brenal\b/i },
    { name: 'respiratory', re: /\bresp(?:iratory)? team\b/i },
    { name: 'SALT', re: /\bSALT\b/ },
    { name: 'surgery', re: /\bsurg(?:ical|eons?)\b/i },
    { name: 'neurology', re: /\bneuro(?:logy)?\b/i }
  ];
  const REQ = /\b(refer(?:red|ral)?|opinion|d\/w|discuss(?:ed)? with|review requested)\b/i;
  const REPLY = /\b(reviewed|seen by|advice|advised|input|recommend(?:s|ed)?|suggest(?:s|ed)?)\b/i;
  const DEVICES = [
    { name: 'CVC', re: /\b(CVC|central line)\b/i },
    { name: 'art line', re: /\bart(?:erial)? line\b/i },
    { name: 'urinary catheter', re: /\b(urinary )?catheter\b/i }
  ];
  const INSERT = /\b(sited|inserted|placed)\b/i;
  const REMOVE = /\b(removed|taken out|out)\b/i;
  const EVENTS = /\b(intubated|extubated|norad started|norad off|AKI stage|fast AF|step-down|septic shock|escalate abx|medically fit|discharge letter sent|home visit 1)\b/i;
  const CHECKS = [
    'Drug held and not restarted',
    'Follow-up advised and not arranged',
    'Test sent with no result',
    'Referral with no reply',
    'Line or catheter with no removal'
  ];

  const cap = s => s[0].toUpperCase() + s.slice(1);
  const clauses = t => t.split(/[.;](?=\s|$)/).map(s => s.trim()).filter(Boolean);

  function svcOf(who, prev) {
    if (/paramedic|ambulance/i.test(who)) return 'Ambulance';
    if (/^ED\b/i.test(who)) return 'ED';
    if (/^ICU\b/i.test(who)) return 'ICU';
    if (/^Ward\b/i.test(who)) return 'Ward';
    if (/community|district|home care/i.test(who)) return 'Home care';
    if (/^GP\b/i.test(who)) return 'GP';
    return prev || 'Unknown';
  }
  const LINE = /^\s*D(\d+)\s+(\d{1,2}):(\d{2})\s*\|\s*([^|]+?)\s*\|\s*(.+)$/;
  function parse(text) {
    const out = [], bad = [];
    text.split('\n').forEach((line, n) => {
      if (!line.trim()) return;
      const m = line.match(LINE);
      if (!m) { bad.push(n + 1); return; }
      out.push({ i: out.length, day: +m[1], time: m[2].padStart(2, '0') + ':' + m[3], t: +m[1] + (+m[2] * 60 + +m[3]) / 1440,
        who: m[4], svc: svcOf(m[4], out.length ? out[out.length - 1].svc : null), text: m[5].trim() });
    });
    return { E: out, bad };
  }

  function analyse(text) {
    const { E, bad } = parse(text);
    const loops = [];
    const later = (i, pred) => E.slice(i + 1).find(pred);

    // 1 drug held, never restarted
    const lastStop = {};
    E.forEach(e => clauses(e.text).forEach(c => {
      if (!STOP.test(c)) return;
      DRUGS.forEach(d => { if (new RegExp('\\b' + d + '\\b', 'i').test(c)) lastStop[d] = { e, c }; });
    }));
    Object.entries(lastStop).forEach(([d, { e, c }]) => {
      const dre = new RegExp('\\b' + d + '\\b', 'i');
      const re = later(e.i, x => clauses(x.text).some(cl => dre.test(cl) && RESTART.test(cl)));
      if (re) loops.push({ key: 'drug:' + d, kind: 'drug', label: cap(d), status: 'closed', start: e.i, end: re.i, text: `${cap(d)} held D${e.day}, restarted D${re.day}`, src: [e.i, re.i] });
      else {
        const again = E.slice(e.i + 1).filter(x => dre.test(x.text));
        loops.push({ key: 'drug:' + d, kind: 'drug', label: cap(d), status: 'open', start: e.i, end: null,
          title: `${cap(d)} held D${e.day} — no restart documented`,
          detail: `"${c}"` + (again.length ? ` · listed again D${again.map(x => x.day).join(', D')} but never restarted` : ' · not mentioned again'),
          src: [e.i, ...again.map(x => x.i)] });
      }
    });

    // 2 finding with follow-up advised, never mentioned again
    const seen = {};
    E.forEach(e => clauses(e.text).forEach(c => {
      if (!(FINDING.test(c) && FOLLOW.test(c))) return;
      const k = (c.match(FINDING_KEY) || [])[1]; if (!k) return;
      const kl = k.toLowerCase(); if (seen[kl]) return; seen[kl] = true;
      const kre = new RegExp('\\b' + k + '\\b', 'i');
      const re = later(e.i, x => kre.test(x.text));
      if (re) loops.push({ key: 'finding:' + kl, kind: 'finding', label: cap(kl), status: 'closed', start: e.i, end: re.i, text: `${cap(kl)} (D${e.day}) picked up again D${re.day}`, src: [e.i, re.i] });
      else loops.push({ key: 'finding:' + kl, kind: 'finding', label: cap(kl), status: 'open', start: e.i, end: null, title: `Follow-up advised D${e.day} — never mentioned again`, detail: `"${c}"`, src: [e.i] });
    }));

    // 3 test sent, no result
    E.forEach(e => clauses(e.text).forEach(c => {
      if (!SENT.test(c)) return;
      TESTS.forEach(t => {
        if (!t.re.test(c)) return;
        const re = later(e.i, x => clauses(x.text).some(cl => t.re.test(cl) && RESULT.test(cl) && !SENT.test(cl)));
        if (re) loops.push({ key: 'pending:' + t.name, kind: 'pending', label: cap(t.name), status: 'closed', start: e.i, end: re.i, text: `${cap(t.name)} sent D${e.day}, resulted D${re.day}`, src: [e.i, re.i] });
        else loops.push({ key: 'pending:' + t.name, kind: 'pending', label: cap(t.name), status: 'open', start: e.i, end: null, title: `${cap(t.name)} sent D${e.day} — no result in the notes`, detail: `"${c}" · the result lands after the patient has moved`, src: [e.i] });
      });
    }));

    // 4 referral, no reply
    E.forEach(e => clauses(e.text).forEach(c => {
      if (!REQ.test(c)) return;
      SPECIALTIES.forEach(s => {
        if (!s.re.test(c)) return;
        const re = later(e.i, x => clauses(x.text).some(cl => s.re.test(cl) && REPLY.test(cl) && !/requested/i.test(cl)));
        if (re) loops.push({ key: 'referral:' + s.name, kind: 'referral', label: cap(s.name), status: 'closed', start: e.i, end: re.i, text: `${cap(s.name)} asked D${e.day}, replied D${re.day}`, src: [e.i, re.i] });
        else loops.push({ key: 'referral:' + s.name, kind: 'referral', label: cap(s.name), status: 'open', start: e.i, end: null, title: `${cap(s.name)} opinion requested D${e.day} — no reply documented`, detail: `"${c}"`, src: [e.i] });
      });
    }));

    // 5 device in, never out
    DEVICES.forEach(d => {
      const ins = E.find(e => clauses(e.text).some(c => d.re.test(c) && INSERT.test(c)));
      if (!ins) return;
      const out = later(ins.i, x => clauses(x.text).some(c => d.re.test(c) && REMOVE.test(c)));
      const last = E[E.length - 1];
      if (out) loops.push({ key: 'device:' + d.name, kind: 'device', label: cap(d.name), status: 'closed', start: ins.i, end: out.i, text: `${cap(d.name)} in D${ins.day}, out D${out.day}`, src: [ins.i, out.i] });
      else {
        const again = E.slice(ins.i + 1).filter(x => d.re.test(x.text));
        loops.push({ key: 'device:' + d.name, kind: 'device', label: cap(d.name), status: 'open', start: ins.i, end: null,
          title: `${cap(d.name)} sited D${ins.day} — no removal documented (day ${last.day - ins.day + 1} at last entry)`,
          detail: again.length ? `Last mentioned D${again[again.length - 1].day}: "${clauses(again[again.length - 1].text).find(c => d.re.test(c))}"` : 'Not mentioned again',
          src: [ins.i, ...again.map(x => x.i)] });
      }
    });

    // services, and the handovers each open loop has crossed
    const strip = [];
    E.forEach(e => { const l = strip[strip.length - 1]; if (l && l.svc === e.svc) { l.n++; l.i1 = e.i; } else strip.push({ svc: e.svc, n: 1, i0: e.i, i1: e.i }); });
    const path = i => { const p = [E[i].svc]; E.slice(i + 1).forEach(x => { if (x.svc !== p[p.length - 1]) p.push(x.svc); }); return p; };
    loops.forEach(l => { if (l.status === 'open') l.path = path(l.start); });
    loops.sort((a, b) => a.start - b.start);

    // coverage: which sentences did any check have something to look at
    const KNOWN = [...DRUGS.map(d => new RegExp('\\b' + d + '\\b', 'i')), ...DEVICES.map(d => d.re), ...TESTS.map(t => t.re), ...SPECIALTIES.map(x => x.re), FINDING, EVENTS, STOP, RESTART];
    let total = 0, checked = 0; const unchk = [];
    E.forEach(e => { let any = false; clauses(e.text).forEach(c => { total++; if (KNOWN.some(r => r.test(c))) { checked++; any = true; } }); if (!any) unchk.push(e.i); });

    // summary: every field is a sourced sentence, or null (shown as "not found")
    const find = re => { for (let i = E.length - 1; i >= 0; i--) { const c = clauses(E[i].text).find(c => re.test(c)); if (c) return { text: c, src: [i] }; } return null; };
    const events = []; E.forEach(e => clauses(e.text).forEach(c => { if (EVENTS.test(c)) events.push({ text: c, src: [e.i] }); }));
    const adm = E.find(e => e.svc === 'ED') || E[0];
    const summary = {
      admitted: adm ? { text: clauses(adm.text).slice(0, 5).join('. ') + '.', src: [adm.i] } : null,
      events,
      now: E.length ? { text: E[E.length - 1].text, src: [E.length - 1] } : null,
      resus: find(/\b(DNACPR|DNAR|resus|escalation|ceiling of (?:care|treatment)|ReSPECT|TEP)\b/i),
      allergies: find(/\b(NKDA|allerg\w+)\b/i),
      family: find(/\b(daughter|son|wife|husband|NOK|family)\b/i)
    };
    return { E, bad, loops, open: loops.filter(l => l.status === 'open'), closed: loops.filter(l => l.status === 'closed'),
      summary, strip, cover: { total, checked, unchk }, days: E.length ? E[E.length - 1].day - E[0].day + 1 : 0, words: text.split(/\s+/).length };
  }

  const api = { analyse, parse, LINE, CHECKS };
  if (typeof module !== 'undefined') module.exports = api; else root.Rind = api;
})(typeof window !== 'undefined' ? window : globalThis);
