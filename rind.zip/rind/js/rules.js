/* Rind engine. Rules only, no language model: same notes in, same page out.
   Five checks, each looking for something that was started and never closed. */
(function (root) {
  const DRUGS = ['prednisolone','salbutamol','ipratropium','doxycycline','hydrocortisone','apixaban','warfarin','rivaroxaban','edoxaban','dabigatran','bisoprolol','ramipril','amlodipine','metformin','amiodarone','digoxin','atorvastatin','clopidogrel','aspirin','levetiracetam','furosemide','insulin'];
  /* Messy-notes handling. Brand names map to the drug. A one-letter typo in a drug name is read as that drug.
     Class words ("blood thinner") point at a drug class. Typos and class words can OPEN a loop or add a
     "possible" note, but they never CLOSE a loop: unclear evidence stays open for a human to confirm. */
  const BRANDS = { eliquis: 'apixaban', xarelto: 'rivaroxaban', pradaxa: 'dabigatran', lixiana: 'edoxaban', glucophage: 'metformin', lanoxin: 'digoxin', plavix: 'clopidogrel', keppra: 'levetiracetam', lasix: 'furosemide' };
  const CLASSES = [
    { re: /\b(blood[- ]?thinners?|anticoag\w*|DOAC|NOAC)\b/i, drugs: ['apixaban', 'warfarin', 'rivaroxaban', 'edoxaban', 'dabigatran'] },
    { re: /\bdiabet\w* (tablets?|meds?|medication)\b/i, drugs: ['metformin'] },
    { re: /\b(BP|blood pressure) (tablets?|meds?|medication)\b/i, drugs: ['ramipril', 'amlodipine', 'bisoprolol'] },
    { re: /\bwater tablets?\b/i, drugs: ['furosemide'] },
    { re: /\bsteroids?\b/i, drugs: ['prednisolone', 'hydrocortisone'] }
  ];
  function lev(a, b) {
    const m = a.length, n = b.length; let prev = Array.from({ length: n + 1 }, (_, j) => j);
    for (let i = 1; i <= m; i++) { const cur = [i]; for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); prev = cur; }
    return prev[n];
  }
  function normalise(text) {
    return text.replace(/[A-Za-z]{5,}/g, w => {
      const l = w.toLowerCase();
      if (DRUGS.includes(l)) return w;
      if (BRANDS[l]) return BRANDS[l];
      if (l.length < 6) return w;
      for (const d of DRUGS) {
        if (d[0] !== l[0] || Math.abs(d.length - l.length) > 2) continue;
        if (lev(l, d) <= (d.length >= 9 ? 2 : 1)) return d;
      }
      return w;
    });
  }
  const STOP = /\b(held|hold|withheld|stopped|stop|suspended|omit(?:ted)?)\b/i;
  const RESTART = /\b(re-?start(?:ed)?|resum(?:e|ed)|recommenc(?:e|ed)|back on)\b/i;
  const FINDING = /\b(nodule|lesion|mass|aneurysm|polyp|incidental)\b/i;
  const FINDING_KEY = /\b(nodule|lesion|mass|aneurysm|polyp)\b/i;
  const FOLLOW = /\b(f\/u|follow[- ]?up|advise[ds]?|recommend(?:s|ed)?|suggest(?:s|ed)?)\b/i;
  const TESTS = [
    { name: 'blood cultures', re: /\b([Bb]lood cultures?|[Bb]lood cx|[Bb]ld cx|BCx|BCs?)\b/ },
    { name: 'sputum culture', re: /\bsputum\b/i },
    { name: 'echo', re: /\b(echo|TTE)\b/i },
    { name: 'urine culture', re: /\b(MSU|urine culture)\b/i },
    { name: 'histology', re: /\b(histology|cytology)\b/i }
  ];
  const SENT = /\b(sent|awaited|pending|requested|chase)\b/i;
  const RESULT = /\b(no growth|grew|negative|positive|resulted|shows|showed|reported|LVEF)\b|:/i;
  const SPECIALTIES = [
    { name: 'cardiology', re: /\bcardio(?:logy)?\b/i },
    { name: 'renal', re: /\brenal\b/i },
    { name: 'respiratory', re: /\bresp(?:iratory)? team\b/i },
    { name: 'SALT', re: /\bSALT\b/ },
    { name: 'surgery', re: /\bsurg(?:ical|eons?)\b/i },
    { name: 'neurology', re: /\bneuro(?:logy)?\b/i },
    { name: 'orthogeriatrics', re: /\bortho-?geri\w*/i }
  ];
  const REQ = /\b(refer(?:red|ral)?|opinion|d\/w|discuss(?:ed)? with|review requested)\b/i;
  const REPLY = /\b(reviewed|seen by|advice|advised|input|recommend(?:s|ed)?|suggest(?:s|ed)?)\b/i;
  const DEVICES = [
    { name: 'CVC', re: /\b(CVC|CVL|central line)\b/i },
    { name: 'art line', re: /\b(art(?:erial)? line|a-line)\b/i },
    { name: 'urinary catheter', re: /\b((urinary )?catheter|foley|IDC)\b/i },
    { name: 'wound drain', re: /\bdrain\b/i }
  ];
  const INSERT = /\b(sited|inserted|placed)\b/i;
  const REMOVE = /\b(removed|taken out|out)\b/i;
  const EVENTS = /\b(intubated|extubated|norad started|norad off|AKI stage|fast AF|step-down|septic shock|escalate abx|medically fit|discharge letter sent|home visit 1|NOF fracture|hemiarthroplasty under|transferred to rehab|post-op delirium)\b/i;
  const NEG = /\b(not|unable|unconfirmed|whether|no record)\b/i;
  const CHECKS = [
    'Drug held and not restarted',
    'Follow-up advised and not arranged',
    'Test sent with no result',
    'Referral with no reply',
    'Line or catheter with no removal',
    'Medicine prescribed with no record it was given',
    'Decision deferred and never made',
    'Something to confirm that nobody confirmed',
    'A document the team could not see',
    'Family to be told, with no record they were',
    'Medicine given or prescribed against a recorded allergy',
    'Allergy recorded differently by different services',
    'Getting worse across services: breathing rate, heart rate, NEWS2, new oxygen',
    'Essentials missing from the whole record: allergies, escalation status, next of kin'
  ];

  /* Problem-oriented summary: each sentence is filed under the problems it mentions.
     Order on screen: problems with open loops first, then this list's order (most acute first). */
  const PROBLEMS = [
    { name: 'Breathing', re: /\b(sats|SpO2|FiO2|NIV|HFNO|intubat\w*|extubat\w*|ETT|SBT|T1RF|nasal O2|SOB|PEEP|chest clear|breathless\w*|wheeze|oxygen|saturation|nebulis\w*|COPD|asthma|RR \d+|prednisolone|salbutamol|ipratropium|steroids?)\b/i },
    { name: 'Infection', re: /\b(CAP|pneumonia|sepsis|septic|abx|antibiotic\w*|co-amox|clari|tazocin|cefuroxime|temp|afebrile|CRP|WCC|cultures?|BCs?|BCx|sputum|MSU|consolidation)\b/i },
    { name: 'Heart and circulation', re: /\b(norad\w*|shock|AF|bisoprolol|ramipril|amlodipine|HTN|rate control|[Cc]ardio\w*|TTE|[Ee]cho|LVEF|murmur|HR \d+|irregular|AS)\b/ },
    { name: 'Blood thinning', re: /\b(apixaban|warfarin|rivaroxaban|edoxaban|dabigatran|anticoag\w*|blood[- ]?thinners?|enoxaparin|VTE|plts|INR)\b/i },
    { name: 'Kidneys', re: /\b(AKI|creat|RRT|renal|UO|anuric|eGFR|U&E|nephrotoxics)\b/i },
    { name: 'Confusion and dementia', re: /\b(delirium|confus\w*|dementia|CAM-ICU|4AT|GCS|sedation)\b/i },
    { name: 'Allergy', re: /\b(allerg\w*|penicillins?|urticaria)\b/i },
    { name: 'Diabetes', re: /\b(T2DM|[Dd]iabet\w*|[Mm]etformin|[Ii]nsulin|BMs?|HbA1c)\b/ },
    { name: 'Fracture, surgery and bones', re: /\b(NOF|fracture|hemiarthroplasty|wound|drain|post-op|spinal|bone health|falls?|orthogeri\w*)\b/i },
    { name: 'Lines and catheters', re: /\b(CVC|CVL|central line|art line|catheter|foley|TWOC|cannula)\b/i },
    { name: 'Incidental findings', re: /\b(nodule|lesion|incidental)\b/i },
    { name: 'Eating and swallowing', re: /\b(SALT|NG feed|dietitian|oral intake|thin fluids|eating)\b/i },
    { name: 'Treatment escalation', re: /\b(escalation (ceiling|wishes)|NIV|DNACPR|ReSPECT)\b/i },
    { name: 'Mobility and going home', re: /\b(physio|OT|mobilis\w*|frame|stairs|transfers|walking|home nursing|lives alone|home alone|discharge)\b/i },
    { name: 'Family', re: /\b(daughter|son|wife|husband|family|NOK)\b/i },
    { name: 'Records and documents', re: /\b(chart|care plan|PDF|paper copy|medication record|not transmitted)\b/i }
  ];
  /* Medicines: names and the short forms used on wards */
  const MEDS = [...['apixaban','warfarin','rivaroxaban','edoxaban','dabigatran','bisoprolol','ramipril','amlodipine','metformin','amiodarone','digoxin','atorvastatin','clopidogrel','aspirin','levetiracetam','furosemide','insulin','enoxaparin','lansoprazole','omeprazole','paracetamol','morphine','tazocin','cefuroxime','laxatives','prednisolone','salbutamol','ipratropium','doxycycline'].map(n => ({ name: n, re: new RegExp('\\b' + n + '\\b', 'i') })),
    { name: 'co-amoxiclav', re: /\bco-amox\w*/i }, { name: 'clarithromycin', re: /\bclari\w*/i }, { name: 'noradrenaline', re: /\bnorad\w*/i }];
  const HOME_LIST = /\b(home meds|PMH|meds bag)\b/i, NOW_LIST = /\b(TTO|Meds):/;
  const SERVICES_NAMED = ['Hospital A', 'GP', 'UCR', 'Care home', 'ICU', 'Ward', 'ED'];
  const cap = s => s[0].toUpperCase() + s.slice(1);
  const clauses = t => t.split(/[.;](?=\s|$)/).map(s => s.trim()).filter(Boolean);

  function svcOf(who, prev) {
    if (/paramedic|ambulance/i.test(who)) return 'Ambulance';
    if (/^ED\b/i.test(who)) return 'ED';
    if (/^ICU\b/i.test(who)) return 'ICU';
    if (/^care home/i.test(who)) return 'Care home';
    if (/^UCR/i.test(who)) return 'UCR';
    if (/^hospital a/i.test(who)) return 'Hospital A';
    if (/^(theatre|anaes)/i.test(who)) return 'Theatre';
    if (/^rehab/i.test(who)) return 'Rehab';
    if (/^Ward\b/i.test(who)) return 'Ward';
    if (/community|district|home care/i.test(who)) return 'Home care';
    if (/^GP\b/i.test(who)) return 'GP';
    return prev || 'Unknown';
  }
  const LINE = /^\s*D(\d+)\s+(\d{1,2}):(\d{2})\s*\|\s*([^|]+?)\s*\|\s*(.+)$/;
  function parse(text) {
    const out = [], bad = [];
    text.split('\n').forEach((line, n) => {
      if (!line.trim()) return;
      const m = line.match(LINE);
      if (!m) { bad.push(n + 1); return; }
      out.push({ i: out.length, day: +m[1], time: m[2].padStart(2, '0') + ':' + m[3], t: +m[1] + (+m[2] * 60 + +m[3]) / 1440,
        who: m[4], svc: svcOf(m[4], out.length ? out[out.length - 1].svc : null), text: m[5].trim() });
    });
    return { E: out, bad };
  }

  function analyse(text) {
    const { E, bad } = parse(text);
    const loops = [];
    const later = (i, pred) => E.slice(i + 1).find(pred);

    // 1 drug held, never restarted (N = text with typos and brand names normalised; quotes always use the original)
    const N = E.map(e => normalise(e.text)), cl = i => clauses(E[i].text), cn = i => clauses(N[i]);
    const lastStop = {};
    E.forEach(e => cn(e.i).forEach((c, k) => {
      if (!STOP.test(c)) return;
      DRUGS.forEach(d => { if (new RegExp('\\b' + d + '\\b', 'i').test(c)) lastStop[d] = { e, c: cl(e.i)[k] || c }; });
    }));
    Object.entries(lastStop).forEach(([d, { e, c }]) => {
      const dre = new RegExp('\\b' + d + '\\b', 'i');
      const inClass = x => CLASSES.some(k => k.drugs.includes(d) && k.re.test(x));
      const re = later(e.i, x => cl(x.i).some(c2 => dre.test(c2) && RESTART.test(c2)));
      if (re) loops.push({ key: 'drug:' + d, kind: 'drug', label: cap(d), status: 'closed', start: e.i, end: re.i, text: `${cap(d)} held D${e.day}, restarted D${re.day}`, src: [e.i, re.i] });
      else {
        const again = E.slice(e.i + 1).filter(x => dre.test(N[x.i]));
        let maybe = null;
        E.slice(e.i + 1).some(x => cn(x.i).some((c2, k) => { if ((dre.test(c2) || inClass(c2)) && RESTART.test(c2)) { maybe = { i: x.i, text: cl(x.i)[k] || c2 }; return true; } return false; }));
        loops.push({ key: 'drug:' + d, kind: 'drug', label: cap(d), status: 'open', start: e.i, end: null, maybe,
          title: `${cap(d)} held D${e.day} — no restart documented`,
          detail: `"${c}"` + (again.length ? ` · listed again D${[...new Set(again.map(x => x.day))].join(', D')} but never restarted` : ' · not mentioned again'),
          src: [e.i, ...again.map(x => x.i)] });
      }
    });

    // 2 finding with follow-up advised, never mentioned again
    const seen = {};
    E.forEach(e => clauses(e.text).forEach(c => {
      if (!(FINDING.test(c) && FOLLOW.test(c))) return;
      const k = (c.match(FINDING_KEY) || [])[1]; if (!k) return;
      const kl = k.toLowerCase(); if (seen[kl]) return; seen[kl] = true;
      const kre = new RegExp('\\b' + k + '\\b', 'i');
      const re = later(e.i, x => kre.test(x.text));
      if (re) loops.push({ key: 'finding:' + kl, kind: 'finding', label: cap(kl), status: 'closed', start: e.i, end: re.i, text: `${cap(kl)} (D${e.day}) picked up again D${re.day}`, src: [e.i, re.i] });
      else loops.push({ key: 'finding:' + kl, kind: 'finding', label: cap(kl), status: 'open', start: e.i, end: null, title: `Follow-up advised D${e.day} — never mentioned again`, detail: `"${c}"`, src: [e.i] });
    }));

    // 3 test sent, no result
    E.forEach(e => clauses(e.text).forEach(c => {
      if (!SENT.test(c) || /\bdeferred\b/i.test(c)) return;
      TESTS.forEach(t => {
        if (!t.re.test(c)) return;
        const re = later(e.i, x => clauses(x.text).some(cl => t.re.test(cl) && RESULT.test(cl) && !SENT.test(cl)));
        if (re) loops.push({ key: 'pending:' + t.name, kind: 'pending', label: cap(t.name), status: 'closed', start: e.i, end: re.i, text: `${cap(t.name)} sent D${e.day}, resulted D${re.day}`, src: [e.i, re.i] });
        else loops.push({ key: 'pending:' + t.name, kind: 'pending', label: cap(t.name), status: 'open', start: e.i, end: null, title: `${cap(t.name)} sent D${e.day} — no result in the notes`, detail: `"${c}" · the result lands after the patient has moved`, src: [e.i] });
      });
    }));

    // 4 referral, no reply
    E.forEach(e => clauses(e.text).forEach(c => {
      if (!REQ.test(c)) return;
      SPECIALTIES.forEach(s => {
        if (!s.re.test(c)) return;
        const re = later(e.i, x => clauses(x.text).some(cl => s.re.test(cl) && REPLY.test(cl) && !/requested/i.test(cl)));
        if (re) loops.push({ key: 'referral:' + s.name, kind: 'referral', label: cap(s.name), status: 'closed', start: e.i, end: re.i, text: `${cap(s.name)} asked D${e.day}, replied D${re.day}`, src: [e.i, re.i] });
        else loops.push({ key: 'referral:' + s.name, kind: 'referral', label: cap(s.name), status: 'open', start: e.i, end: null, title: `${cap(s.name)} opinion requested D${e.day} — no reply documented`, detail: `"${c}"`, src: [e.i] });
      });
    }));

    // 5 device in, never out
    DEVICES.forEach(d => {
      const ins = E.find(e => clauses(e.text).some(c => d.re.test(c) && INSERT.test(c)));
      if (!ins) return;
      const out = later(ins.i, x => clauses(x.text).some(c => d.re.test(c) && REMOVE.test(c)));
      const last = E[E.length - 1];
      if (out) loops.push({ key: 'device:' + d.name, kind: 'device', label: cap(d.name), status: 'closed', start: ins.i, end: out.i, text: `${cap(d.name)} in D${ins.day}, out D${out.day}`, src: [ins.i, out.i] });
      else {
        const again = E.slice(ins.i + 1).filter(x => d.re.test(x.text));
        loops.push({ key: 'device:' + d.name, kind: 'device', label: cap(d.name), status: 'open', start: ins.i, end: null,
          title: `${cap(d.name)} sited D${ins.day} — no removal documented (day ${last.day - ins.day + 1} at last entry)`,
          detail: again.length ? `Last mentioned D${again[again.length - 1].day}: "${clauses(again[again.length - 1].text).find(c => d.re.test(c))}"` : 'Not mentioned again',
          src: [ins.i, ...again.map(x => x.i)] });
      }
    });

    // 6 prescribed, no record it was given
    const rx = {};
    E.forEach(e => cn(e.i).forEach((c, k) => {
      if (!/\bprescribed\b/i.test(c) || NEG.test(c)) return;
      DRUGS.forEach(d => { if (!rx[d] && new RegExp('\\b' + d + '\\b', 'i').test(c)) rx[d] = { e, c: cl(e.i)[k] || c }; });
    }));
    Object.entries(rx).forEach(([d, { e, c }]) => {
      const dre = new RegExp('\\b' + d + '\\b', 'i'), cls = x => CLASSES.some(k => k.drugs.includes(d) && k.re.test(x));
      const given = later(e.i, x => cn(x.i).some(c2 => dre.test(c2) && /\b(given|administered|taken)\b/i.test(c2) && !NEG.test(c2)));
      if (given) loops.push({ key: 'rx:' + d, kind: 'rx', label: cap(d), status: 'closed', start: e.i, end: given.i, text: `${cap(d)} prescribed ${e.time}, given ${given.time}`, src: [e.i, given.i] });
      else {
        const doubts = E.slice(e.i + 1).filter(x => cn(x.i).some(c2 => (dre.test(c2) || cls(c2)) && NEG.test(c2)));
        loops.push({ key: 'rx:' + d, kind: 'rx', label: cap(d), status: 'open', start: e.i, end: null, maybe: null,
          title: `${cap(d)} prescribed ${e.time} — no record it was given`,
          detail: `"${c}"` + (doubts.length ? ` · ${doubts.length} later note${doubts.length === 1 ? ' says' : 's say'} this could not be confirmed` : ' · not mentioned again'),
          src: [e.i, ...doubts.map(x => x.i)] });
      }
    });

    // 7 decision deferred, never made
    const deferred = {};
    E.forEach(e => cl(e.i).forEach(c => {
      const m = c.match(/\b([A-Za-z-]+?)s?\s+deferred\b/i); if (!m) return;
      const topic = m[1].toLowerCase(); if (deferred[topic]) return; deferred[topic] = true;
      const tre = new RegExp('\\b' + topic, 'i');
      const made = later(e.i, x => cl(x.i).some(c2 => tre.test(c2) && /\b(prescribed|started|given|commenced)\b/i.test(c2) && !NEG.test(c2)));
      if (made) loops.push({ key: 'decision:' + topic, kind: 'decision', label: cap(topic), status: 'closed', start: e.i, end: made.i, text: `${cap(topic)} deferred ${e.time}, decided ${made.time}`, src: [e.i, made.i] });
      else {
        const again = E.slice(e.i + 1).filter(x => tre.test(x.text));
        loops.push({ key: 'decision:' + topic, kind: 'decision', label: cap(topic), status: 'open', start: e.i, end: null, maybe: null,
          title: `${cap(topic)} decision deferred ${e.time} — still not made`,
          detail: `"${c}"` + (again.length ? ` · raised again ${again.map(x => x.time).join(', ')}, still not decided` : ''),
          src: [e.i, ...again.map(x => x.i)] });
      }
    }));

    // 8 something to confirm that nobody confirmed
    E.forEach(e => cl(e.i).forEach(c => {
      const m = c.match(/\b(confirm|check|verify|clarify)\s+(?:current |exact |the )?([^.,;]{3,50}?)\s+(with|before)\s+([^.,;]{2,40})/i);
      if (!m || NEG.test(c.slice(0, m.index))) return;
      const obj = m[2].toLowerCase(), words = obj.split(/\s+/).filter(w => w.length > 4);
      const done = later(e.i, x => cl(x.i).some(c2 => /\b(confirmed|verified|clarified|discussed)\b/i.test(c2) && !NEG.test(c2) && words.some(w => c2.toLowerCase().includes(w))));
      if (done) loops.push({ key: 'confirm:' + obj, kind: 'confirm', label: cap(obj), status: 'closed', start: e.i, end: done.i, text: `${cap(obj)} confirmed ${done.time}`, src: [e.i, done.i] });
      else { const name = /reaction/.test(obj) && /penicillin/i.test(e.text) ? 'Penicillin allergy, ' + obj : cap(obj);
        loops.push({ key: 'confirm:' + obj, kind: 'confirm', label: name.split(',')[0], status: 'open', start: e.i, end: null, maybe: null,
        title: `${name} — to ${m[1].toLowerCase()} ${m[3].toLowerCase()} ${m[4].split(/ before | so | to /)[0]}, no record it was done`, detail: `"${c}"`, src: [e.i] }); }
    }));

    // 9 a document the team could not see
    const docs = {};
    E.forEach(e => cl(e.i).forEach(c => {
      if (!/\b(not attached|not directly viewable|not located|not transmitted)\b/i.test(c)) return;
      const type = /\bchart\b/i.test(c) ? 'observation chart' : /\b(plan|copy|PDF)\b/i.test(c) ? 'care plan' : 'document';
      (docs[type] = docs[type] || []).push({ e, c });
    }));
    Object.entries(docs).forEach(([type, hits]) => {
      const first = hits[0], src = hits.map(h => h.e.i), who = [...new Set(hits.map(h => h.e.svc))];
      const named = SERVICES_NAMED.find(s => hits.some(h => new RegExp('\\b' + s + '\\b', 'i').test(h.c)) && E.some(x => x.svc === s && !src.includes(x.i)));
      if (named) { const held = E.find(x => x.svc === named); loops.push({ key: 'doc:' + type, kind: 'doc', label: cap(type), status: 'closed', found: true, start: first.e.i, end: hits[hits.length - 1].e.i,
        text: `${cap(type)} could not be seen by ${who.join(', ')}. It is in this record, from ${named}`, src: [...src, held.i] }); }
      else loops.push({ key: 'doc:' + type, kind: 'doc', label: cap(type), status: 'open', start: first.e.i, end: null, maybe: null,
        title: `${cap(type)} not available — not in this record either`, detail: `"${first.c}"`, src });
    });

    // 10 family to be told
    E.forEach(e => cl(e.i).forEach(c => {
      if (!/\b(daughter|son|wife|husband|family|NOK)\b[^.]*\bto be (updated|informed|told|called)\b/i.test(c)) return;
      const told = later(e.i, x => cl(x.i).some(c2 => /\b(daughter|son|wife|husband|family|NOK)\b/i.test(c2) && /\b(informed|updated|told|aware|phoned)\b/i.test(c2) && !/to be/i.test(c2)));
      if (told) loops.push({ key: 'family', kind: 'family', label: 'Family', status: 'closed', start: e.i, end: told.i, text: `Family to be told ${e.time}, told ${told.time}`, src: [e.i, told.i] });
      else loops.push({ key: 'family', kind: 'family', label: 'Family', status: 'open', start: e.i, end: null, maybe: null, title: `Family to be told ${e.time} — no record they were`, detail: `"${c}"`, src: [e.i] });
    }));

    // 11. a medicine given or prescribed that the allergy record rules out
    const PEN = /\b(amoxicillin|co-?amoxiclav|augmentin|flucloxacillin|tazocin|piperacillin|benzylpenicillin|phenoxymethylpenicillin|penicillin v|pivmecillinam)\b/i;
    let penAl = null;
    E.forEach(e => clauses(e.text).forEach(c => { if (!penAl && /penicillin/i.test(c) && /allerg|avoid/i.test(c) && !/no known|NKDA/i.test(c)) penAl = { e, c }; }));
    if (penAl) E.forEach(e => clauses(e.text).forEach(c => {
      const m = c.match(PEN); if (!m) return;
      if (!/\b(given|gave|prescribed|started|commenced|administered|stat)\b/i.test(c) || /\b(not|avoid|do not|instead of|withheld|stopped|allerg)\b/i.test(c)) return;
      const d = m[1].toLowerCase(); if (loops.some(l => l.key === 'conflict:' + d)) return;
      loops.push({ key: 'conflict:' + d, kind: 'conflict', label: 'Allergy', status: 'open', start: e.i, end: null, maybe: null,
        title: `${cap(d)} ${/prescribed/i.test(c) ? 'prescribed' : 'given'} ${e.time} — penicillin allergy is on record`,
        detail: `"${c}" · the allergy was recorded as "${penAl.c}"`, src: [penAl.e.i, e.i] });
    }));
    // 12. the allergy record says different things in different places
    const nk = E.find(e => /\bNKDA\b|no known (drug )?allerg/i.test(e.text));
    const al = E.find(e => clauses(e.text).some(c => /allerg/i.test(c) && !/no known|NKDA|\?\s*allerg/i.test(c)));
    if (nk && al) loops.push({ key: 'conflict:allergy record', kind: 'conflict', label: 'Allergy', status: 'open', start: Math.min(nk.i, al.i), end: null, maybe: null,
      title: `Allergy record differs — no known allergies (${nk.svc}), an allergy (${al.svc})`, detail: 'Two services recorded different allergy status', src: [nk.i, al.i] });

    // services, and the handovers each open loop has crossed
    const strip = [];
    E.forEach(e => { const l = strip[strip.length - 1]; if (l && l.svc === e.svc) { l.n++; l.i1 = e.i; } else strip.push({ svc: e.svc, n: 1, i0: e.i, i1: e.i }); });
    const path = i => { const p = [E[i].svc]; E.slice(i + 1).forEach(x => { if (x.svc !== p[p.length - 1]) p.push(x.svc); }); return p; };
    loops.forEach(l => { if (l.status === 'open') l.path = path(l.start); });
    const RANK = ['conflict', 'rx', 'drug', 'decision', 'confirm', 'pending', 'finding', 'referral', 'device', 'doc', 'family'];
    loops.sort((a, b) => (RANK.indexOf(a.kind) - RANK.indexOf(b.kind)) || (a.start - b.start));

    // coverage: which sentences did any check have something to look at
    const KNOWN = [...CLASSES.map(k => k.re), ...DRUGS.map(d => new RegExp('\\b' + d + '\\b', 'i')), ...DEVICES.map(d => d.re), ...TESTS.map(t => t.re), ...SPECIALTIES.map(x => x.re), FINDING, EVENTS, STOP, RESTART];
    let total = 0, checked = 0; const unchk = [];
    E.forEach(e => { let any = false; cn(e.i).forEach(c => { total++; if (KNOWN.some(r => r.test(c))) { checked++; any = true; } }); if (!any) unchk.push(e.i); });

    // summary: every field is a sourced sentence, or null (shown as "not found")
    const first = re => { for (let i = 0; i < E.length; i++) { const c = clauses(E[i].text).find(c => re.test(c)); if (c) return { text: c, src: [i] }; } return null; };
    const find = re => { for (let i = E.length - 1; i >= 0; i--) { const c = clauses(E[i].text).find(c => re.test(c)); if (c) return { text: c, src: [i] }; } return null; };
    const events = []; E.forEach(e => clauses(e.text).forEach(c => { if (EVENTS.test(c)) events.push({ text: c, src: [e.i] }); }));
    const adm = E.find(e => e.svc === 'ED') || E.find(e => /\b(suspected|imp:|impression|working diagnosis)\b/i.test(e.text)) || E[0];
    const summary = {
      admitted: adm ? { text: clauses(adm.text).slice(0, adm.svc === 'ED' ? 5 : 1).join('. ') + '.', src: [adm.i] } : null,
      events,
      now: E.length ? { text: E[E.length - 1].text, src: [E.length - 1] } : null,
      resus: find(/\b(DNACPR|DNAR|resus\w*|escalation (?:ceiling|wishes|plan|status)|ceiling of (?:care|treatment)|ReSPECT|TEP)\b/i),
      allergies: find(/\b(NKDA|allerg\w+)\b/i),
      family: find(/\b(daughter|son|wife|husband|NOK|family)\b/i),
      // the person, not only the illness: who to call, when they were last told, where the patient lives
      nok: first(/\b(NOK|next of kin)\b/i) || first(/\b(daughter|son|wife|husband|partner) [A-Z][a-z]+[^.]*\b0\d{3}/i) || first(/\b(daughter|son|wife|husband|partner) [A-Z][a-z]+/),
      adjust: first(/\b(short simple sentences|explain before touching|low-stimulation|simple explanations)\b/i),
      familyTold: find(/^(?!.*\bto be\b).*\b(daughter|son|wife|husband|family|NOK)\b[^.]*\b(updated|informed|told|phoned|aware|visited|present|meeting)\b/i),
      phone: find(/\b0\d{2,4} ?\d{3,4} ?\d{3,4}\b/),
      living: first(/\b(lives alone|home alone|lives with|care home|nursing home)\b/i)
    };
    // problems, most important first
    const problems = PROBLEMS.map((p, order) => {
      const items = [];
      E.forEach(e => cl(e.i).forEach(c => { if (p.re.test(c)) items.push({ i: e.i, text: c }); }));
      return { name: p.name, order, items, loops: [] };
    }).filter(p => p.items.length);
    loops.forEach(l => {
      const probe = l.status === 'open' ? l.label + ' ' + l.title + ' ' + l.detail : l.label + ' ' + l.text;
      const byLabel = PROBLEMS.find(p => p.re.test(l.label) || p.re.test(l.label.toLowerCase())) || PROBLEMS.find(p => p.re.test(probe));
      l.problem = byLabel ? byLabel.name : null;
      const p = problems.find(x => x.name === l.problem); if (p && l.status === 'open') p.loops.push(l.key);
    });
    problems.sort((a, b) => (b.loops.length - a.loops.length) || (a.order - b.order));

    // medicines: what she came in on, what the latest list says, and the difference
    const medsIn = c => MEDS.filter(m => m.re.test(c)).map(m => m.name);
    const home = new Set(), homeSrc = new Set(); let now = null;
    E.forEach(e => cn(e.i).forEach(c => {
      if (HOME_LIST.test(c)) medsIn(c).forEach(n => { home.add(n); homeSrc.add(e.i); });
      if (NOW_LIST.test(c) && medsIn(c).length) now = { i: e.i, names: medsIn(c) };
    }));
    const allMeds = MEDS.map(m => {
      const hits = []; E.forEach(e => cn(e.i).forEach((c, k) => { if (m.re.test(c)) hits.push({ i: e.i, text: cl(e.i)[k] || c, n: c }); }));
      if (!hits.length) return null;
      let status = 'mentioned';
      hits.forEach(h => {
        const mm = h.n.match(m.re); if (!mm) return;
        const near = h.n.slice(Math.max(0, mm.index - 12), mm.index) + ' | ' + h.n.slice(mm.index + mm[0].length, mm.index + mm[0].length + 22);
        if (RESTART.test(near)) status = 'restarted';
        else if (/\b(stopped|off)\b/i.test(near)) status = 'stopped';
        else if (/\b(held|withheld|suspended|omitted)\b/i.test(near)) status = 'held';
        else if (/\b(continues?|to continue)\b/i.test(near)) status = 'continuing';
        else if (/\b(started|given|at induction)\b/i.test(near) && !NEG.test(h.n)) status = 'given';
        else if (/\bprescribed\b/i.test(h.n) && status === 'mentioned') status = 'prescribed';
      });
      return { name: m.name, status, first: hits[0].i, last: hits[hits.length - 1].i, home: home.has(m.name), now: !!(now && now.names.includes(m.name)) };
    }).filter(Boolean);
    const meds = { home: [...home], homeSrc: [...homeSrc], now, all: allMeds,
      missing: now ? [...home].filter(n => !now.names.includes(n)) : [],
      added: now ? now.names.filter(n => !home.has(n)) : [] };

    const obs = [];
    E.forEach(e => {
      const g = re => { const m = e.text.match(re); return m ? m[1] : null; };
      const o = { i: e.i, rr: g(/\bRR (?:still )?(\d+)/), spo2: g(/\bSpO2 (\d+%(?: on [^,.]+)?)/), hr: g(/\bHR (\d+)/), temp: g(/\bTemp (\d+(?:\.\d)?)/), news: g(/\bNEWS2 (\d+)/) };
      if (o.rr || o.spo2 || o.hr) obs.push(o);
    });

    // 13. getting worse across services, on the latest day of the record
    let trend = null;
    const lastDay = obs.length ? E[obs[obs.length - 1].i].day : null, today = obs.filter(o => E[o.i].day === lastDay);
    if (today.length >= 3) {
      const num = k => today.map(o => parseFloat(o[k])).filter(n => !isNaN(n)), lines = [], last = a => a[a.length - 1];
      const rrs = num('rr'), hrs = num('hr'), nws = num('news'), o2 = today.map(o => o.spo2).filter(Boolean);
      if (rrs.length >= 2 && last(rrs) - rrs[0] >= 6 && last(rrs) >= 25) lines.push('Breathing rate ' + rrs.join(' → '));
      if (hrs.length >= 2 && last(hrs) - hrs[0] >= 15 && last(hrs) >= 100) lines.push('Heart rate ' + hrs.join(' → '));
      if (nws.length >= 2 && last(nws) - nws[0] >= 3) lines.push('NEWS2 ' + nws.join(' → '));
      if (o2.length >= 2 && /air/i.test(o2[0]) && /L\/min|oxygen/i.test(last(o2))) lines.push('Oxygen ' + o2[0] + ' → ' + last(o2));
      if (lines.length) trend = { lines, src: today.map(o => o.i) };
    }

    return { E, bad, loops, problems, meds, obs, trend, open: loops.filter(l => l.status === 'open'), closed: loops.filter(l => l.status === 'closed'),
      summary, strip, cover: { total, checked, unchk }, days: E.length ? E[E.length - 1].day - E[0].day + 1 : 0, words: text.split(/\s+/).length };
  }

  const api = { analyse, parse, LINE, CHECKS };
  if (typeof module !== 'undefined') module.exports = api; else root.Rind = api;
})(typeof window !== 'undefined' ? window : globalThis);
