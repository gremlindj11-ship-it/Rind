/* Rind UI. All detection lives in rules.js; this file only draws. */
(function () {
  const { analyse, LINE, CHECKS } = window.Rind;
  const { NOTES, EXPECTED_OPEN, DEMO_ENTRY } = window.RindData;
  const $ = id => document.getElementById(id);
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const reduced = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  let notesText = NOTES, built = false, busy = false;

  /* ---------- notes pane ---------- */
  function renderNotes(R, newIdx) {
    $('noteHead').textContent = `Source notes · ${R.E.length} entries · ${R.days} days`;
    $('notes').innerHTML = R.E.map(e => `<div class="note${e.i === newIdx ? ' new' : ''}" id="n${e.i}"><span class="meta">D${e.day} ${e.time} · <b>${esc(e.svc)}</b> · ${esc(e.who)}</span><br>${esc(e.text)}</div>`).join('');
    if (built) R.cover.unchk.forEach(i => { const n = $('n' + i); if (n) n.classList.add('unchk'); });
  }
  function showNote(i) {
    if (!$('editor').hidden) toggleEdit();
    document.querySelectorAll('.note.hit').forEach(n => n.classList.remove('hit'));
    const n = $('n' + i); if (!n) return;
    n.classList.add('hit');
    const box = $('notes'); box.scrollTop = Math.max(0, n.offsetTop - box.offsetTop - 80);
    if (n.scrollIntoView) n.scrollIntoView({ block: 'nearest' });
  }

  /* ---------- journey (hero) ---------- */
  const W = 1200, L = 24, RP = 150, TY = 204;
  function layout(R) {
    const E = R.E, segs = R.strip.map(s => Object.assign({}, s));
    const tEnd = E[E.length - 1].t + 0.6;
    segs.forEach((s, k) => { s.t0 = E[s.i0].t; s.t1 = k < segs.length - 1 ? E[segs[k + 1].i0].t : tEnd; s.w = Math.max(s.t1 - s.t0, 2.6); });
    const tot = segs.reduce((a, s) => a + s.w, 0), span = W - L - RP; let x = L;
    segs.forEach(s => { s.x0 = x; s.x1 = x + span * s.w / tot; x = s.x1; });
    const X = i => { const s = segs.find(s => i >= s.i0 && i <= s.i1), t = E[i].t; return s.x0 + (s.t1 > s.t0 ? (t - s.t0) / (s.t1 - s.t0) : 0) * (s.x1 - s.x0); };
    return { segs, X, rindX: W - RP + 10 };
  }
  function drawJourney(R, show, animate) {
    const { segs, X, rindX } = layout(R), E = R.E;
    const f = n => n.toFixed(1);
    let s = '<title id="jt">Journey of one patient across services, with open and closed loops</title>';
    segs.forEach((g, k) => {
      s += `<rect class="seg${k % 2 ? ' alt' : ''}" x="${f(g.x0)}" y="${TY}" width="${f(g.x1 - g.x0 - 2)}" height="24"/>`;
      s += `<text class="segLab" x="${f((g.x0 + g.x1) / 2)}" y="${TY + 44}" text-anchor="middle">${esc(g.svc)}</text>`;
      s += `<text class="segSub" x="${f((g.x0 + g.x1) / 2)}" y="${TY + 60}" text-anchor="middle">${g.n} ${g.n === 1 ? 'entry' : 'entries'}</text>`;
    });
    E.forEach(e => { s += `<rect class="tick" x="${f(X(e.i) - 0.75)}" y="${TY + 7}" width="1.5" height="10"/>`; });
    // handover slabs (the slices)
    segs.slice(1).forEach(g => {
      s += `<rect class="slab" x="${f(g.x0 - 6)}" y="14" width="10" height="${TY - 14}" rx="3"/>`;
      s += `<text class="slabLab" x="${f(g.x0 - 1)}" y="10" text-anchor="middle">handover</text>`;
    });
    s += `<rect class="rindEdge" x="${rindX + 10}" y="14" width="5" height="${TY - 14}" rx="2"/><rect class="rindBar" x="${rindX}" y="14" width="12" height="${TY - 14}" rx="3"/>`;
    s += `<text class="rindLab" x="${rindX + 7}" y="${TY + 44}" text-anchor="middle">Rind</text>`;
    if (show) {
      const an = (cls, d) => animate && !reduced ? ` class="${cls} draw" pathLength="1" style="animation-delay:${d}ms"` : ` class="${cls}"`;
      const pop = d => animate && !reduced ? ` style="animation-delay:${d}ms" class="pop"` : '';
      // closed loops: arcs that land
      const spanSeen = {}, placed = [];
      const fits = (x, y, w) => { if (placed.some(p => Math.abs(p.x - x) < (p.w + w) / 2 + 8 && Math.abs(p.y - y) < 15)) return false; placed.push({ x, y, w }); return true; };
      const labelled = new Set([...R.closed].sort((p, q) => (X(q.end) - X(q.start)) - (X(p.end) - X(p.start))).filter(l => {
        const a = X(l.start), b = X(l.end); if (b - a < 60) return false;
        const h = Math.min(120, 16 + (b - a) * 0.2); return fits((a + b) / 2, TY - h - 6, l.label.length * 6.4);
      }));
      R.closed.forEach((l, k) => {
        const a = X(l.start), b = Math.max(X(l.end), a + 14), key = l.start + '-' + l.end;
        const dup = spanSeen[key] = (spanSeen[key] || 0) + 1;
        const h = Math.min(120, 16 + (b - a) * 0.2) + (dup - 1) * 13;
        const d = 150 + k * 90;
        s += `<g class="loopHit" tabindex="0" role="button" data-src="${l.start}" aria-label="Closed: ${esc(l.text)}"><title>Closed: ${esc(l.text)}</title>`;
        const pd = `M${f(a)} ${TY} Q${f((a + b) / 2)} ${f(TY - 2 * h)} ${f(b)} ${TY}`;
        s += `<path class="hit" d="${pd}"/><path${an('arc', d)} d="${pd}"/>`;
        s += `<circle class="startDot" cx="${f(a)}" cy="${TY}" r="3"/><circle class="startDot" cx="${f(b)}" cy="${TY}" r="3"/>`;
        if (labelled.has(l)) s += `<text${pop(d + 700)} x="${f((a + b) / 2)}" y="${f(TY - h - 6)}" text-anchor="middle"><tspan class="arcLab">${esc(l.label)}</tspan></text>`;
        s += '</g>';
      });
      // open loops: threads that pass every handover and reach the rind
      const n = R.open.length, gap = n > 1 ? Math.min(26, 96 / (n - 1)) : 0;
      R.open.forEach((l, k) => {
        const a = X(l.start), y = 34 + k * gap, d = 1100 + k * 260;
        segs.slice(1).forEach(g => { if (g.x0 > a + 8) s += `<circle class="hole" cx="${f(g.x0 - 1)}" cy="${f(y)}" r="8"/>`; });
        s += `<g class="loopHit" tabindex="0" role="button" data-open="${k}" data-src="${l.start}" aria-label="Open: ${esc(l.title)}"><title>Open: ${esc(l.title)}</title>`;
        const pd = `M${f(a)} ${TY} C${f(a)} ${f(y + 70)} ${f(a + 4)} ${f(y)} ${f(a + 46)} ${f(y)} L${rindX} ${f(y)}`;
        s += `<path class="hit" d="${pd}"/><path${an('thread', d)} d="${pd}"/>`;
        s += `<circle class="startDot" cx="${f(a)}" cy="${TY}" r="4"/>`;
        s += `<g${pop(d + 850)}><circle class="endDot" cx="${rindX}" cy="${f(y)}" r="6"/><text class="threadLab" x="${rindX + 24}" y="${f(y + 5)}">${esc(l.label)}</text></g></g>`;
      });
    }
    $('journey').innerHTML = s;
  }
  function tiles(R, show) {
    const h = R.strip.length - 1;
    const t = (cls, n, label) => `<div class="tile ${cls}"><b>${n}</b><span>${label}</span></div>`;
    $('tiles').innerHTML = t('', R.E.length, 'entries read') + t('', h, `handover${h === 1 ? '' : 's'}`) +
      (show ? t('r', R.open.length, 'open loops') + t('g', R.closed.length, 'closed loops') + t('y', R.cover.unchk.length, 'entries no check touched')
            : t('r', '–', 'open loops') + t('g', '–', 'closed loops') + t('y', '–', 'entries no check touched'));
  }

  /* ---------- the page ---------- */
  const chips = (src, E) => [...new Set(src)].map(i => `<button type="button" class="src" data-i="${i}">D${E[i].day} ${E[i].time}</button>`).join('');
  const NF = '<span class="nf">Not found in these notes</span> — check with the team';
  function renderPage(R, ms) {
    const { E, open, closed, summary: S, cover } = R;
    const f = x => x ? `${esc(x.text)} ${chips(x.src, E)}` : NF;
    const demo = (notesText.match(/\b\d{2,3}[FM]\b/) || ['patient'])[0];
    let val;
    if (notesText === NOTES) {
      const got = open.map(o => o.key), hit = EXPECTED_OPEN.filter(k => got.includes(k)).length, extra = got.filter(k => !EXPECTED_OPEN.includes(k)).length;
      val = `Self-check on this synthetic record: ${hit}/${EXPECTED_OPEN.length} planted open loops found · ${extra} false alarms · ${closed.length} closed loops left alone.`;
    } else val = 'Notes changed since the original. This page was rebuilt from the current text.';
    if (R.bad.length) val += ` Lines not in the entry format and not read: ${R.bad.join(', ')}.`;
    $('out').innerHTML = `
      <div class="pt"><b>Synthetic patient · ${esc(demo)}</b><span>read ${E.length} entries in ${ms} ms</span></div>
      <div class="box red"><h3>Open loops — ${open.length} started and never closed</h3>
        ${open.length ? open.map((o, k) => `<div class="flag" id="flag${k}"><div class="t"><span class="tagOpen">Open</span>${esc(o.title)} ${chips(o.src, E)}</div><div class="d">${esc(o.detail)}</div>
          <div class="route">${o.path.length > 1 ? `Crossed ${o.path.length - 1} handover${o.path.length > 2 ? 's' : ''} unclosed:` : 'Not yet handed over:'} ${o.path.map(p => `<span class="stop">${esc(p)}</span>`).join('<i>→</i>')}</div></div>`).join('')
          : '<div class="flag">None found by these 5 checks. That is not the same as none. The notes are still the record.</div>'}
      </div>
      <div class="row"><div class="k">Why admitted</div><div>${f(S.admitted)}</div></div>
      <div class="row"><div class="k">What happened</div><div><ul class="ev">${S.events.map(x => `<li>${f(x)}</li>`).join('') || '<li>' + NF + '</li>'}</ul></div></div>
      <div class="row"><div class="k">Latest entry</div><div>${f(S.now)}</div></div>
      <div class="row"><div class="k">Resus / escalation</div><div>${f(S.resus)}</div></div>
      <div class="row"><div class="k">Allergies</div><div>${f(S.allergies)}</div></div>
      <div class="row"><div class="k">Family</div><div>${f(S.family)}</div></div>
      <div class="box green" style="margin-top:16px"><h3>Closed loops — ${closed.length}</h3>${closed.map(c => `<div class="closedRow">${esc(c.text)} ${chips(c.src, E)}</div>`).join('')}</div>
      <div class="box grey"><h3>What this page did not check</h3>
        <div class="closedRow">It runs 5 checks and nothing else: ${CHECKS.map(c => c.toLowerCase()).join('; ')}.</div>
        <div class="closedRow">Those checks had something to look at in ${cover.checked} of ${cover.total} sentences. ${cover.unchk.length} entries were not touched by any check. They have a dashed edge in the notes and still need a human read.</div>
      </div>
      <div class="val">${val}</div>`;
    $('empty').hidden = true; $('out').hidden = false;
  }

  /* ---------- flows ---------- */
  function heroText(R, show) {
    const svc = R.strip.length;
    $('heroTitle').textContent = show
      ? (R.open.length ? `${R.open.length} open loop${R.open.length === 1 ? '' : 's'} passed every handover. Rind is where they stop.` : 'No open loops found by these 5 checks.')
      : `One patient. ${svc} services. Every handover is a slice with holes.`;
    $('heroSub').textContent = show
      ? 'Red threads were started and never closed. Green arcs were closed. Select any of them to see the note.'
      : `${R.E.length} entries over ${R.days} days. Nobody reads all of it at a handover.`;
  }
  function refresh(animate, newIdx) {
    const t0 = performance.now(); const R = analyse(notesText); const ms = (performance.now() - t0).toFixed(1);
    renderNotes(R, newIdx); heroText(R, built); drawJourney(R, built, animate); tiles(R, built);
    if (built) { renderPage(R, ms); R.cover.unchk.forEach(i => { const n = $('n' + i); if (n) n.classList.add('unchk'); }); }
    return R;
  }
  async function build() {
    if (busy) return; busy = true; $('buildBtn').disabled = true;
    try {
      if (!reduced) {
        const notes = [...document.querySelectorAll('.note')], box = $('notes');
        for (let i = 0; i < notes.length; i++) {
          notes[i].classList.add('scan'); if (i) notes[i - 1].classList.remove('scan');
          box.scrollTop = Math.max(0, notes[i].offsetTop - box.offsetTop - 120);
          $('heroSub').textContent = `Reading entry ${i + 1} of ${notes.length}…`;
          await sleep(32);
        }
        if (notes.length) notes[notes.length - 1].classList.remove('scan');
        box.scrollTop = 0;
      }
    } catch (e) { /* the animation is decoration; never let it block the result */ }
    built = true;
    try { refresh(true); } finally { busy = false; $('buildBtn').disabled = false; $('buildBtn').textContent = 'Read again'; }
  }
  function toggleEdit() {
    const ed = $('editor');
    if (ed.hidden) { $('ta').value = notesText; ed.hidden = false; $('notes').hidden = true; $('addForm').hidden = true; $('editBtn').textContent = 'Done — rebuild'; }
    else { notesText = $('ta').value.replace(/\s+$/, ''); ed.hidden = true; $('notes').hidden = false; $('addForm').hidden = false; $('editBtn').textContent = 'Edit notes'; refresh(false); }
  }

  /* ---------- events ---------- */
  document.addEventListener('click', e => {
    const b = e.target.closest('.src'); if (b) { showNote(+b.dataset.i); return; }
    const g = e.target.closest('.loopHit'); if (g) activateLoop(g);
  });
  document.addEventListener('keydown', e => {
    if ((e.key === 'Enter' || e.key === ' ') && e.target.classList && e.target.classList.contains('loopHit')) { e.preventDefault(); activateLoop(e.target); }
  });
  function activateLoop(g) {
    showNote(+g.dataset.src);
    document.querySelectorAll('.flag.on').forEach(x => x.classList.remove('on'));
    if (g.dataset.open !== undefined) { const fl = $('flag' + g.dataset.open); if (fl) { fl.classList.add('on'); if (fl.scrollIntoView) fl.scrollIntoView({ block: 'nearest' }); } }
  }
  $('buildBtn').addEventListener('click', build);
  $('editBtn').addEventListener('click', toggleEdit);
  $('resetBtn').addEventListener('click', () => { $('ta').value = NOTES; });
  $('paperBtn').addEventListener('click', () => {
    if (!built) { built = true; refresh(false); $('buildBtn').textContent = 'Read again'; }
    const on = document.body.classList.toggle('paper'); $('paperBtn').textContent = on ? 'Back to notes' : 'Downtime copy';
    if (on) { try { window.print(); } catch (e) { /* printing is blocked in some hosted frames; the on-screen copy still shows */ } }
  });
  $('addForm').addEventListener('submit', e => {
    e.preventDefault();
    const v = $('addIn').value.trim(), err = $('addErr');
    if (!LINE.test(v)) { err.textContent = 'Use the entry format: D28 09:00 | GP | what happened'; err.hidden = false; return; }
    err.hidden = true; notesText = notesText + '\n' + v;
    const R = refresh(true, analyse(notesText).E.length - 1);
    const n = $('n' + (R.E.length - 1)); if (n) { const box = $('notes'); box.scrollTop = box.scrollHeight; }
    $('addIn').value = '';
  });
  $('addIn').addEventListener('input', () => { $('addErr').hidden = true; });
  $('addIn').value = DEMO_ENTRY;
  refresh(false);
})();
