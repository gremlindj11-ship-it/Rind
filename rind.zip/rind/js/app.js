/* Rind UI. All detection lives in rules.js; this file only draws. */
(function () {
  const { analyse, LINE, CHECKS } = window.Rind;
  const PATIENTS = window.RindData.PATIENTS.filter(p => !p.hidden);
  const $ = id => document.getElementById(id);
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const cap = s => s[0].toUpperCase() + s.slice(1);
  const reduced = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  let cur = PATIENTS[0], notesText = cur.notes, built = false, busy = false, lastMs = '0', query = '', lastR = null, audience = '', jStage = null, jOpen = true, jClosed = false, doc = 'handover', asOf = 0, jSel = null, nSvc = null, nUn = false;
  const edits = {}, myNote = {};

  /* ---------- source links: a small chip; hover or focus shows the note it came from ---------- */
  const when = (i, E) => { const e = E[i], L = cur.dayLabels; if (!L) return `Day ${e.day}, ${e.time}`; return e.day === 0 ? L[0] : `${L[e.day] || 'Day ' + e.day}, ${e.time}`; };
  const whenShort = (i, E) => { const e = E[i], L = cur.dayLabels; return !L ? `Day ${e.day}` : e.day === 0 ? L[0] : e.time; };
  const dayWords = t => t ? t.replace(/\bD(\d+)\b/g, 'day $1') : t;
  const nice = R => { R.loops.forEach(l => { const dl = t => t && cur.dayLabels ? t.replace(/\bD(\d+)\b/g, (m, n) => cur.dayLabels[n] || 'day ' + n) : t; if (!cur.dayLabels) { l.title = dayWords(l.title); l.detail = dayWords(l.detail); l.text = dayWords(l.text); } else { l.title = dl(l.title); l.text = dl(l.text); } if (l.kind === 'pending' && l.title && !/\bsent\b/i.test(l.detail || '')) l.title = l.title.replace(' sent ', ' planned '); if (l.title) { const p = l.title.split(' — '); l.t1 = p[0]; l.t2 = p.slice(1).join(', '); l.title = l.t1 + (l.t2 ? ': ' + l.t2 : ''); } }); return R; };
  const mins = e => e.day * 1440 + +e.time.slice(0, 2) * 60 + +e.time.slice(3, 5);
  const dur = m => m < 60 ? `${m} min` : m < 2880 ? `${Math.floor(m / 60)} h${m % 60 ? ' ' + (m % 60) + ' min' : ''}` : `${Math.round(m / 1440)} days`;
  const age = (i, E) => { const a = E[i], b = E[E.length - 1]; return cur.dayLabels && a.day === 0 && b.day !== 0 ? 'since ' + cur.dayLabels[0] : dur(Math.max(0, mins(b) - mins(a))); };
  const epStart = E => E.find(e => !(cur.dayLabels && e.day === 0)) || E[0];
  const planOf = R => { const fd = R.closed.find(c => c.found); if (!fd) return null; const svc = R.E[fd.src[fd.src.length - 1]].svc;
    const lines = R.E.filter(e => e.svc === svc).flatMap(e => e.text.split(/[.;](?=\s|$)/).map(c => c.trim()).filter(c => /\b(target|plan|avoid|ceiling|guideline|trial)\b/i.test(c)).map(c => ({ c, i: e.i }))).slice(0, 5);
    return lines.length ? { svc, lines, why: fd.text.split('.')[0] } : null; };
  const addMin = (t, m) => { const x = +t.slice(0, 2) * 60 + +t.slice(3, 5) + m; return String(Math.floor(x / 60) % 24).padStart(2, '0') + ':' + String(x % 60).padStart(2, '0'); };
  const TPL = l => { const d = l.label, low = d.toLowerCase(), obj = (l.key.split(':')[1] || low); switch (l.kind) {
    case 'rx': return [['It was given', `${d} was given at [time], confirmed with [who].`], ['It was missed', `${d} dose was missed earlier; ${low} given now at [time].`]];
    case 'drug': return [['Restarted', `${d} restarted at [time] after review by [who].`], ['Stays held', `${d} to stay held: [reason]; review on [date].`]];
    case 'decision': return [['Decision made', `${d} decision made at [time]: [which one] started.`]];
    case 'confirm': return [['Confirmed', `${cap(obj)} confirmed with [who] at [time]: [what they said].`]];
    case 'pending': return [['Result back', `${d} result: [result].`]];
    case 'finding': return [['Follow-up arranged', `${d} follow-up arranged: [what and when].`]];
    case 'referral': return [['Reply received', `${d} advice received: [advice].`]];
    case 'device': return [['Removed', `${d} removed at [time].`], ['Stays in', `${d} to stay in: [reason]; review on [date].`]];
    case 'doc': return [['Received', `${d} received from [who] at [time].`]];
    case 'family': return [['Family told', 'Family told at [time] by [who]: [what was said].']];
    case 'dup': return [['Reviewed', `${d} second dose reviewed at [time] with [who]: [intended or not, and what was done].`]];
    case 'conflict': return [['Reviewed', 'Allergy reviewed at [time] with [who]: [what was done].']];
    default: return [['Done', '[What was done], at [time].']]; } };
  let flash = '', aiItems = [], aiAvail = false, aiState = 'idle', aiData = null, aiErr = '';
  const findQuote = (R, q) => { const n = String(q || '').replace(/\s+/g, ' ').trim().toLowerCase(); if (n.length < 8) return null; const e = R.E.find(y => y.text.replace(/\s+/g, ' ').toLowerCase().includes(n)); return e ? e.i : null; };
  const trendVals = (x, E) => { const p = (x.pts || []).filter(Boolean); if (p.length < 2) return `<b><i>${esc(String(x.a))}</i><em aria-hidden="true">→</em>${esc(String(x.b))}</b>`;
    const a = p[0], z = p[p.length - 1];
    return `<b>${p.map((q, k) => `<button type="button" class="src tv${k === p.length - 1 ? ' last' : ''}" data-i="${q.i}" aria-label="${esc(String(q.v))}, ${when(q.i, E)}, ${esc(E[q.i].svc)}">${esc(String(q.v))}</button>`).join('<em aria-hidden="true">→</em>')}</b><small>${esc(E[a.i].svc)} ${E[a.i].time} to ${esc(E[z.i].svc)} ${E[z.i].time}</small>`; };
  const AI_LOCAL = /^(localhost|127\.0\.0\.1)$/.test(location.hostname), AI_BASE = AI_LOCAL ? '' : ['http:', '', '127.0.0.1:8000'].join('/');
  function aiPanelHtml(R) {
    const btns = `<p class="aiBtns"><button type="button" class="btn" data-ai="run">${aiState === 'done' ? 'Run again' : 'Write an AI summary'}</button> <button type="button" class="btn" data-ai="test">Test the safety gate</button>${aiState === 'done' ? ' <button type="button" class="linkbtn" data-ai="clear">Clear</button>' : ''}</p>`;
    const head = `<div class="aiHead"><b>AI summary</b><span>${aiAvail ? 'server connected' : 'optional · needs the team\'s server running on this computer'}</span></div>`;
    if (aiState === 'loading') return `<div class="aiBox aiSum">${head}<p class="hint">Asking the model, then checking every claim's quote against the notes…</p></div>`;
    if (aiState === 'error') return `<div class="aiBox aiSum">${head}<p class="notice bad"><b>No AI summary.</b> ${/fetch|network|load/i.test(aiErr) ? 'The AI server is not running on this computer. In the Rind folder run <code>python -m uvicorn main:app --port 8000</code>, then press the button again' : esc(aiErr)}. Everything else on this page is from Rind's own checks and does not depend on it.</p>${btns}</div>`;
    if (aiState !== 'done' || !aiData) return `<div class="aiBox aiSum aiSlim"><div class="aiHead"><b>AI summary</b><span>optional · every claim must quote the notes word for word, or it is blocked</span></div>${btns}</div>`;
    const d = aiData, st = d.verification_stats || {}, fb = /DETERMINISTIC|FALLBACK/i.test(d.generation_mode || '');
    let dropped = 0;
    const line = (c, lead) => { if (!c || !c.verification_passed) return ''; const i = findQuote(R, c.exact_source_quote); if (i == null) { dropped++; return ''; }
      const same = String(c.claim_text || '').replace(/[.\s]+$/, '').toLowerCase() === String(c.exact_source_quote || '').replace(/[.\s]+$/, '').toLowerCase();
      return `<li>${lead && !fb ? `<b>${esc(lead)}</b> ` : ''}${esc(c.claim_text)}${same ? '' : ` <q>${esc(c.exact_source_quote)}</q>`} ${chips([i], R.E)}${c.confidence && c.confidence !== 'HIGH' ? ` <span class="aiConf">${esc(c.confidence.toLowerCase())} confidence</span>` : ''}</li>`; };
    const sec = (title, arr, lead) => { const rows = (arr || []).map(c => line(c, lead ? lead(c) : '')).join(''); return rows ? `<h4>${title}</h4><ul>${rows}</ul>` : ''; };
    const admin = { ADMINISTERED: 'given', PRESCRIBED_ONLY: 'prescribed only', WITHHELD_OR_NOT_GIVEN: 'withheld or not given', INSUFFICIENT_DATA: 'not clear' };
    const body = sec('Reason for attendance', [d.reason_for_attendance]) + sec('Allergies', d.allergies) + sec('Medicines', d.medications, c => `${c.medication_name}, ${admin[c.administration_status] || 'not clear'}:`) + sec('Key clinical information', d.key_clinical_info) + sec('What helps this person', d.reasonable_adjustments) + sec(fb ? 'Open loops the server picked out' : 'Open loops the model sees', d.open_loops);
    const q = d.quarantined_claims || [];
    return `<div class="aiBox aiSum">${head}
      <p class="aiMeta">${fb ? 'No model was used: the server had no API key or the call failed, so it fell back to plain extraction.' : `Written by <code>${esc(d.model_used || 'a language model')}</code>.`} ${st.verified_claims != null ? `${st.verified_claims} of ${st.total_claims_checked} claims backed by a word-for-word quote.` : ''}${dropped ? ` ${dropped} more dropped by Rind's own check.` : ''}</p>
      ${d.clinical_safety_halt || q.length ? `<div class="notice bad"><b>Safety gate stopped ${q.length || 'some'} claim${q.length === 1 ? '' : 's'}.</b> The quote was not in the notes, so the claim is not shown as fact.${q.map(x => `<div class="aiBlocked">Blocked: ${esc(x.blocked_claim_text || '')}</div>`).join('')}</div>` : ''}
      ${body}
      <p class="hint">${fb ? 'Plain extraction by the server, with no model used.' : 'Written by a language model, not by Rind\'s checks.'} It never opens or closes a loop.</p>${btns}</div>`;
  }
  async function aiRun(sim) {
    aiState = 'loading'; const p = $('aiPanel'); if (p) p.innerHTML = aiPanelHtml(lastR);
    try {
      const r = await fetch(AI_BASE + '/api/summarise', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ patient_id: cur.id, patient_name: cur.name, raw_notes_text: viewText(), simulate_hallucination: !!sim }) });
      if (!r.ok) throw new Error('the server answered ' + r.status);
      aiData = await r.json(); aiState = 'done'; aiAvail = true;
      aiItems = (aiData.open_loops || []).filter(c => c.verification_passed).map(c => ({ text: c.claim_text, quote: c.exact_source_quote }));
      const st = aiData.verification_stats || {};
      log(`AI summary ${sim ? '(safety gate test) ' : ''}received: ${st.verified_claims}/${st.total_claims_checked} claims verified${aiData.clinical_safety_halt ? ', safety gate stopped ' + (aiData.quarantined_claims || []).length : ''}`);
    } catch (e) { aiState = 'error'; aiErr = String(e && e.message || e); log('AI summary failed: ' + aiErr); }
    if (built) refresh(false);
  }
  const aiCheck = R => aiItems.map(x => { const q = String(x.quote || '').trim().toLowerCase(), cited = typeof x.index === 'number' ? R.E[x.index] : R.E.find(e => `D${e.day} ${e.time}` === String(x.entry || '').trim());
    const hit = q.length >= 12 ? (cited && cited.text.toLowerCase().includes(q) ? cited : R.E.find(y => y.text.toLowerCase().includes(q))) : null;
    return { text: String(x.text || '').slice(0, 300), quote: String(x.quote || '').trim(), ok: !!hit && !!x.text, i: hit ? hit.i : null }; });
  window.RindAI = {
    notes: () => lastR.E.map(e => ({ entry: `D${e.day} ${e.time}`, index: e.i, service: e.svc, who: e.who, text: e.text })),
    suggest: list => { aiItems = Array.isArray(list) ? list.slice(0, 20) : []; const out = aiCheck(lastR); log(`AI suggestions received: ${out.filter(x => x.ok).length} kept, ${out.filter(x => !x.ok).length} dropped`); if (built) refresh(false); return out.map(x => ({ text: x.text, kept: x.ok })); },
    clear: () => { aiItems = []; if (built) refresh(false); }
  };
  const mom = () => cur.moments ? cur.moments[asOf] : null;
  const isLatest = () => !cur.moments || asOf === cur.moments.length - 1;
  const viewText = () => { const m = mom(); if (!m || !m.at) return notesText; const L = notesText.split('\n'), k = L.findIndex(x => x.startsWith(m.at + ' ')); return k < 0 ? notesText : L.slice(0, k + 1).join('\n'); };
  const preText = () => cur.moments ? (mom().pre || cur.arrived || '') : (cur.prealert || '');
  const arriving = () => cur.moments ? !!mom().pre : !!cur.prealert;
  const svcList = R => { const out = []; R.strip.forEach(x => { const g = out.find(o => o.svc === x.svc); if (g) { g.n += x.n; g.i1 = x.i1; } else out.push({ svc: x.svc, n: x.n, i0: x.i0, i1: x.i1 }); }); return out; };
  const lives = (l, E) => { let c = 0, rs = 0, n = 0; [...new Set(l.src)].forEach(i => { const w = E[i].who; if (/\b(MAR|chart)\b/i.test(w)) c++; else if (/\blab\b/i.test(w)) rs++; else n++; });
    return [c ? `${c} chart entr${c === 1 ? 'y' : 'ies'}` : '', rs ? `${rs} result${rs === 1 ? '' : 's'}` : '', n ? `${n} sentence${n === 1 ? '' : 's'} in notes` : ''].filter(Boolean).join(', '); };
  function drawMoments() { const el = $('moments'); el.hidden = !cur.moments; if (!cur.moments) return;
    el.innerHTML = `<span class="jfL">Record as it stood at</span>` + cur.moments.map((m, k) => `<button type="button" class="chip" data-mo="${k}" aria-pressed="${k === asOf}">${esc(m.label)}</button>`).join(''); }
  const USER = 'ED clinician (demo sign-in)';
  const nowTime = () => new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
  const audit = [], done = {}, reviewed = {};
  const log = text => { audit.unshift({ t: nowTime(), text }); if (audit.length > 60) audit.pop(); drawAudit(); };
  function drawAudit() { const el = $('auditList'); if (el) el.innerHTML = audit.map(a => `<li><span class="day">${a.t}</span><span>${esc(a.text)}</span></li>`).join('') || '<li><span class="day"></span><span>Nothing logged yet.</span></li>'; }
  const chips = (src, E) => [...new Set(src)].map(i => `<button type="button" class="src" data-i="${i}" aria-label="Source: ${when(i, E)}, ${esc(E[i].svc)}">${when(i, E)}</button>`).join('<span class="sep" aria-hidden="true"> · </span>');
  const dayLink = (i, E) => `<button type="button" class="src day" data-i="${i}" aria-label="Source: ${when(i, E)}, ${esc(E[i].svc)}">${whenShort(i, E)}</button>`;
  const pop = document.createElement('div'); pop.id = 'pop'; pop.hidden = true; pop.setAttribute('role', 'tooltip'); document.body.appendChild(pop);
  function showPop(b) {
    const e = lastR && lastR.E[+b.dataset.i]; if (!e) return;
    pop.innerHTML = `<div class="popMeta">${when(e.i, lastR.E)} · ${esc(e.svc)} · ${esc(e.who)}</div><div>${esc(e.text)}</div><div class="popHint">Select to open in the notes</div>`;
    pop.hidden = false;
    const r = b.getBoundingClientRect(), w = Math.min(420, window.innerWidth - 24);
    pop.style.width = w + 'px';
    pop.style.left = Math.max(12, Math.min(r.left + window.scrollX, window.scrollX + window.innerWidth - w - 12)) + 'px';
    const below = r.bottom + 8 + pop.offsetHeight < window.innerHeight;
    pop.style.top = (below ? r.bottom + window.scrollY + 6 : r.top + window.scrollY - pop.offsetHeight - 6) + 'px';
  }
  const hidePop = () => { pop.hidden = true; };
  document.addEventListener('mouseover', e => { const b = e.target.closest && e.target.closest('.src'); if (b) showPop(b); });
  document.addEventListener('mouseout', e => { if (e.target.closest && e.target.closest('.src')) hidePop(); });
  document.addEventListener('focusin', e => { const b = e.target.closest && e.target.closest('.src'); if (b) showPop(b); else hidePop(); });
  window.addEventListener('scroll', hidePop, true);

  /* ---------- notes panel ---------- */
  const qWords = q => q.toLowerCase().split(/\s+/).filter(Boolean);
  const qHit = (e, W) => { const t = (e.text + ' ' + e.who + ' ' + e.svc).toLowerCase(); return W.every(w => t.includes(w)); };
  const qMark = (t, W) => W.length ? t.split(new RegExp('(' + W.map(w => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + ')', 'ig')).map((p, k) => k % 2 ? `<mark>${esc(p)}</mark>` : esc(p)).join('') : esc(t);
  function renderNotes(R, newIdx) {
    const q = query.trim(), W = qWords(q);
    const hl = t => q ? qMark(t, W) : esc(t);
    const list = R.E.filter(e => !q || qHit(e, W)).filter(e => !nSvc || e.svc === nSvc).filter(e => !nUn || R.cover.unchk.includes(e.i));
    if ($('noteF')) $('noteF').innerHTML = `<button type="button" class="chip" data-ns="" aria-pressed="${!nSvc && !nUn && !q}">All</button>` + [...new Set(R.E.map(e => e.svc))].map(x => `<button type="button" class="chip" data-ns="${esc(x)}" aria-pressed="${nSvc === x}">${esc(x)}</button>`).join('') + (built && R.cover.unchk.length ? `<button type="button" class="chip" data-nu="1" aria-pressed="${nUn}">Not touched by a check ${R.cover.unchk.length}</button>` : '');
    $('noteHead').textContent = q || nSvc || nUn ? `${list.length} of ${R.E.length} entries${q ? ` match "${q}"` : ''}${nSvc ? ' · ' + nSvc : ''}${nUn ? ' · not touched by a check' : ''}` : `Source notes · ${R.E.length} entries · ${R.days} days`;
    const firstOf = {}, dupOf = {}; R.E.forEach(e => { const k = e.text.toLowerCase().replace(/\s+/g, ' ').trim(); if (k in firstOf) dupOf[e.i] = firstOf[k]; else firstOf[k] = e.i; });
    const nDup = list.filter(e => e.i in dupOf).length;
    if (nDup && !(q || nSvc || nUn)) $('noteHead').textContent += ` · ${nDup} repeated ${nDup === 1 ? 'entry' : 'entries'} folded`;
    $('notes').innerHTML = list.map(e => `<div class="note${e.i === newIdx ? ' new' : ''}${e.i in dupOf && !q ? ' dup' : ''}" id="n${e.i}"><span class="meta">${when(e.i, R.E)} · ${esc(e.svc)} · ${hl(e.who)}</span>${e.i in dupOf && !q ? `<details><summary>Same wording as the note from ${when(dupOf[e.i], R.E)}</summary>${esc(e.text)}</details>` : hl(e.text)}</div>`).join('') || '<p class="none">No entries match.</p>';
    if (built) R.cover.unchk.forEach(i => { const n = $('n' + i); if (n) n.classList.add('unchk'); });
  }
  function setNotes(on) { $('left').hidden = !on; document.body.classList.toggle('showNotes', on); $('notesBtn').setAttribute('aria-pressed', on); $('notesLb').textContent = on ? 'Hide notes' : 'Show notes'; }
  function showNote(i) {
    hidePop(); setNotes(true);
    if (lastR && lastR.E[i]) log(`Source viewed: ${when(i, lastR.E)}, ${lastR.E[i].svc}`);
    if (!$('editor').hidden) toggleEdit();
    if (!$('n' + i)) { query = ''; $('q').value = ''; nSvc = null; nUn = false; renderNotes(lastR); }
    document.querySelectorAll('.note.hit').forEach(n => n.classList.remove('hit'));
    const n = $('n' + i); if (!n) return;
    n.classList.add('hit');
    const box = $('notes'); box.scrollTop = Math.max(0, n.offsetTop - box.offsetTop - 80);
  }
  function setView(v) {
    document.querySelectorAll('.view').forEach(x => { x.hidden = x.id !== 'v-' + v; });
    document.querySelectorAll('.nav[data-v]').forEach(b => { if (b.dataset.v === v) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current'); });
    document.body.classList.toggle('wide', v === 'journey');
    if (v === 'journey' && built) drawJourney(lastR, true, true);
    if (v !== 'home') document.body.classList.remove('noPatient');
    window.scrollTo(0, 0);
  }

  /* ---------- journey ---------- */
  const W = 1200, L = 24, RP = 150, TY = 204;
  function layout(R) {
    const E = R.E, all = R.strip.map(s => Object.assign({}, s));
    const tEnd = E[E.length - 1].t + 0.6;
    all.forEach((s, k) => { s.t0 = E[s.i0].t; s.t1 = k < all.length - 1 ? E[all[k + 1].i0].t : tEnd; s.w = Math.max(s.t1 - s.t0, 2.6); });
    const segs = jStage === null || !all[jStage] ? all : [all[jStage]];
    const tot = segs.reduce((a, s) => a + s.w, 0), span = W - L - RP; let x = L;
    segs.forEach(s => { s.x0 = x; s.x1 = x + span * s.w / tot; x = s.x1; });
    const lo = segs[0].i0, hi = segs[segs.length - 1].i1;
    const X = i => { if (i < lo) return L; if (i > hi) return segs[segs.length - 1].x1; const s = segs.find(s => i >= s.i0 && i <= s.i1), t = E[i].t; return s.x0 + (s.t1 > s.t0 ? (t - s.t0) / (s.t1 - s.t0) : 0) * (s.x1 - s.x0); };
    return { segs, X, rindX: W - RP + 10, lo, hi };
  }
  function drawJourney(R, show, animate) {
    const E = R.E, G = svcList(R), stageOf = i => G.findIndex(g => g.svc === E[i].svc);
    const rows = !show ? [] : [...(jOpen ? R.open : []), ...(jClosed ? R.closed : [])].filter(l => {
      if (jStage === null) return true;
      return [l.start, ...l.src, ...(l.status === 'closed' ? [l.end] : [])].some(i => stageOf(i) === jStage);
    });
    const mark = (idx, i, cls) => `<span class="src jm ${cls}" data-i="${i}" data-loop="${idx}"></span>`;
    let h = `<div class="jg" style="--n:${G.length}" role="table" aria-label="Where each loop started and how far it was carried">
      <div class="jh jlab" role="columnheader">Loop</div>
      ${G.map((g, k) => `<button type="button" class="jh${jStage === k ? ' on' : ''}" data-js="${k}" aria-pressed="${jStage === k}" title="Show only the loops ${esc(g.svc)} started or mentioned"><b>${esc(g.svc)}</b><span>${g.n} ${g.n === 1 ? 'entry' : 'entries'}</span></button>`).join('')}
      <div class="jh jrind" role="columnheader"><b>Rind</b><span>now</span></div>`;
    rows.forEach((l, r) => {
      const open = l.status !== 'closed', a = stageOf(l.start), b = open ? G.length : stageOf(l.end), idx = R.loops.indexOf(l);
      const t = open ? [l.t1, l.t2] : [cap(l.label), 'closed ' + when(l.end, E)];
      const acted = open && done[dk(l)];
      h += `<button type="button" class="loopHit jlab ${open ? 'open' : 'closed'}" data-loop="${idx}" style="--k:${r}"><b>${esc(t[0])}</b><span>${esc(t[1] || '')}</span></button>`;
      G.forEach((g, k) => {
        if (k < a || k > b) { h += `<div class="jc${jStage === k ? ' on' : ''}" data-loop="${idx}"></div>`; return; }
        const ids = [...new Set([l.start, ...l.src, ...(open ? [] : [l.end])])].filter(i => stageOf(i) === k).sort((x, y) => x - y);
        const line = a === b ? '' : k === a ? ' from' : k === b ? ' to' : ' thru';
        const one = !ids.length ? '' : !open && k === b ? mark(idx, l.end, 'end') : k === a ? mark(idx, l.start, 'start') : mark(idx, ids[ids.length - 1], 'again');
        h += `<div class="jc${line}${open ? '' : ' ok'}${jStage === k ? ' on' : ''}" data-loop="${idx}">${one}</div>`;
      });
      h += open ? `<div class="jc to jr" data-loop="${idx}"><span class="jopen${acted ? ' acted' : ''}">${acted ? 'Recorded' : 'Open'}</span></div>` : `<div class="jc jr" data-loop="${idx}"><span class="jdone">Closed</span></div>`;
    });
    if (show && !rows.length) h += `<div class="jnone">Nothing to show with these filters.</div>`;
    h += '</div>';
    $('journey').innerHTML = h;
    if (show) { const key = l => l.key + '|' + l.start, pick = rows.find(l => key(l) === jSel) || rows[0]; if (pick) showLoop(R.loops.indexOf(pick), R); else $('loopDetail').innerHTML = ''; }
    if ($('jf')) $('jf').innerHTML = `<span class="jfL">Show</span>
        <button type="button" class="chip" data-jk="open" aria-pressed="${jOpen && !jClosed}">Open ${R.open.length}</button>
        <button type="button" class="chip" data-jk="closed" aria-pressed="${jClosed && !jOpen}">Closed ${R.closed.length}</button>
        <button type="button" class="chip" data-jk="all" aria-pressed="${jOpen && jClosed}">All ${R.loops.length}</button>
        ${jStage !== null ? `<button type="button" class="chip" data-js="all" aria-pressed="false">${esc(G[jStage].svc)} only · show whole journey</button>` : ''}
        <span class="jkey"><i class="jm start"></i>started <i class="jm again"></i>mentioned again <i class="jm end"></i>closed</span>`;
  }

  /* ---------- one loop, in full: used on the loops page and under the journey ---------- */
  const evidence = l => { const n = new Set(l.src.map(i => lastR.E[i].text.toLowerCase().replace(/\s+/g, ' ').trim())).size; return l.maybe ? 'Unclear wording in the notes, a person needs to confirm' : n >= 3 ? `Strong, ${n} notes say the same` : n === 2 ? 'Moderate, 2 notes' : 'One note only'; };
  function loopBody(l, E) {
    if (l.status === 'closed') return `<p class="quote">${esc(l.text)}. Started and finished in the notes.</p><dl class="meta2"><dt>Source</dt><dd>${chips(l.src, E)}</dd></dl>`;
    return `<p class="quote">${esc(l.detail)}</p>
      ${l.kind === 'dup' && l.known != null ? `<p class="q"><b>The fact was already in the record.</b> It was a sentence in a note, not an entry on the drug chart, so a check that compares chart entries has nothing to compare. ${chips([l.known], E)}</p>` : ''}
      ${l.maybe ? `<p class="q"><b>Possible restart on day ${E[l.maybe.i].day}:</b> "${esc(l.maybe.text)}". The wording is unclear, so this stays open until someone confirms. ${chips([l.maybe.i], E)}</p>` : ''}
      <dl class="meta2"><dt>Passed through</dt><dd>${l.path.map(esc).join('<span class="arrow" aria-hidden="true"></span>')}</dd><dt>Evidence</dt><dd>${evidence(l)}</dd><dt>Where it lives</dt><dd>${lives(l, E)}</dd><dt>Source</dt><dd>${chips(l.src, E)}</dd></dl>`;
  }

  /* ---------- who needs to act on what ---------- */
  const CARER = { 'Home care': 'Community nurse', Ward: 'Ward team', Rehab: 'Rehab team', ICU: 'ICU team', ED: 'ED', GP: 'GP', Theatre: 'Ward team', Ambulance: 'ED', 'Care home': 'Care home', UCR: 'UCR team', 'Hospital A': 'Hospital A', AMU: 'AMU team', 'NHS 111': 'NHS 111', 'North Mersey': 'North Mersey' };
  const carer = R => CARER[R.E[R.E.length - 1].svc] || 'Receiving team';
  function owners(l, R) {
    const now = carer(R), has = s => R.strip.some(x => x.svc === s), u = a => [...new Set(a)];
    if (l.kind === 'referral') return u([l.label, 'GP']);
    if (l.kind === 'drug') return u(['GP', now]);
    if (l.kind === 'device') return u([now, 'GP']);
    if (l.kind === 'rx') return u([now, has('Care home') ? 'Care home' : 'GP']);
    if (l.kind === 'decision' || l.kind === 'confirm' || l.kind === 'family' || l.kind === 'dup' || l.kind === 'conflict') return [now];
    if (l.kind === 'doc') return u([has('Care home') ? 'Care home' : now]);
    return ['GP'];
  }
  /* recommended handovers for this patient: the team caring for them now, then anyone with a loop to act on */
  function recommended(R) {
    const now = carer(R), count = {};
    R.open.forEach(l => owners(l, R).forEach(o => { count[o] = (count[o] || 0) + 1; }));
    const names = [...new Set([now, ...Object.keys(count).sort((a, b) => count[b] - count[a])])];
    return names.map(n => {
      const ref = R.open.find(l => l.kind === 'referral' && l.label === n);
      const arriving = R.E[R.E.length - 1].svc === 'Ambulance';
      const why = n === now ? (arriving ? 'Receiving the patient next' : 'Looking after the patient now') : ref ? `Asked for an opinion on day ${R.E[ref.start].day}, no reply in the notes` : n === 'Care home' ? 'Can confirm what was given and send the chart' : 'Has follow-up to arrange';
      return { name: n, n: count[n] || 0, why };
    });
  }
  function audiences(R) { return [...new Set([...recommended(R).map(x => x.name), 'ED'])]; }
  function handoverText(R, who) {
    const E = R.E, at = i => when(i, E), S = R.summary, demo = (notesText.match(/\b\d{2,3}[FM]\b/) || ['patient'])[0];
    const mine = who === 'ED' && carer(R) !== 'ED' ? R.open : R.open.filter(l => owners(l, R).includes(who)), rest = R.open.filter(l => !mine.includes(l));
    const line = (l, k) => `${k + 1}. ${l.title} [${at(l.start)}, ${E[l.start].svc}]` + (l.maybe ? ` (possible restart ${at(l.maybe.i)}, unclear, confirm)` : '');
    const L = [`HANDOVER TO ${who.toUpperCase()} · synthetic patient ${demo}`, ''];
    const st0 = epStart(E), plan = planOf(R);
    L.push(`First seen ${at(st0.i)} (${st0.svc}), ${age(st0.i, E)} before the latest note.`, '');
    if (S.admitted) L.push('PRESENTING PROBLEM', S.admitted.text, '');
    if (R.trend) L.push(R.E[R.trend.src[0]].day === R.E[R.E.length - 1].day ? 'GETTING WORSE TODAY' : 'GOT WORSE ON ' + String(cur.dayLabels ? cur.dayLabels[R.E[R.trend.src[0]].day] : 'day ' + R.E[R.trend.src[0]].day).toUpperCase(), ...R.trend.lines.map(x => '- ' + x), '');
    if (plan) L.push(`PLAN ALREADY ON RECORD (${plan.svc}, ${at(plan.lines[0].i)})`, ...plan.lines.map(x => '- ' + x.c), '');
    L.push('MAIN PROBLEMS', ...R.problems.slice(0, 5).map(p => `- ${p.name}: ${p.items[p.items.length - 1].text}`), '');
    L.push(who === 'ED' && carer(R) !== 'ED' ? `ALL OPEN LOOPS (${mine.length})` : `FOR YOU TO ACTION (${mine.length})`);
    L.push(...(mine.length ? mine.map(line) : ['None found for you by these checks.']));
    if (rest.length) L.push('', `OPEN WITH OTHER TEAMS (${rest.length})`, ...rest.map(l => `- ${l.title} → ${owners(l, R).join(', ')}`));
    if (R.meds.now) {
      L.push('', 'MEDICINES');
      if (R.meds.missing.length) L.push(`Home medicine not on the latest list: ${R.meds.missing.join(', ')}`);
      if (R.meds.added.length) L.push(`New on the latest list: ${R.meds.added.join(', ')}`);
    }
    const nf = [['Resus / escalation status', S.resus], ['Allergies', S.allergies], ['Next of kin', S.nok], ['Family phone number', S.phone]].filter(x => !x[1]).map(x => x[0]);
    if (S.nok || S.familyTold) L.push('', 'FAMILY', ...(S.nok ? ['Next of kin: ' + S.nok.text] : []), ...(S.familyTold ? [`Last told: ${S.familyTold.text} [${at(S.familyTold.src[0])}]`] : []));
    if (nf.length) L.push('', 'NOT FOUND IN THE NOTES', ...nf.map(x => '- ' + x));
    L.push('', `${CHECKS.length} checks only, not a full summary. ${R.cover.unchk.length} of ${E.length} entries were not touched by any check.`);
    return L.join('\n');
  }
  const ST = { held: 'held', stopped: 'stopped', restarted: 'held, then restarted', continuing: 'continuing', given: 'given', prescribed: 'prescribed', mentioned: 'mentioned' };
  const DOCS = [['handover', 'Handover'], ['discharge', 'Discharge summary'], ['family', 'Call the family']];
  const nokShort = t => { const m = t.match(/\b([Dd]aughter|[Ss]on|[Ww]ife|[Hh]usband|[Pp]artner) ([A-Z][a-z]+(?: [A-Z][a-z]+)?)[^0-9]{0,8}(0\d[\d ]{8,12}\d)?/); return m ? `${m[2]}, ${m[1].toLowerCase()}${m[3] ? ' · ' + m[3] : ''}` : t; };
  const mine = () => (myNote[cur.id] || '').trim();
  function dischargeText(R) {
    const E = R.E, at = i => when(i, E), S = R.summary, v = x => x ? x.text : 'Not found in the notes';
    const src = l => `[${at(l.start)}, ${E[l.start].svc}]`, by = k => R.open.filter(l => k.includes(l.kind));
    const medLine = m => `- ${cap(m.name)}: ${R.open.some(l => l.key === 'drug:' + m.name) ? 'HELD, NOT RESTARTED' : R.open.some(l => l.key === 'rx:' + m.name) ? 'PRESCRIBED, NO RECORD IT WAS GIVEN' : ST[m.status]}`;
    const L = ['DISCHARGE SUMMARY · draft', `${cur.name} · born ${cur.dob} · NHS no ${cur.nhsNo} · synthetic patient`, ''];
    L.push('PRESENTING PROBLEM', v(S.admitted), '', 'CLINICAL SUMMARY, BY PROBLEM', ...R.problems.slice(0, 6).map(p => `- ${p.name}: ${p.items[p.items.length - 1].text}`), '');
    L.push('MEDICINES', ...(R.meds.all.length ? R.meds.all.map(medLine) : ['Not found in the notes']));
    if (R.meds.now && R.meds.missing.length) L.push(`Home medicine not on the latest list: ${R.meds.missing.join(', ')}`);
    if (R.meds.now && R.meds.added.length) L.push(`New on the latest list: ${R.meds.added.join(', ')}`);
    L.push('', 'ALLERGIES', v(S.allergies), '');
    const res = by(['pending']), fu = by(['referral', 'finding', 'drug', 'device']), other = R.open.filter(l => !res.includes(l) && !fu.includes(l));
    L.push('RESULTS STILL AWAITED', ...(res.length ? res.map(l => `- ${l.title} ${src(l)}`) : ['None found by these checks.']), '');
    L.push('ACTIONS FOR THE GP AND FOLLOW-UP', ...(fu.length ? fu.map(l => `- ${l.title} ${src(l)}`) : ['None found by these checks.']));
    if (other.length) L.push('', 'STILL OPEN AT DISCHARGE', ...other.map(l => `- ${l.title} ${src(l)}`));
    L.push('', 'ESCALATION AND RESUSCITATION', v(S.resus), '', 'FAMILY', `Next of kin: ${S.nok ? nokShort(S.nok.text) : 'Not found in the notes'}`, `Last told: ${S.familyTold ? `${S.familyTold.text} [${at(S.familyTold.src[0])}]` : 'Not found in the notes'}`);
    if (S.adjust) L.push('', 'ADJUSTMENTS', S.adjust.text);
    if (mine()) L.push('', 'ADDED BY THE CLINICIAN', mine());
    L.push('', `Draft from ${CHECKS.length} checks, not a full summary. Check against the notes before sending.`);
    return L.join('\n');
  }
  function familyText(R) {
    const E = R.E, at = i => when(i, E), S = R.summary;
    const ask = R.open.filter(l => l.kind === 'family' || /family|daughter|\bson\b|wife|husband|partner|NOK/i.test(l.title));
    const L = ['CALL THE FAMILY', '', 'WHO', S.nok ? nokShort(S.nok.text) : 'Next of kin not found in the notes', '', 'LAST TOLD', S.familyTold ? `${S.familyTold.text} [${at(S.familyTold.src[0])}]` : 'No record in the notes that the family has been told', ''];
    L.push('TO TELL THEM', S.now ? S.now.text.split(/(?<=\.)\s/).slice(0, 2).join(' ') : 'Not found in the notes', '(clinical wording from the notes: put it in plain words on the call)', '');
    L.push('TO ASK THEM', ...(ask.length ? ask.map(l => `- ${l.title}`) : ['Nothing in the open loops needs the family.']));
    if (S.adjust) L.push('', 'WHAT HELPS THIS PERSON', S.adjust.text);
    if (mine()) L.push('', 'ADDED BY THE CLINICIAN', mine());
    return L.join('\n');
  }
  const docKey = () => `${cur.id}|${doc}|${doc === 'handover' ? audience : ''}`;
  const draftFor = R => doc === 'handover' ? handoverText(R, audience) + (mine() ? '\n\nADDED BY THE CLINICIAN\n' + mine() : '') : doc === 'discharge' ? dischargeText(R) : familyText(R);
  function docStatus(draft) {
    const ed = edits[docKey()];
    $('docState').innerHTML = !ed ? 'Draft written by Rind from the notes. Edit anything before you send it.'
      : `<span class="okTag">Edited by you at ${ed.t}</span>${ed.base !== draft ? '<b class="bad">The notes have changed since you edited this.</b> ' : ''}<button type="button" class="linkbtn" id="docReset">Go back to Rind's draft</button>`;
  }
  function drawHandover(R) {
    const recs = recommended(R), list = audiences(R); if (!list.includes(audience)) audience = list[0];
    const draft = draftFor(R), ed = edits[docKey()];
    $('v-handover').innerHTML = `<h2 class="cardH">Handover and documents</h2>
      <div class="jf"><span class="jfL">Write</span>${DOCS.map(d => `<button type="button" class="chip" data-doc="${d[0]}" aria-pressed="${doc === d[0]}">${d[1]}</button>`).join('')}</div>
      ${doc === 'handover' ? `<p class="hint" style="margin:0 0 10px">Recommended for this patient, from who is caring for them now and who has a loop to act on.</p>
      <div class="recGrid" id="aud">${recs.map(x => `<button type="button" class="rec" data-a="${esc(x.name)}" aria-pressed="${x.name === audience}"><b>${esc(x.name)}</b><span class="recN">${x.n} to action</span><span class="recWhy">${esc(x.why)}</span></button>`).join('')}
        ${recs.some(x => x.name === 'ED') ? '' : `<button type="button" class="rec" data-a="ED" aria-pressed="${audience === 'ED'}"><b>ED</b><span class="recN">All ${R.open.length}</span><span class="recWhy">If the patient comes back in</span></button>`}</div>` : ''}
      <textarea id="hoText" rows="16" spellcheck="true" aria-label="${DOCS.find(d => d[0] === doc)[1]} text, editable">${esc(ed ? ed.text : draft)}</textarea>
      <p class="docState" id="docState"></p>
      <button type="button" id="copyBtn" class="btn copy">Copy text</button> <button type="button" id="pdfBtn" class="btn copy">View as a document</button> <span id="copyMsg" class="hint" role="status"></span>`;
    docStatus(draft);
    $('recs').innerHTML = recs.map(x => `<button type="button" class="nav sub" data-aud="${esc(x.name)}"><span class="lbl">${esc(x.name)}</span><span class="badge quiet">${x.n}</span></button>`).join('');
  }
  document.addEventListener('change', e => { if (e.target.id === 'idTick') $('idOpen').disabled = !e.target.checked; });
  document.addEventListener('input', e => {
    if (e.target.id === 'hoText') { const k = docKey(), draft = draftFor(lastR); if (!edits[k]) log(`${DOCS.find(d => d[0] === doc)[1]} edited by the clinician`); edits[k] = { text: e.target.value, t: nowTime(), base: edits[k] ? edits[k].base : draft }; docStatus(draft); }
    if (e.target.id === 'myNote') { if (!myNote[cur.id]) log('Clinician added a line to the summary'); myNote[cur.id] = e.target.value; drawHandover(lastR); }
  });

  /* ---------- pages ---------- */
  const NF = '<span class="nf">Not found in these notes</span>';
  const dk = l => `${cur.id}|${l.key}|${l.start}`;
  function renderPage(R) {
    const { E, open, closed, summary: S, cover, problems, meds } = R;
    const f = x => x ? `${esc(x.text)} ${chips(x.src, E)}` : NF;
    // 1 open loops
    const plan = planOf(R);
    const trendCard = R.trend ? `<div class="trend"><div class="trendH"><b>${E[R.trend.src[0]].day === E[E.length - 1].day ? 'Getting worse today' : 'Got worse on ' + (cur.dayLabels ? cur.dayLabels[E[R.trend.src[0]].day] : 'day ' + E[R.trend.src[0]].day)}</b><span>${R.trend.src.length} sets of observations, ${chips([R.trend.src[0]], E)} to ${chips([R.trend.src[R.trend.src.length - 1]], E)}</span></div>
      <div class="trendG">${R.trend.items.map(x => `<div class="${x.wide ? 'wide' : ''}"><span>${esc(x.k)}</span>${trendVals(x, E)}</div>`).join('')}</div></div>` : '';
    const planCard = plan ? `<details class="plan" open><summary><b>Treatment plan already on record</b><span>${esc(plan.svc)}, ${when(plan.lines[0].i, E)} · ${esc(plan.why)}</span></summary><ul>${plan.lines.map(x => `<li>${esc(x.c)} ${chips([x.i], E)}</li>`).join('')}</ul></details>` : '';
    const ai = aiCheck(R), kept = ai.filter(x => x.ok), drop = ai.length - kept.length;
    const aiCard = ai.length ? `<details class="aiBox" open><summary><b>Suggested by AI</b><span>${kept.length} backed by a line in the notes${drop ? ` · ${drop} dropped, no matching line` : ''}</span></summary>${kept.length ? `<ul>${kept.map(x => `<li>${esc(x.text)} <q>${esc(x.quote)}</q> ${chips([x.i], E)}</li>`).join('')}</ul>` : ''}<p class="hint">Written by a language model, not by the checks. A line is shown only if its quote is found word for word in the notes. AI lines never open or close a loop.</p></details>` : '';
    const flashCard = flash ? `<p class="notice good flash"><b>Closed by your entry.</b> ${esc(flash)}</p>` : ''; flash = '';
    $('out').innerHTML = `${flashCard}${trendCard}${planCard}<section class="loops">${open.length ? open.map((o, k) => `<details class="loop${done[dk(o)] ? ' actioned' : ''}" id="flag${k}" ${k === 0 && !done[dk(o)] ? 'open' : ''}>
        <summary><span class="dot" aria-hidden="true"></span><span class="lt"><b>${esc(o.t1)}</b>${o.t2 ? `<i>${esc(o.t2)}</i>` : ''}</span><span class="age">${age(o.ageFrom != null ? o.ageFrom : o.start, E).startsWith('since') ? age(o.ageFrom != null ? o.ageFrom : o.start, E) : 'open ' + age(o.ageFrom != null ? o.ageFrom : o.start, E)}</span>${o.problem ? `<button type="button" class="tag" data-prob="${esc(o.problem)}" title="See this problem in the summary">${esc(o.problem)}</button>` : ''}</summary>
        <div class="lb">${loopBody(o, E)}${isLatest() ? `<div class="act">${done[dk(o)] ? `<span class="okTag">Recorded in the notes at ${done[dk(o)]}</span>Still open by the checks. <button type="button" class="linkbtn" data-rec="${k}">Add another entry</button>` : `<button type="button" class="btn" data-rec="${k}">Record what was done</button>`}
          <form class="recF" data-k="${k}" hidden><div class="recTop"><label for="rec${k}">New entry for the notes</label>${TPL(o).length > 1 ? TPL(o).map((t, n) => `<button type="button" class="chip" data-tpl="${n}" aria-pressed="${n === 0}">${esc(t[0])}</button>`).join('') : ''}</div>
          <textarea id="rec${k}" rows="2" spellcheck="true">${esc(TPL(o)[0][1])}</textarea>
          <p class="hint">Fill in the parts in brackets. It goes into the notes signed ${esc(USER)}, then Rind reads the record again. The loop closes only if the entry settles it.</p>
          <button type="submit" class="btn">Add to the notes</button> <button type="button" class="linkbtn" data-reccancel="1">Cancel</button> <span class="recErr" role="alert"></span></form></div>` : `<p class="pastHint">You are viewing the record as it stood at an earlier moment. Choose Latest to record what was done.</p>`}</div></details>`).join('')
        : '<p class="notice">None found by these checks. That is not the same as none. The notes are still the record.</p>'}</section>
      ${closed.filter(c => c.found && !plan).map(c => `<p class="notice good"><b>Found in the record.</b> ${esc(c.text)}. ${chips(c.src, E)}</p>`).join('')}
      ${aiCard}
      <p class="notice"><b>${CHECKS.length} checks only.</b> ${cover.unchk.length} of ${E.length} entries were not touched by any check and still need a human read. <button type="button" class="linkbtn" data-act="unchk">Show them</button></p>
      <p class="hub"><span class="hubL">Read ${R.E.length} entries in ${lastMs} ms from</span>${svcList(R).map(x => `<button type="button" class="svc" data-ns="${esc(x.svc)}" title="Show the ${esc(x.svc)} notes">${esc(x.svc)} <i>${x.n}</i></button>`).join('<span class="arrow" aria-hidden="true"></span>')}</p>
      <p class="sign">${reviewed[cur.id] ? `<span class="okTag">Reviewed at ${reviewed[cur.id]}</span> Logged in the audit trail.` : `<button type="button" class="btn" id="signBtn">Mark this page as reviewed</button>`}</p>
      <p class="next"><button type="button" class="btn" data-go="journey">Next: see where each one started</button></p>`;
    $('out').hidden = false;
    // 2 summary: problems in order of importance, then medicines
    const st = { held: 'Held', stopped: 'Stopped', restarted: 'Held, then restarted', continuing: 'Continuing', given: 'Given', prescribed: 'Prescribed', mentioned: 'Mentioned' };
    const openRx = n => open.some(l => l.key === 'rx:' + n);
    const openDrug = n => open.some(l => l.key === 'drug:' + n);
    const medRow = m => `<tr><td>${esc(cap(m.name))}</td><td>${openDrug(m.name) ? '<b class="bad">Held, not restarted</b>' : openRx(m.name) ? '<b class="bad">Prescribed, no record it was given</b>' : st[m.status]}</td><td>${m.home ? 'Yes' : ''}</td><td>${m.now ? 'Yes' : ''}</td><td>${chips([m.first, m.last], E)}</td></tr>`;
    const kv = (k, x, wide) => `<div class="kv${wide ? ' wide' : ''}${x ? '' : ' miss'}"><span>${k}</span><div>${f(x)}</div></div>`;
    const nowTwo = S.now ? { text: S.now.text.split(/(?<=\.)\s/).slice(0, 2).join(' '), src: S.now.src } : null;
    const oRow = (l, k) => `<button type="button" class="openRow" data-ql="${k}"><i class="qDot" aria-hidden="true"></i><b>${esc(l.t1)}</b><span>${esc(l.t2 || '')}</span><em>${age(l.ageFrom != null ? l.ageFrom : l.start, E).startsWith('since') ? age(l.ageFrom != null ? l.ageFrom : l.start, E) : 'open ' + age(l.ageFrom != null ? l.ageFrom : l.start, E)}</em></button>`;
    $('v-summary').innerHTML = `<h2 class="cardH">Summary</h2>
      <div class="keyG">
        <div class="keyCard why"><span>Why ${cur.sex === 'F' ? 'she' : 'he'} is here</span><div>${S.admitted ? f(S.admitted) : NF}</div></div>
        <div class="keyCard ${S.allergies ? 'alg' : 'miss'}"><span>Allergies</span><div>${S.allergies ? f(S.allergies) : NF}</div></div>
        <div class="keyCard ${S.resus ? '' : 'miss'}"><span>Limits on treatment</span><div>${S.resus ? f(S.resus) : NF}</div></div>
      </div>
      <h3 class="subH act">Still open<span class="badge">${open.length}</span></h3>
      ${open.length ? `<div class="openL">${open.slice(0, 5).map(oRow).join('')}${open.length > 5 ? `<details class="openMore"><summary>Show ${open.length - 5} more</summary>${open.slice(5).map((l, k) => oRow(l, k + 5)).join('')}</details>` : ''}</div>` : '<p class="hint">None found by these checks.</p>'}
      <h3 class="subH">Latest note and readings</h3>
      <p class="sit">${f(nowTwo)}</p>
      ${R.trend ? `<div class="trendG flat">${R.trend.items.map(x => `<div class="${x.wide ? 'wide' : ''}"><span>${esc(x.k)}</span>${trendVals(x, E)}</div>`).join('')}</div>` : ''}
      ${R.obs.length > 1 ? `<details class="prob"><summary><span class="pn">All observations</span><span class="pl">${R.obs.length} sets across the journey</span></summary><table class="meds"><thead><tr><th>When</th><th>Where</th><th>Breathing rate</th><th>Oxygen</th><th>Heart rate</th><th>Temp</th><th>NEWS2</th></tr></thead><tbody>${R.obs.map(o => `<tr><td>${chips([o.i], E)}</td><td>${esc(E[o.i].svc)}</td><td>${o.rr || ''}</td><td>${esc(o.spo2 || '')}</td><td>${o.hr || ''}</td><td>${o.temp || ''}</td><td>${o.news || ''}</td></tr>`).join('')}</tbody></table></details>` : ''}
      <h3 class="subH">Background</h3>
      <div class="kvG">${[['Family last told', S.familyTold], ['Next of kin', S.nok]].filter(x => x[1]).map(x => kv(x[0], x[1])).join('')}${cur.where ? `<div class="kv"><span>Lives</span><div>${esc(cur.where)}</div></div>` : S.living ? kv('Lives', S.living) : ''}${S.adjust ? kv('What helps this person', S.adjust) : ''}</div>
      ${(() => { const miss = [['Next of kin', S.nok], ['Family last told', S.familyTold], ['Where they live', cur.where || S.living], ['What helps this person', S.adjust]].filter(x => !x[1]).map(x => x[0]); return miss.length ? `<p class="kvMiss"><i class="aDot" aria-hidden="true"></i><b>Not found in these notes:</b> ${miss.map(esc).join(', ').toLowerCase()}</p>` : ''; })()}
      <h3 class="subH">By problem</h3>
      ${(() => { const row = p => { const last = p.items[p.items.length - 1]; return `<details class="prob" data-pn="${esc(p.name)}"><summary><span class="pn">${esc(p.name)}</span>${p.loops.length ? `<span class="badge">${p.loops.length} open</span>` : ''}<span class="pl">${esc(last.text.length > 70 ? last.text.slice(0, 68) + '…' : last.text)}</span></summary>
        ${p.items.length > 6 ? `<details class="earlier"><summary>${p.items.length - 5} earlier mentions</summary><ol class="tl">${p.items.slice(0, -5).map(it => `<li>${dayLink(it.i, E)}<span>${esc(it.text)}</span></li>`).join('')}</ol></details>` : ''}<ol class="tl">${(p.items.length > 6 ? p.items.slice(-5) : p.items).map(it => `<li>${dayLink(it.i, E)}<span>${esc(it.text)}</span></li>`).join('')}</ol>${open.filter(l => p.loops.includes(l.key)).map(l => `<p class="pLoop"><button type="button" class="linkbtn" data-ql="${open.indexOf(l)}"><i class="qDot" aria-hidden="true"></i>${esc(l.title)}</button></p>`).join('')}</details>`; }; const top = problems.filter(p => p.loops.length), rest = problems.filter(p => !p.loops.length);
        return (top.length ? top : rest.slice(0, 3)).map(row).join('') + ((top.length ? rest : rest.slice(3)).length ? `<details class="prob more"><summary><span class="pn">${(top.length ? rest : rest.slice(3)).length} more mentioned</span><span class="pl">${(top.length ? rest : rest.slice(3)).map(p => esc(p.name)).join(', ')}</span></summary><div class="nest">${(top.length ? rest : rest.slice(3)).map(row).join('')}</div></details>` : ''); })()}
      <h3 class="subH">Medicines</h3>
      ${meds.now ? `${meds.missing.length ? `<p class="notice bad"><b>Home medicine not on the latest list:</b> ${meds.missing.map(cap).map(esc).join(', ')}. ${chips([meds.now.i], E)}</p>` : '<p class="notice">Every home medicine is on the latest list.</p>'}
        ${meds.added.length ? `<p class="notice"><b>New on the latest list:</b> ${meds.added.map(cap).map(esc).join(', ')}.</p>` : ''}
        <details class="prob"><summary><span class="pn">Full medicines list</span><span class="pl">${meds.all.length} medicines mentioned in the notes</span></summary>
        <table class="meds"><thead><tr><th>Medicine</th><th>In the notes</th><th>Home</th><th>Latest list</th><th>First and last mention</th></tr></thead><tbody>${meds.all.map(medRow).join('')}</tbody></table></details>`
      : `<table class="meds"><thead><tr><th>Medicine</th><th>In the notes</th><th>First and last mention</th></tr></thead><tbody>${meds.all.map(m => `<tr><td>${esc(cap(m.name))}</td><td>${openRx(m.name) ? '<b class="bad">Prescribed, no record it was given</b>' : st[m.status]}</td><td>${chips([m.first, m.last], E)}</td></tr>`).join('')}</tbody></table>`}
      <div id="aiPanel">${aiPanelHtml(R)}</div>
      <details class="noteBox"${myNote[cur.id] ? ' open' : ''}><summary>${myNote[cur.id] ? 'Clinician note' : 'Add a clinician note'}</summary>
        <p class="hint">Written by you, not taken from the notes. It is marked as added by the clinician and goes into the handover and every document.</p>
        <textarea id="myNote" rows="3" aria-label="Clinician note">${esc(myNote[cur.id] || '')}</textarea></details>
      <p class="next"><button type="button" class="btn" data-go="handover">Next: hand over to the right team</button></p>`;
    // 3 handover
    drawHandover(R);
    // 4 journey extras
    $('loopDetail').innerHTML = '<p class="hint">Select a row to see what it is and where it came from.</p>';
    $('closedList').innerHTML = `<summary><span class="pn">Closed loops</span><span class="pl">${closed.length} started and finished in the notes</span></summary>${closed.map(c => `<div class="closedRow"><span class="dot ok" aria-hidden="true"></span>${esc(c.text)} ${chips(c.src, E)}</div>`).join('') || '<div class="closedRow">None.</div>'}`;
    // 5 more
    let val;
    if (notesText === cur.notes) {
      const got = open.map(o => o.key), hit = cur.expectedOpen.filter(k => got.includes(k)).length, extra = got.filter(k => !cur.expectedOpen.includes(k)).length;
      val = `Self-check on this synthetic record: ${hit}/${cur.expectedOpen.length} expected open loops found · ${extra} false alarms · ${closed.length} closed loops left alone.`;
      if (!isLatest()) val = 'The self-check runs on the latest record. You are viewing an earlier moment.';
    } else val = 'Notes changed since the original. Everything was rebuilt from the current text.';
    if (R.bad.length) val += ` Lines not in the entry format and not read: ${R.bad.join(', ')}.`;
    $('checksBody').innerHTML = `<p>Rind runs ${CHECKS.length} checks. Each one looks for something that was started and never finished.</p>
      <ul class="ev">${CHECKS.map(c => `<li>${esc(c)}</li>`).join('')}</ul>
      <p>On this record the checks had something to look at in ${cover.checked} of ${cover.total} sentences. ${cover.unchk.length} entries were not touched by any check. <button type="button" class="linkbtn" data-act="unchk">Show them</button></p>
      <p><b>Messy notes.</b> Brand names, common abbreviations and one-letter typos in drug names are understood. Unclear wording can open a loop or add a "possible" note. It never closes one.</p>
      <p><b>No AI model.</b> Rules only, so the same notes always give the same page and it cannot invent a sentence. Every line links to the note it came from.</p>
      <p class="val">${val}</p>`;
    $('nOpen').textContent = open.filter(l => !done[dk(l)]).length;
    const tidy = t => { const m = t.match(/\b([Dd]aughter|[Ss]on|[Ww]ife|[Hh]usband|[Pp]artner) ([A-Z][a-z]+(?: [A-Z][a-z]+)?)[^0-9]{0,8}(0\d[\d ]{8,12}\d)?/); if (m) return `${m[2]}, ${m[1].toLowerCase()}${m[3] ? ' · ' + m[3] : ''}`; t = t.replace(/^escalation ceiling:\s*/i, ''); return cap(t); };
    const fact = (k, x) => x ? `<button type="button" class="fact src" data-i="${x.src[0]}" title="Open the note this came from"><span>${k}</span><b>${esc(tidy(x.text))}</b></button>` : `<div class="fact miss"><span>${k}</span><b>Not found in notes</b></div>`;
    $('facts').innerHTML = fact('Allergies', S.allergies) + fact('Escalation', S.resus) + (S.nok || !S.familyTold ? fact('Next of kin', S.nok) : fact('Family last told', S.familyTold));
    const pa = E.find(e => /pre-?alert/i.test(e.text)), pp = $('ptPre'); pp.classList.toggle('src', !!pa); if (pa) pp.dataset.i = pa.i; else delete pp.dataset.i;
  }

  /* ---------- flows ---------- */
  function drawBanner() {
    $('ptAv').textContent = cur.name.split(' ').map(w => w[0]).join('');
    $('ptName').textContent = cur.name;
    $('ptSub').textContent = `${cur.age} · ${cur.sex === 'F' ? 'Female' : 'Male'} · Born ${cur.dob} · NHS no ${cur.nhsNo} · ${cur.where}`;
    $('ptPre').hidden = !preText(); $('ptPre').textContent = preText(); drawMoments();
  }
  function drawHome() {
    const row = (p, inc) => { let open = '';
      if (inc) { const L = p.notes.split('\n'), k = L.findIndex(x => x.startsWith(p.moments[0].at + ' ')), R0 = analyse(L.slice(0, k + 1).join('\n')), said = ((L[k] || '').split('|')[2] || '').replace(/^\s*Pre-alert to ED:\s*/i, '').replace(/\s*ETA.*$/i, '').trim();
        open = `${said ? `<span>Crew reports: ${esc(said)}</span>` : ''}<span class="ptOpen"><i class="qDot" aria-hidden="true"></i>${R0.open.length} open before ${p.sex === 'F' ? 'she' : 'he'} arrives: ${esc(R0.open.slice(0, 3).map(l => (l.short || l.label || '').toLowerCase()).join(', '))}</span>`; }
      return `<button type="button" class="ptRow${inc ? ' inc' : ''}" data-p="${p.id}"><span class="avatar" aria-hidden="true">${p.name.split(' ').map(w => w[0]).join('')}</span>
      <span class="ptRowId">${inc ? `<span class="ptTop"><b>${esc(p.name)}</b><span class="pre">${esc(p.moments[0].pre)}</span></span>` : `<b>${esc(p.name)}</b>`}<span>${p.age} · ${p.sex === 'F' ? 'Female' : 'Male'} · Born ${esc(p.dob)} · NHS no ${esc(p.nhsNo)}</span>${inc ? open : `<span>${esc(p.story)}</span>`}</span>
</button>`; };
    const inc = PATIENTS.filter(p => p.moments && p.moments[0].pre), rest = PATIENTS.filter(p => !inc.includes(p));
    $('ptList').innerHTML = (inc.length ? `<h3 class="subH">On the way in by ambulance</h3>${inc.map(p => row(p, true)).join('')}` : '') + `<h3 class="subH">Recent patients</h3>${rest.map(p => row(p, false)).join('')}`;
  }
  function goHome() { $('q').placeholder = 'Find a patient by name or NHS number'; document.body.classList.add('noPatient'); setNotes(false); document.body.classList.remove('paper'); $('paperBack').hidden = true; setView('home'); }
  let pending = null;
  function askIdentity(id) {
    const p = PATIENTS.find(x => x.id === id); closeList(); $('q').value = ''; query = '';
    if (!p || busy) return;
    pending = p;
    $('idBody').innerHTML = [['Name', p.name], ['Date of birth', `${p.dob} (${p.age})`], ['NHS number', p.nhsNo], ['Address', p.where]].map(x => `<dt>${x[0]}</dt><dd>${esc(x[1])}</dd>`).join('');
    $('idSay').innerHTML = `I confirm I am accessing the record of <b>${esc(p.name)}</b>, NHS number <b>${esc(p.nhsNo)}</b>, for their direct care.`; $('idTick').checked = false; $('idOpen').disabled = true; $('idModal').hidden = false; $('idTick').focus();
  }
  function openPatient(p) {
    $('idModal').hidden = true; pending = null;
    if (!$('editor').hidden) { $('editor').hidden = true; $('notes').hidden = false; $('addForm').hidden = false; $('editBtn').textContent = 'Edit notes'; }
    cur = p; notesText = p.notes; $('addIn').value = p.demoEntry; $('addTry').innerHTML = (p.tryEntries || []).length ? '<span>Try</span>' + p.tryEntries.map((t, k) => `<button type="button" class="chip" data-try="${k}">${esc(t[0])}</button>`).join('') : ''; $('addErr').hidden = true; audience = ''; doc = 'handover'; asOf = 0; aiItems = []; aiData = null; aiState = 'idle'; jStage = null; jSel = null; nSvc = null; nUn = false; query = ''; built = false;
    document.body.classList.remove('noPatient'); $('q').placeholder = 'Find a patient or search these notes'; $('out').hidden = true;
    drawBanner(); refresh(false); setView('loops'); $('notes').scrollTop = 0;
    log(`Access confirmed for direct care and record opened: ${p.name}, NHS no ${p.nhsNo}`);
    build();
  }
  function heroText(R, show) {
    const svc = new Set(R.strip.map(x => x.svc)).size, n = R.open.length;
    const demo = (notesText.match(/\b\d{2,3}[FM]\b/) || ['patient'])[0];
    const nd = R.open.filter(l => done[dk(l)]).length;
    const left = R.open.filter(l => !done[dk(l)]);
    const short = l => { if (l.short) return l.short; const base = l.kind === 'confirm' ? l.t1.split(',')[0] : (l.label || l.t1); return (base + ({ decision: ' decision', finding: ' follow-up', referral: ' reply', pending: ' result', dup: ' given twice' }[l.kind] || '')).toLowerCase(); };
    $('heroTitle').textContent = !show ? 'What was started and never closed?' : !n ? 'No open loops found by these checks' : !left.length ? `All ${n} open loops have an entry recorded` : (arriving() ? `Before ${cur.sex === 'F' ? 'she' : 'he'} arrives: ` : 'Still open: ') + left.slice(0, 3).map(short).join(', ') + (left.length > 3 ? ` + ${left.length - 3} more` : '');
    const st0 = epStart(R.E), topL = left.find(l => !(cur.dayLabels && R.E[l.start].day === 0));
    $('heroClock').innerHTML = !show ? '' : `<b>${age(st0.i, R.E)}</b> since first seen (${esc(st0.svc)}, ${when(st0.i, R.E)})` + (topL ? ` · ${esc(short(topL))} waiting <b>${age(topL.ageFrom != null ? topL.ageFrom : topL.start, R.E)}</b>` : '');
    const nowS = R.summary.now, nowP = nowS ? nowS.text.split(/(?<=\.)\s/) : [], nowT = nowP.length > 1 && nowP[0].length < 30 ? nowP[0] + ' ' + nowP[1] : nowP[0] || '';
    if (show && nowS) $('heroSub').innerHTML = `<b>Latest:</b> ${esc(nowT)} ${chips(nowS.src, R.E)}`;
    else $('heroSub').textContent = show ? `${R.E.length} entries from ${svc} services.` : 'Rind reads the whole record across every handover and lists the loose ends.';
    $('bootCount').textContent = `${R.E.length} entries loaded · ${R.days} days · ${svc} services`;
    $('lead').classList.toggle('done', show);
  }
  function refresh(animate, newIdx) {
    const t0 = performance.now(); const R = nice(analyse(viewText())); lastMs = (performance.now() - t0).toFixed(1);
    lastR = R; renderNotes(R, newIdx); heroText(R, built); drawJourney(R, built, animate && !$('v-journey').hidden);
    if (built) { renderPage(R); R.cover.unchk.forEach(i => { const n = $('n' + i); if (n) n.classList.add('unchk'); }); }
    return R;
  }
  async function build() {
    if (busy) return; busy = true;
    const ring = document.querySelector('.ring'), arc = $('ringArc');
    try {
      if (!reduced) {
        const n = lastR.E.length; ring.classList.add('live'); arc.style.strokeDashoffset = 84;
        const steps = Math.min(n, 14);
        for (let k = 1; k <= steps; k++) { const i = Math.round(k / steps * n); arc.style.strokeDashoffset = (84 * (1 - i / n)).toFixed(1); $('heroSub').textContent = `Reading entry ${i} of ${n}`; await sleep(360 / steps); }
        await sleep(60);
      }
    } catch (e) { /* the animation is decoration; never let it block the result */ }
    ring.classList.remove('live'); arc.style.strokeDashoffset = '';
    built = true;
    try { refresh(true); } finally { busy = false; }
  }
  function toggleEdit() {
    const ed = $('editor');
    if (ed.hidden) { setNotes(true); $('ta').value = notesText; ed.hidden = false; $('notes').hidden = true; $('addForm').hidden = true; $('editBtn').textContent = 'Done editing, rebuild'; }
    else { notesText = $('ta').value.replace(/\s+$/, ''); ed.hidden = true; $('notes').hidden = false; $('addForm').hidden = false; $('editBtn').textContent = 'Edit notes'; refresh(false); }
  }
  function showLoop(i, R0) {
    const R = R0 || lastR, l = R.loops[i]; if (!l) return;
    jSel = l.key + '|' + l.start;
    document.querySelectorAll('#journey .sel').forEach(g => g.classList.remove('sel'));
    document.querySelectorAll(`#journey [data-loop="${i}"]`).forEach(g => g.classList.add('sel'));
    $('loopDetail').innerHTML = `<div class="ldHead"><span class="dot${l.status === 'closed' ? ' ok' : ''}" aria-hidden="true"></span><b>${esc(l.status === 'closed' ? 'Closed: ' + l.label : l.title)}</b>${l.problem ? `<span class="tag">${esc(l.problem)}</span>` : ''}</div>${loopBody(l, R.E)}`;
  }

  /* ---------- events ---------- */
  document.addEventListener('click', e => {
    const t = e.target;
    if (!t.closest('.search')) closeList();
    const ns = t.closest('[data-ns]'); if (ns) { nSvc = ns.dataset.ns || null; if (!nSvc) { nUn = false; query = ''; $('q').value = ''; } if (!$('editor').hidden) toggleEdit(); setNotes(true); renderNotes(lastR); return; }
    if (t.closest('[data-nu]')) { nUn = !nUn; renderNotes(lastR); return; }
    const pb = t.closest('[data-prob]'); if (pb) { e.preventDefault(); setView('summary'); const d = [...document.querySelectorAll('details.prob[data-pn]')].find(x => x.dataset.pn === pb.dataset.prob); if (d) { const up = d.parentElement.closest('details'); if (up) up.open = true; d.open = true; d.scrollIntoView({ block: 'center' }); } return; }
    const qs = t.closest('[data-qs]'); if (qs) { $('q').value = qs.dataset.qs; $('q').focus(); drawList(); return; }
    const jr = t.closest('#journey [data-loop]'); if (jr) { showLoop(+jr.dataset.loop); return; }
    const b = t.closest('.src'); if (b) { showNote(+b.dataset.i); return; }
    const g = t.closest('.loopHit'); if (g) { showLoop(+g.dataset.loop); return; }
    const nv = t.closest('.nav[data-v]'); if (nv) { setView(nv.dataset.v); return; }
    const go = t.closest('[data-go]'); if (go) { setView(go.dataset.go); return; }
    const jk = t.closest('[data-jk]'); if (jk) { jOpen = jk.dataset.jk !== 'closed'; jClosed = jk.dataset.jk !== 'open'; drawJourney(lastR, true, false); return; }
    const js = t.closest('[data-js]'); if (js) { jStage = js.dataset.js === 'all' || jStage === +js.dataset.js ? null : +js.dataset.js; drawJourney(lastR, true, false); return; }
    const tr = t.closest('[data-try]'); if (tr && cur.tryEntries) { $('addIn').value = cur.tryEntries[+tr.dataset.try][1]; $('addErr').hidden = true; $('addIn').focus(); return; }
    const ab = t.closest('[data-ai]'); if (ab) { if (ab.dataset.ai === 'clear') { aiData = null; aiState = 'idle'; aiItems = []; refresh(false); } else aiRun(ab.dataset.ai === 'test'); return; }
    const mo = t.closest('[data-mo]'); if (mo) { asOf = +mo.dataset.mo; jSel = null; aiData = null; aiState = 'idle'; aiItems = []; drawBanner(); refresh(false); log(`Viewing the record as it stood at: ${mom().label}`); return; }
    const dc = t.closest('[data-doc]'); if (dc) { doc = dc.dataset.doc; drawHandover(lastR); return; }
    if (t.id === 'docReset') { delete edits[docKey()]; log(`${DOCS.find(d => d[0] === doc)[1]} put back to Rind's draft`); drawHandover(lastR); return; }
    const au = t.closest('#aud button'); if (au) { audience = au.dataset.a; drawHandover(lastR); return; }
    const sub = t.closest('.nav.sub'); if (sub) { audience = sub.dataset.aud; drawHandover(lastR); setView('handover'); return; }
    const qp = t.closest('#qList [data-p]'); if (qp) { pickPatient(qp.dataset.p); return; }
    if (t.closest('#qList [data-notes]')) { searchNotes(); return; }
    const qn = t.closest('#qList [data-qn]'); if (qn) { query = $('q').value; closeList(); if (!$('editor').hidden) toggleEdit(); setNotes(true); renderNotes(lastR); showNote(+qn.dataset.qn); return; }
    const ql = t.closest('[data-ql]'); if (ql) { closeList(); setView('loops'); const d = $('flag' + ql.dataset.ql); if (d) { d.open = true; d.scrollIntoView({ block: 'center' }); } return; }
    if (t.id === 'changePt') { goHome(); return; }
    const row = t.closest('.ptRow'); if (row) { askIdentity(row.dataset.p); return; }
    if (t.id === 'idOpen' && pending && $('idTick').checked) { openPatient(pending); return; }
    if (t.id === 'idCancel' || t.id === 'idModal') { $('idModal').hidden = true; pending = null; return; }
    const rc = t.closest('[data-rec]'); if (rc) { const f = rc.closest('.act').querySelector('.recF'); f.hidden = false; const ta = f.querySelector('textarea'); ta.focus(); const a = ta.value.indexOf('['), b = ta.value.indexOf(']'); if (a >= 0 && b > a) ta.setSelectionRange(a, b + 1); return; }
    const tp = t.closest('[data-tpl]'); if (tp) { const f = tp.closest('.recF'), l = lastR.open[+f.dataset.k]; f.querySelector('textarea').value = TPL(l)[+tp.dataset.tpl][1]; f.querySelectorAll('[data-tpl]').forEach(b => b.setAttribute('aria-pressed', b === tp)); f.querySelector('textarea').focus(); return; }
    if (t.closest('[data-reccancel]')) { t.closest('.recF').hidden = true; return; }
    const dn = t.closest('[data-done]'); if (dn) { const l = lastR.open[+dn.dataset.done]; done[dk(l)] = nowTime(); log(`Marked as actioned: ${l.title}`); refresh(false); return; }
    const un = t.closest('[data-undo]'); if (un) { const l = lastR.open[+un.dataset.undo]; delete done[dk(l)]; log(`Undid actioned: ${l.title}`); refresh(false); return; }
    if (t.id === 'signBtn') { reviewed[cur.id] = nowTime(); log(`Page reviewed for ${cur.name}`); refresh(false); return; }
    if (!t.closest('.search')) closeList();
    if (t.id === 'closeNotes') { setNotes(false); return; }
    if (t.dataset && t.dataset.act === 'unchk') { setNotes(true); const n = document.querySelector('.note.unchk'); if (n) { const box = $('notes'); box.scrollTop = Math.max(0, n.offsetTop - box.offsetTop - 40); } return; }
    if (t.id === 'pdfBtn') {
      const name = DOCS.find(d => d[0] === doc)[1], ed = edits[docKey()], lines = $('hoText').value.split('\n');
      const body = lines.slice(1).map(x => !x.trim() ? '' : /^[A-Z][A-Z0-9 ,'-]{3,58}(\s*\(.*\))?$/.test(x.trim()) ? `<h4>${esc(x.trim())}</h4>` : /^(- |\d+\. )/.test(x) ? `<p class="li">${esc(x)}</p>` : `<p>${esc(x)}</p>`).join('');
      $('dvTitle').textContent = name + (doc === 'handover' ? ' to ' + audience : '');
      $('printDoc').innerHTML = `<div class="pdHead"><div><b class="pdBrand">Rind</b><span>${esc(name)}${doc === 'handover' ? ' to ' + esc(audience) : ''}</span></div>
        <dl><dt>Patient</dt><dd>${esc(cur.name)}</dd><dt>Born</dt><dd>${esc(cur.dob)}</dd><dt>NHS number</dt><dd>${esc(cur.nhsNo)}</dd><dt>Requested by</dt><dd>${esc(USER)}, ${nowTime()}</dd><dt>Status</dt><dd>${ed ? 'Edited by the clinician at ' + ed.t : 'Draft written by Rind from the notes, not yet edited'}</dd></dl></div>
        <div class="pdBody">${body}</div><div class="pdFoot">Synthetic patient. Student prototype, not an NHS service. Decision support: check against the notes before acting.</div>`;
      $('dvMsg').textContent = window.self !== window.top ? 'This preview is inside another page, which can block printing. Open the page on its own to print.' : '';
      $('docView').hidden = false; document.body.classList.add('docView'); $('docView').scrollTop = 0; $('dvPrint').focus();
      log(`${name} opened as a document`); return;
    }
    if (t.id === 'dvPrint') { log(`${$('dvTitle').textContent} sent to print or PDF`); try { window.print(); } catch (err) { $('dvMsg').textContent = 'Printing is blocked here. Close this and use Copy text.'; } return; }
    if (t.id === 'dvClose' || t.id === 'docView') { $('docView').hidden = true; document.body.classList.remove('docView'); return; }
    if (t.id === 'copyBtn') {
      const ta = $('hoText'), msg = $('copyMsg');
      log(`${DOCS.find(d => d[0] === doc)[1]} copied${doc === 'handover' ? ' for ' + audience : ''}`);
      const copied = () => { msg.textContent = 'Copied.'; }, manual = () => { ta.focus(); ta.select(); msg.textContent = 'Selected. Press Ctrl+C to copy.'; };
      try { navigator.clipboard.writeText(ta.value).then(copied, manual); } catch (err) { manual(); }
    }
  });
  document.addEventListener('keydown', e => {
    if ((e.key === 'Enter' || e.key === ' ') && e.target.classList && e.target.classList.contains('loopHit')) { e.preventDefault(); showLoop(+e.target.dataset.loop); }
    if (e.key === '/' && !/INPUT|TEXTAREA/.test(e.target.tagName)) { e.preventDefault(); $('q').focus(); }
    if (e.key === 'Escape') { hidePop(); if (!$('idModal').hidden) { $('idModal').hidden = true; pending = null; } if (!$('docView').hidden) { $('docView').hidden = true; document.body.classList.remove('docView'); } }
  });
  $('notesBtn').addEventListener('click', () => { const on = $('left').hidden; setNotes(on); if (on) log(`Source notes opened: ${cur.name}`); });
  /* header search: finds a patient, or searches this patient's notes */
  function closeList() { $('qList').hidden = true; $('q').setAttribute('aria-expanded', 'false'); }
  function drawList() {
    const v = $('q').value.trim(), low = v.toLowerCase(), home = document.body.classList.contains('noPatient'), W = qWords(v);
    if (home && !v) { closeList(); return; }
    const pts = PATIENTS.filter(p => !v || (p.name + ' ' + p.story + ' ' + p.age + ' ' + p.dob + ' ' + p.nhsNo + ' ' + p.nhsNo.replace(/ /g, '')).toLowerCase().includes(low));
    let h = '';
    if (!home && lastR && v.length >= 2) {
      const hit = lastR.E.filter(e => qHit(e, W)), loops = lastR.open.filter(l => W.every(w => l.title.toLowerCase().includes(w)));
      const snip = e => { const t = e.text, at = Math.max(0, t.toLowerCase().indexOf(W[0])), a = Math.max(0, at - 36); return (a ? '…' : '') + t.slice(a, a + 104) + (a + 104 < t.length ? '…' : ''); };
      h += `<div class="qH">In ${esc(cur.name)}'s record · ${hit.length} ${hit.length === 1 ? 'note' : 'notes'}${loops.length ? ` · ${loops.length} open ${loops.length === 1 ? 'loop' : 'loops'}` : ''}</div>`;
      h += loops.map(l => `<button type="button" data-ql="${lastR.open.indexOf(l)}"><b><i class="qDot" aria-hidden="true"></i>Open loop</b><span>${qMark(l.title, W)}</span></button>`).join('');
      h += hit.slice(0, 5).map(e => `<button type="button" data-qn="${e.i}"><b>${when(e.i, lastR.E)} · ${esc(e.svc)}</b><span>${qMark(snip(e), W)}</span></button>`).join('');
      if (!hit.length && !loops.length) h += '<div class="qNone">Nothing in this record matches.</div>';
      if (hit.length > 5) h += `<button type="button" data-notes="1" class="qNotes">Show all ${hit.length} in the notes</button>`;
    }
    if (!home && lastR && !v) {
      const cand = [...new Set([...lastR.meds.all.slice(0, 4).map(m => m.name), 'allergy', 'oxygen', 'family', 'escalation'])].filter(w => lastR.E.some(e => qHit(e, [w]))).slice(0, 7);
      if (cand.length) h += `<div class="qH">Search this record for</div><div class="qSug">${cand.map(w => `<button type="button" class="chip" data-qs="${esc(w)}">${esc(w)}</button>`).join('')}</div>`;
    }
    if (home || !v || pts.length) h += `<div class="qH">${v ? 'Patients' : 'Recent patients'}</div>` +
      (pts.map(p => `<button type="button" data-p="${p.id}"><b>${esc(p.name)}</b><span>${p.age} · ${p.sex} · NHS no ${esc(p.nhsNo)} · ${esc(p.story)}${!home && p === cur ? ' · open now' : ''}</span></button>`).join('') || '<div class="qNone">No patient matches. Search by name, date of birth or NHS number.</div>');
    $('qList').innerHTML = h; $('qList').hidden = false; $('q').setAttribute('aria-expanded', 'true');
  }
  function searchNotes() { query = $('q').value; closeList(); if (!$('editor').hidden) toggleEdit(); setNotes(true); renderNotes(lastR); }
  function pickPatient(id) { askIdentity(id); }
  $('q').addEventListener('focus', drawList);
  $('q').addEventListener('input', () => { drawList(); if (!$('q').value.trim() && query) { query = ''; renderNotes(lastR); } });
  $('q').addEventListener('keydown', e => {
    if (e.key === 'Enter') { e.preventDefault(); const v = $('q').value.trim(); if (!v) return; const pts = PATIENTS.filter(p => p.name.toLowerCase().includes(v.toLowerCase())); const home = document.body.classList.contains('noPatient'); if (pts.length === 1 && (home || pts[0] !== cur)) pickPatient(pts[0].id); else if (!home) searchNotes(); }
    if (e.key === 'Escape') closeList();
  });
  $('menuBtn').addEventListener('click', () => { const off = document.body.classList.toggle('noSide'); $('menuBtn').setAttribute('aria-expanded', !off); });
  $('editBtn').addEventListener('click', toggleEdit);
  $('resetBtn').addEventListener('click', () => { $('ta').value = cur.notes; });
  $('paperBtn').addEventListener('click', () => {
    const on = document.body.classList.toggle('paper'); $('paperBack').hidden = !on;
    if (on) { setNotes(false); setView('loops'); try { window.print(); } catch (e) { /* printing is blocked in some hosted frames; the on-screen copy still shows */ } }
  });
  $('paperBack').addEventListener('click', () => { document.body.classList.remove('paper'); $('paperBack').hidden = true; });
  $('addForm').addEventListener('submit', e => {
    e.preventDefault();
    const v = $('addIn').value.trim(), err = $('addErr');
    if (!LINE.test(v)) { err.textContent = 'Use the entry format: D28 09:00 | GP | what happened'; err.hidden = false; return; }
    err.hidden = true; if (cur.moments) asOf = cur.moments.length - 1; notesText = notesText + '\n' + v; drawBanner();
    log(`Entry added to the notes: ${v.slice(0, 60)}`);
    const R = refresh(true, nice(analyse(notesText)).E.length - 1);
    if ($('n' + (R.E.length - 1))) { const box = $('notes'); box.scrollTop = box.scrollHeight; }
    $('addIn').value = '';
  });
  document.addEventListener('submit', e => {
    const f = e.target.closest && e.target.closest('.recF'); if (!f) return;
    e.preventDefault();
    const l = lastR.open[+f.dataset.k], v = f.querySelector('textarea').value.trim().replace(/\s+/g, ' '), err = f.querySelector('.recErr');
    if (!v) { err.textContent = 'Write what was done first.'; return; }
    if (/[\[\]]/.test(v)) { err.textContent = 'Fill in the parts in brackets first.'; return; }
    const last = lastR.E[lastR.E.length - 1], id = dk(l), key = l.key, name = l.t1;
    notesText = notesText.trimEnd() + `\nD${last.day} ${addMin(last.time, 10)} | ED clinician | ${v.replace(/\|/g, '/')}`;
    log(`Entry added to the notes for "${name}": ${v.slice(0, 60)}`);
    const R2 = nice(analyse(notesText)), still = R2.open.some(x => x.key === key);
    if (still) done[id] = nowTime(); else { delete done[id]; flash = `${name}. ${v}`; log(`Loop closed by that entry: ${name}`); }
    refresh(false, R2.E.length - 1);
    $('v-loops').scrollIntoView({ block: 'start' });
  });
  $('addIn').addEventListener('input', () => { $('addErr').hidden = true; });
  /* offline copy: the page is one file with no network calls, so saving it is the whole install */
  const dl = $('dlBtn');
  if (location.protocol === 'file:') { dl.hidden = true; $('boot').firstElementChild.textContent = 'Running from a file on this device'; }
  else dl.addEventListener('click', async () => {
    try {
      const html = await (await fetch(location.href, { cache: 'no-store' })).text();
      const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([html], { type: 'text/html' }));
      a.download = 'rind-offline.html'; document.body.appendChild(a); a.click(); a.remove();
    } catch (e) { dl.textContent = 'Use your browser\'s Save page as'; }
  });
  $('addIn').value = cur.demoEntry;
  drawBanner(); drawHome(); drawAudit();
  refresh(false);
  if (/^(localhost|127\.0\.0\.1)$/.test(location.hostname)) fetch('/api/health').then(r => r.ok ? r.json() : null).then(j => { if (j && j.status === 'ok') { aiAvail = true; if (built) refresh(false); } }).catch(() => {});
  goHome();
})();
