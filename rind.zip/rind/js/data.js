/* Synthetic patients written for this prototype on 14 Nov 2026. No real patient data. */
(function (root) {
  const PATIENTS = [
  {
    id: 'S', name: 'Margaret Stilton', age: 82, sex: 'F', dob: '3 Feb 1944', nhsNo: '999 311 4082', where: 'Rosebank Residential Care Home',
    story: 'Care home resident, breathless and newly confused. Seven services in one day.',
    arrived: 'Arrived by ambulance 18:15',
    moments: [
      { label: 'Ambulance pre-alert, 18:12', at: 'D1 18:12', pre: 'Ambulance pre-alert 18:12 · ETA 18:15' },
      { label: 'ED, 21:05', at: 'D1 21:05' },
      { label: 'AMU admission, 21:35', at: 'D1 21:35' },
      { label: 'Latest, 15 Nov 09:15', at: null }
    ],
    dayLabels: { 0: 'before 14 Nov', 1: '14 Nov', 2: '15 Nov' },
    notes: `D0 00:00 | North Mersey respiratory clinic (RESP-22019) | Clinic letter 21 Aug: COPD/asthma overlap. Respiratory management plan, SpO2 target and escalation guidance held in North Mersey record.
D0 00:00 | GP summary (GP-SUM-44182) | Problems: COPD/asthma overlap, moderate dementia, hypertension, frailty. Allergy: penicillin, reaction details not confirmed. Regular: budesonide/formoterol inhaler, donepezil, ramipril; salbutamol inhaler PRN. Next of kin: daughter Helen Stilton, 07700 900123.
D0 20:00 | Care home MAR (RB MAR) | 13 Nov 20:00, donepezil given. Budesonide/formoterol evening dose given.
D1 08:15 | Care home carer | Usual morning. Up, dressed and ate breakfast.
D1 09:00 | GP (GP-RX-91827) | Prednisolone prescribed for current respiratory exacerbation.
D1 09:30 | Care home MAR (RB MAR) | Prednisolone given at 09:30.
D1 14:30 | Care home MAR (RB MAR) | Salbutamol inhaler given at around 14:30 for breathlessness.
D1 15:22 | Care home senior carer | More breathless this afternoon and newly confused. RR 20, SpO2 94% on room air, HR 88. Prednisolone given at 09:30. Salbutamol inhaler at around 14:30. NHS 111 contacted. Daughter informed.
D1 15:30 | NHS 111 clinician | Care home reports breathlessness and new confusion. Prednisolone given at 09:30, salbutamol inhaler at around 14:30. Penicillin allergy. Referred to Urgent Community Response.
D1 17:03 | UCR practitioner (UCR-OBS-1703) | RR 26, SpO2 91% on room air, HR 104. Alert; slower responses.
D1 17:10 | UCR practitioner (UCR-TX-1710) | Nebuliser given. Nebuliser product and dose: see originating chart. Partial response.
D1 17:28 | UCR practitioner | Ambulance requested. Daughter informed.
D1 18:05 | Paramedic (NWAS-OBS-1805) | RR 28, SpO2 92% on room air, HR 108. GCS 14/15, confused. Prednisolone given at 09:30 at the care home, salbutamol inhaler at around 14:30.
D1 18:12 | Paramedic | Pre-alert to ED: 82F, breathless with new confusion, COPD/asthma overlap, penicillin allergy. ETA 18:15.
D1 18:20 | ED triage nurse (HOSP-B-TRI-1820) | RR 28, SpO2 91% on room air, HR 112. AVPU: Alert. Handover from ambulance crew at 18:15.
D1 18:25 | ED nurse (ED MAR) | Salbutamol nebuliser given at 18:25.
D1 18:32 | ED registrar (HOSP-B-MED-1832) | Exacerbation of COPD/asthma overlap with new confusion. Had prednisolone at 09:30 at the care home. Penicillin allergy, reaction details not confirmed. Amoxicillin considered but not administered. Antibiotics deferred until chest imaging. Check respiratory management plan held at North Mersey. Chest imaging as indicated. Bloods and ECG requested.
D1 18:40 | ED nurse (ED MAR) | Prednisolone given at 18:40.
D1 18:55 | ED nurse (ED MAR) | Salbutamol nebuliser given at 18:55.
D1 19:20 | ED nurse | ECG obtained. Remains breathless at rest. RR 28, SpO2 93% on 2 L/min oxygen, HR 110. Urinary catheter inserted for fluid balance.
D1 19:40 | ED lab (HOSP-B-LAB-1940) | Bloods: potassium 2.8. ECG: sinus tachycardia. Remaining results filed in lab record.
D1 19:48 | ED doctor (HOSP-B-REV-1948) | Potassium 2.8, manage per protocol.
D1 20:05 | ED pharmacist (HOSP-B-PHARM-2005) | Medicines history: prednisolone recorded at 09:30 (care home) and at 18:40 (ED). Penicillin allergy, reaction details to be sought. Care home medicines record not attached to the transfer paperwork.
D1 20:12 | ED nurse (HOSP-B-COMM-2012) | Daughter informed by phone of the plan to admit.
D1 21:05 | ED registrar | Decision to admit to AMU.
D1 21:35 | AMU doctor (HOSP-B-AMU-2135) | Admitted with exacerbation of COPD/asthma overlap and new confusion. Correct potassium. Repeat U&E planned. Review respiratory management plan from North Mersey. Care home collateral planned. Ramipril held while acutely unwell. Referred to frailty team.
D1 22:05 | AMU nurse | Transferred from ED. Settled on the ward.
D2 08:40 | AMU pharmacist (HOSP-B-PHARM-150826) | Medicines reconciliation: prednisolone recorded twice on 14 Nov, at 09:30 and 18:40. Penicillin allergy, reaction details not confirmed.
D2 09:15 | AMU doctor (HOSP-B-MED-0915) | Ward round. Repeat U&E to follow potassium replacement. Respiratory management plan requested from North Mersey. Care home contacted for collateral. Daughter to be updated after ward round.`,
    expectedOpen: ['rx:potassium', 'dup:prednisolone', 'confirm:respiratory plan and oxygen target', 'confirm:penicillin reaction', 'confirm:nebuliser product and dose', 'confirm:care home collateral', 'pending:chest imaging', 'pending:repeat U&E', 'drug:ramipril', 'decision:antibiotic', 'referral:frailty team', 'device:urinary catheter', 'family'],
    demoEntry: 'D2 09:40 | AMU nurse | Potassium replacement given at 09:40 as charted.',
    fills: {
      'rx:potassium': { who: 'the AMU nurse' },
      'dup:prednisolone': { who: 'the AMU pharmacist', 'intended or not, and what was done': 'not intended, no further steroid today' },
      'drug:ramipril': { who: 'the AMU doctor', reason: 'acutely unwell', date: '16 Nov' },
      'decision:antibiotic': { 'which one': 'doxycycline' },
      'confirm:respiratory plan and oxygen target': { who: 'North Mersey respiratory team', 'what they said': 'target SpO2 88 to 92%' },
      'confirm:penicillin reaction': { who: 'her daughter', 'what they said': 'rash as a child, no anaphylaxis' },
      'confirm:nebuliser product and dose': { who: 'the UCR practitioner', 'what they said': 'salbutamol 5 mg' },
      'confirm:care home collateral': { who: 'the care home senior carer', 'what they said': 'usually alert and chatty' },
      'pending:chest imaging': { result: 'chest X-ray, no consolidation' },
      'pending:repeat U&E': { result: 'potassium 3.6' },
      'referral:frailty team': { advice: 'will review on AMU today' },
      'device:urinary catheter': { reason: 'fluid balance', date: '16 Nov' },
      'family': { who: 'the AMU doctor', 'what was said': 'daughter updated on the plan' }
    },
    tryEntries: [['Potassium is given', 'D2 09:40 | AMU nurse | Potassium replacement given at 09:40 as charted.'], ['A penicillin is prescribed', 'D2 09:50 | AMU doctor | Co-amoxiclav 1.2 g IV prescribed for chest infection.'], ['The catheter comes out', 'D2 10:10 | AMU nurse | Urinary catheter removed.'], ['Another service records no allergies', 'D2 10:20 | Frailty team | Reviewed on AMU. NKDA.']]
  },
    {
      id: 'C', hidden: true, name: 'Margaret Thompson', age: 82, sex: 'F', dob: '14 Mar 1943', nhsNo: '999 654 3210', where: 'Maple View Care Home',
      story: 'Care home resident, breathless, arriving by ambulance', label: 'Margaret Thompson · 82F · COPD, arriving by ambulance',
      prealert: 'Ambulance pre-alert 18:15 · arriving in 15 minutes', dayLabels: { 0: '18 Sep', 1: 'Today' },
      notes: `D0 00:00 | Hospital A respiratory clinic | Asthma–COPD overlap, FEV1 42% predicted, compensated type 2 respiratory failure on last admission. Target oxygen saturation 88–92% with controlled oxygen. Obtain early blood gas on arrival if needing more than 28% oxygen.
D0 00:00 | Hospital A respiratory clinic | Exacerbation plan: controlled oxygen, nebulised salbutamol 5 mg + ipratropium 500 mcg, prednisolone 40 mg PO. Avoid penicillins, documented rash and urticaria; check exact timing and reaction with GP or family before choosing antibiotics. Use the non-penicillin guideline such as doxycycline if infective.
D0 00:00 | Hospital A respiratory clinic | Escalation ceiling: suitable for NIV trial if hypercapnic respiratory acidosis develops; confirm current escalation wishes with daughter Jane Thompson. Moderate dementia: use short simple sentences, allow extra time, explain before touching, low-stimulation bay where possible.
D1 09:00 | GP Dr Mendes | Seen at Maple View Care Home on weekly ward round. Carer reports increased breathlessness, worsening wheeze and more sputum since yesterday evening. Eating and drinking less. Usual moderate dementia baseline, slightly quieter than usual.
D1 09:00 | GP Dr Mendes | Alert, full sentences with mild effort. Scattered bilateral expiratory wheeze, no focal crepitations. RR 22, SpO2 92% on room air, HR 92, BP 134/76, Temp 37.2. NEWS2 2.
D1 09:30 | GP Dr Mendes | Suspected acute exacerbation of COPD/asthma overlap, suitable to remain at care home with close monitoring. Respiratory care plan is with Hospital A respiratory clinic, PDF not attached to GP record. Prescribed prednisolone 40 mg OD for 5 days and salbutamol PRN. Antibiotic deferred pending sputum and clinical course, coded penicillin allergy with no detail recorded. Safety-netted with senior carer: call UCR or 999 if breathlessness worsens, SpO2 below 90% or new confusion. Daughter Jane Thompson (07700 123456) to be updated.
D1 15:30 | Care home senior carer | Much more breathless after lunch, breathing faster, short words only. More confused than her usual baseline, did not recognise evening staff, distressed by noise. Moved to quiet bedroom. UCR team called for urgent assessment.
D1 15:30 | Care home senior carer | Medication record sync is delayed. Prednisolone 40 mg prescribed at 09:30 by GP, whether the first dose was given has not been confirmed. Seven-day baseline observation chart not transmitted.
D1 17:00 | UCR advanced practitioner | Attended after care home call. Sitting upright, visibly breathless, speaking in 3 to 4 word phrases. More confused than morning baseline, calmed when things were explained slowly before examining. Widespread expiratory wheeze, reduced air entry at bases. RR 28, SpO2 90% on room air, HR 104, BP 138/82, Temp 37.6. NEWS2 7.
D1 17:10 | UCR advanced practitioner | Given ipratropium 500 mcg + salbutamol 2.5 mg nebuliser with controlled nasal oxygen 2 L/min. Care staff say target saturation is 88–92% from Hospital A, paper copy not located in room.
D1 17:35 | UCR advanced practitioner | After nebuliser SpO2 91% on 2 L/min, RR still 28. Inadequate response, needs hospital assessment, category 2 ambulance called. Daughter Jane informed by care staff. Unable to confirm whether morning prednisolone was given. Hospital A respiratory plan not directly viewable on community record.
D1 18:00 | Paramedic | Handover from UCR. Tachypnoeic, single phrases, bilateral wheeze, accessory muscle use. Anxious when cuff applied without warning, settles with calm simple explanations. RR 30, SpO2 91% on 2 L/min, HR 110, BP 142/78, Temp 37.8, BM 6.8, GCS 14.
D1 18:05 | Paramedic | Given salbutamol 5 mg nebuliser, nasal oxygen 2 L/min continued. IV access 20G left arm. Antibiotics not given because of penicillin allergy with rash and urticaria, left for ED to decide.
D1 18:15 | Paramedic | Pre-alert to ED: 82F, suspected exacerbation of asthma/COPD overlap, deteriorating despite GP and UCR treatment. Penicillin allergy. Moderate dementia, needs quiet area and simple explanations. Morning steroid dose unconfirmed. ETA 15 minutes.`,
      expectedOpen: ['rx:prednisolone', 'decision:antibiotic', 'confirm:escalation wishes', 'confirm:timing and reaction', 'doc:observation chart'],
      demoEntry: 'D1 18:40 | Care home senior carer | Phoned by ED: prednisolone 40 mg was given at 10:15, signed on the paper chart.'
    },
    {
      id: 'A', name: 'Joan Ashby', age: 84, sex: 'F', dob: '2 Jun 1942', nhsNo: '999 104 2217', where: 'Own home, lives alone', story: 'Pneumonia, intensive care, now at home', label: 'Patient A · 84F · pneumonia, ICU',
      notes: `D1 02:25 | Paramedic | 84F, daughter called 999. Confused, RR 32, sats 79% RA, 91% on 15L. Pre-alert sent. Meds bag brought in: apixaban, bisoprolol, ramipril, atorvastatin.
D1 03:10 | ED SpR | 84F BIBA from home. 3/7 cough, SOB, confusion. Sats 81% RA, RR 34, T 38.9. CXR R lower zone consolidation. Imp: severe CAP, T1RF. PMH: AF (apixaban, bisoprolol), HTN (ramipril), CKD3. NKDA. Lives alone, daughter Karen NOK.
D1 05:40 | ICU SpR | Tiring on NIV, GCS 11. Intubated 05:25 grade 2 view, size 7.0 ETT. R IJ CVC + L radial art line sited. Norad started 0.12. Urinary catheter inserted. Co-amox + clari.
D1 11:00 | ICU cons WR | Severe CAP, septic shock. Plts 68, INR 1.6. Apixaban held – plts + lines. Ramipril held – AKI risk on norad. Continue abx. Daughter updated by phone.
D2 09:30 | ICU SHO | FiO2 0.6 PEEP 10. Norad 0.18. BC x2 + sputum sent. UO 20ml/hr. Creat 168 (baseline 110).
D2 21:00 | Nurse | Turned 2-hrly, pressure areas intact. Daughter phoned, password given.
D3 02:50 | ICU SHO | K 5.9, insulin-dex given. UO <10ml/hr x4h.
D3 10:15 | ICU cons WR | AKI stage 3, creat 312. Escalate abx to tazocin D1. Fluid balance +4.2L.
D4 09:00 | ICU SHO | BCs no growth 48h. Sputum grew S pneumoniae, sens amox. FiO2 0.5. Norad 0.1.
D4 15:30 | Pharmacist | Renal dosing reviewed: tazocin 4.5g BD while eGFR <20.
D5 10:30 | ICU cons WR | Creat 388, anuric overnight. Renal referral – ?RRT. Family meeting planned.
D6 14:00 | ICU SHO | Seen by renal: no RRT for now, UO picking up after furosemide challenge, daily U&E. Norad weaning 0.05.
D6 20:10 | Nurse | Sedation hold tolerated 40 min.
D7 16:20 | ICU SpR | Temp 38.4, WCC up. CT CAP for ?collection: no collection, R basal consolidation improving. Incidental 9mm RUL nodule, radiology advise f/u CT 3/12. Tazocin continues.
D8 09:40 | ICU cons WR | Norad off. FiO2 0.35. Creat 240 improving. SBT tomorrow. Daughter visited, updated at bedside.
D9 11:05 | ICU SpR | SBT passed. Extubated 10:50 to HFNO 40L/0.4. Tazocin stopped D7/7.
D9 19:00 | Physio | Chest clear post-extubation, strong cough.
D10 09:15 | ICU SHO | HFNO 30L/0.35. Art line removed. Delirium overnight, pulling at lines. CAM-ICU +ve.
D11 10:00 | ICU cons WR | Delirium settling. Nasal O2 2L. Creat 176. Physio: sat out 20 min.
D11 15:00 | Dietitian | NG feed stopped, oral intake + supplements.
D12 04:30 | ICU SHO | Fast AF rate 130s, BP 98/60. K 3.4 replaced, Mg given. Bisoprolol 2.5 given. D/w cardiology SpR re rate control + anticoag – will review, await opinion.
D12 10:20 | ICU cons WR | Back in SR after bisoprolol. Rate 80s. Continue bisoprolol 2.5 OD. Ward-fit soon.
D13 09:30 | ICU SHO | TTE requested – new AF + ?LV function. Creat 141. Eating small amounts.
D13 14:00 | Pharmacist | Med rec: home meds apixaban 5 BD, bisoprolol 2.5, ramipril 5, atorvastatin 20. Atorvastatin continues.
D14 11:00 | ICU SHO | TWOC successful, urinary catheter removed. Mobilised to chair w/ 2.
D15 10:10 | ICU cons WR | TTE: LVEF 50%, mild MR, LA dilated. Creat 118 – ramipril restarted 2.5mg. Bed requested ward 12.
D16 09:00 | ICU SHO | Awaiting ward bed. Obs stable. Low mood, daughter aware.
D16 14:30 | OT | Home alone, stairs, will need assessment before discharge.
D17 22:40 | ICU SHO | Temp 38.1, HR 104. BC x2 sent. CXR nil new. Urine dip neg. Observe off abx.
D18 10:00 | ICU cons WR | Afebrile since. CRP 44 falling. SALT review requested – coughing with thin fluids. Fit for ward.
D19 09:20 | ICU SHO | SALT reviewed: normal diet, thin fluids OK with supervision. Mobilising w/ 2 + frame.
D19 15:45 | ICU SpR | Step-down to ward 12 today. Meds: bisoprolol 2.5 OD, ramipril 2.5 OD, lansoprazole, enoxaparin 40 SC. CVC to stay for access – poor veins. Daughter updated.
D20 09:30 | Ward FY1 | Clerked from ICU, 19/7 of notes. Plan per ICU: continue meds, physio, OT. CVC in situ R IJ.
D21 11:15 | Ward nurse | CVC removed, tip intact, site clean. Peripheral cannula L forearm.
D22 10:00 | Ward SpR WR | Medically fit. OT + physio happy. Home tomorrow with home nursing visits. TTO: bisoprolol 2.5, ramipril 2.5, lansoprazole, atorvastatin.
D23 14:20 | Ward FY1 | Discharge letter sent to GP. Dx: severe CAP, AKI resolved, new AF. Plan: GP to repeat U&E in 1/52. Home nursing accepted.
D25 10:40 | Community nurse | Home visit 1. HR 108 irregular, BP 128/74, sats 95% RA. Eating well, daughter present. Pt asks about her blood thinner – apixaban not on TTO list. Message left for GP.
D27 16:05 | Community nurse | Home visit 2. HR 112 irregular. No call back from GP yet. Mild ankle swelling.`,
      expectedOpen: ['drug:apixaban', 'finding:nodule', 'pending:blood cultures', 'referral:cardiology'],
      demoEntry: 'D28 09:00 | GP | Apixaban restarted 5mg BD after call from community nurse.'
    },
    {
      id: 'B', name: 'Derek Bannon', age: 71, sex: 'M', dob: '19 Oct 1955', nhsNo: '999 208 4471', where: 'Own home, lives alone', story: 'Hip fracture, surgery, rehab, now at home', label: 'Patient B · 71M · hip fracture, rehab',
      notes: `D1 14:10 | Paramedic | 71M fall at home, found by neighbour. R leg short + externally rotated. Pain 8/10, morphine 5mg IV. No head injury. Lives alone.
D1 15:05 | ED SHO | 71M mechanical fall. XR: displaced R intracapsular NOF fracture. PMH: T2DM (metformin), HTN (ramipril), BPH. NKDA. Systolic murmur heard. Echo requested pre-op. Fascia iliaca block done.
D1 19:30 | Ward ortho SHO | Clerked. For hemiarthroplasty tomorrow. NBM from midnight. Bloods: creat 96, HbA1c 61. Ramipril held – pre-op. VTE assessment done.
D2 08:15 | Ward ortho SHO | TTE: moderate AS, LVEF 55%. Anaesthetist aware, proceed with spinal.
D2 13:40 | Theatre | R cemented hemiarthroplasty under spinal. Urinary catheter inserted. Wound drain placed. EBL 300ml. Cefuroxime at induction.
D2 18:00 | Ward nurse | Back from theatre. Obs stable. Catheter draining clear urine. PCA morphine.
D3 09:20 | Ward ortho SpR WR | Day 1 post-op. Hb 98. Creat 162 – AKI stage 1. Metformin held – AKI. D/w renal re AKI. Drain removed, 80ml total.
D3 15:00 | Ward ortho SHO | Renal advised: IV fluids, avoid NSAIDs, repeat U&E daily. Physio: stood with frame + 2.
D4 10:00 | Ward ortho SHO | Creat 131 improving. Pain controlled. Enoxaparin 40 SC to continue 28 days post-op.
D5 03:30 | Ward nurse | Confused overnight, pulling at catheter. Temp 37.9. MSU sent. Bladder scan not done.
D5 10:30 | Ward ortho SpR WR | Post-op delirium, 4AT 6. Bloods NAD. Creat 104. Ramipril restarted 2.5mg. D/w orthogeriatrics re bone health + falls – will review.
D6 11:00 | Physio | Walking 10m with frame + 1. Stairs not yet assessed.
D7 09:45 | Ward ortho SHO | Delirium settled. Wound dry. Catheter in situ. Medically fit for rehab. BMs 11–14, on sliding scale insulin PRN.
D8 14:00 | Ward ortho SHO | Transferred to rehab unit. TTO written. Discharge summary to rehab team.
D9 10:00 | Rehab SHO | Admitted from ortho. Meds as per TTO: ramipril 2.5, paracetamol, enoxaparin 40 SC, laxatives. Catheter draining well.
D12 11:30 | Rehab physio | Stairs achieved with rail. Independent transfers.
D15 09:30 | Rehab SpR WR | Progressing well. BMs 13–17 this week. Home at the weekend with district nurses for enoxaparin.
D17 13:00 | Rehab SHO | Discharge letter sent to GP. Dx: R NOF #, hemiarthroplasty, AKI resolved, moderate AS. Home nursing accepted for daily enoxaparin until day 28.
D18 10:15 | Community nurse | Home visit 1. Enoxaparin given. Catheter still in, pt unsure why or who takes it away. BM 16.8. Says his diabetes tablets were not sent home with him.
D20 10:30 | Community nurse | Home visit 2. BM 18.2. Message left for GP re catheter + diabetes tablets.`,
      expectedOpen: ['drug:metformin', 'device:urinary catheter', 'pending:urine culture', 'referral:orthogeriatrics'],
      demoEntry: 'D21 09:00 | GP | Metformin restarted 500mg BD, creat back to baseline.'
    }
  ];
  const data = { PATIENTS };
  if (typeof module !== 'undefined') module.exports = data; else root.RindData = data;
})(typeof window !== 'undefined' ? window : globalThis);
