/* Synthetic patient written for this prototype on 14 Nov 2026. No real patient data. */
(function (root) {
  const NOTES = `D1 02:25 | Paramedic | 84F, daughter called 999. Confused, RR 32, sats 79% RA, 91% on 15L. Pre-alert sent. Meds bag brought in: apixaban, bisoprolol, ramipril, atorvastatin.
D1 03:10 | ED SpR | 84F BIBA from home. 3/7 cough, SOB, confusion. Sats 81% RA, RR 34, T 38.9. CXR R lower zone consolidation. Imp: severe CAP, T1RF. PMH: AF (apixaban, bisoprolol), HTN (ramipril), CKD3. NKDA. Lives alone, daughter Karen NOK.
D1 05:40 | ICU SpR | Tiring on NIV, GCS 11. Intubated 05:25 grade 2 view, size 7.0 ETT. R IJ CVC + L radial art line sited. Norad started 0.12. Urinary catheter inserted. Co-amox + clari.
D1 11:00 | ICU cons WR | Severe CAP, septic shock. Plts 68, INR 1.6. Apixaban held – plts + lines. Ramipril held – AKI risk on norad. Continue abx. Daughter updated by phone.
D2 09:30 | ICU SHO | FiO2 0.6 PEEP 10. Norad 0.18. BC x2 + sputum sent. UO 20ml/hr. Creat 168 (baseline 110).
D2 21:00 | Nurse | Turned 2-hrly, pressure areas intact. Daughter phoned, password given.
D3 02:50 | ICU SHO | K 5.9, insulin-dex given. UO <10ml/hr x4h.
D3 10:15 | ICU cons WR | AKI stage 3, creat 312. Escalate abx to tazocin D1. Fluid balance +4.2L.
D4 09:00 | ICU SHO | BCs no growth 48h. Sputum grew S pneumoniae, sens amox. FiO2 0.5. Norad 0.1.
D4 15:30 | Pharmacist | Renal dosing reviewed: tazocin 4.5g BD while eGFR <20.
D5 10:30 | ICU cons WR | Creat 388, anuric overnight. Renal referral – ?RRT. Family meeting planned.
D6 14:00 | ICU SHO | Seen by renal: no RRT for now, UO picking up after furosemide challenge, daily U&E. Norad weaning 0.05.
D6 20:10 | Nurse | Sedation hold tolerated 40 min.
D7 16:20 | ICU SpR | Temp 38.4, WCC up. CT CAP for ?collection: no collection, R basal consolidation improving. Incidental 9mm RUL nodule, radiology advise f/u CT 3/12. Tazocin continues.
D8 09:40 | ICU cons WR | Norad off. FiO2 0.35. Creat 240 improving. SBT tomorrow. Daughter visited, updated at bedside.
D9 11:05 | ICU SpR | SBT passed. Extubated 10:50 to HFNO 40L/0.4. Tazocin stopped D7/7.
D9 19:00 | Physio | Chest clear post-extubation, strong cough.
D10 09:15 | ICU SHO | HFNO 30L/0.35. Art line removed. Delirium overnight, pulling at lines. CAM-ICU +ve.
D11 10:00 | ICU cons WR | Delirium settling. Nasal O2 2L. Creat 176. Physio: sat out 20 min.
D11 15:00 | Dietitian | NG feed stopped, oral intake + supplements.
D12 04:30 | ICU SHO | Fast AF rate 130s, BP 98/60. K 3.4 replaced, Mg given. Bisoprolol 2.5 given. D/w cardiology SpR re rate control + anticoag – will review, await opinion.
D12 10:20 | ICU cons WR | Back in SR after bisoprolol. Rate 80s. Continue bisoprolol 2.5 OD. Ward-fit soon.
D13 09:30 | ICU SHO | TTE requested – new AF + ?LV function. Creat 141. Eating small amounts.
D13 14:00 | Pharmacist | Med rec: home meds apixaban 5 BD, bisoprolol 2.5, ramipril 5, atorvastatin 20. Atorvastatin continues.
D14 11:00 | ICU SHO | TWOC successful, urinary catheter removed. Mobilised to chair w/ 2.
D15 10:10 | ICU cons WR | TTE: LVEF 50%, mild MR, LA dilated. Creat 118 – ramipril restarted 2.5mg. Bed requested ward 12.
D16 09:00 | ICU SHO | Awaiting ward bed. Obs stable. Low mood, daughter aware.
D16 14:30 | OT | Home alone, stairs, will need assessment before discharge.
D17 22:40 | ICU SHO | Temp 38.1, HR 104. BC x2 sent. CXR nil new. Urine dip neg. Observe off abx.
D18 10:00 | ICU cons WR | Afebrile since. CRP 44 falling. SALT review requested – coughing with thin fluids. Fit for ward.
D19 09:20 | ICU SHO | SALT reviewed: normal diet, thin fluids OK with supervision. Mobilising w/ 2 + frame.
D19 15:45 | ICU SpR | Step-down to ward 12 today. Meds: bisoprolol 2.5 OD, ramipril 2.5 OD, lansoprazole, enoxaparin 40 SC. CVC to stay for access – poor veins. Daughter updated.
D20 09:30 | Ward FY1 | Clerked from ICU, 19/7 of notes. Plan per ICU: continue meds, physio, OT. CVC in situ R IJ.
D21 11:15 | Ward nurse | CVC removed, tip intact, site clean. Peripheral cannula L forearm.
D22 10:00 | Ward SpR WR | Medically fit. OT + physio happy. Home tomorrow with home nursing visits. TTO: bisoprolol 2.5, ramipril 2.5, lansoprazole, atorvastatin.
D23 14:20 | Ward FY1 | Discharge letter sent to GP. Dx: severe CAP, AKI resolved, new AF. Plan: GP to repeat U&E in 1/52. Home nursing accepted.
D25 10:40 | Community nurse | Home visit 1. HR 108 irregular, BP 128/74, sats 95% RA. Eating well, daughter present. Pt asks about her blood thinner – apixaban not on TTO list. Message left for GP.
D27 16:05 | Community nurse | Home visit 2. HR 112 irregular. No call back from GP yet. Mild ankle swelling.`;
  const data = {
    NOTES,
    EXPECTED_OPEN: ['drug:apixaban', 'finding:nodule', 'pending:blood cultures', 'referral:cardiology'],
    DEMO_ENTRY: 'D28 09:00 | GP | Apixaban restarted 5mg BD after call from community nurse.'
  };
  if (typeof module !== 'undefined') module.exports = data; else root.RindData = data;
})(typeof window !== 'undefined' ? window : globalThis);
