/* Synthetic patients written for this prototype on 14 Nov 2026. No real patient data. */
(function (root) {
  const PATIENTS = [
    {
      id: 'C', name: 'Margaret Thompson', age: 82, sex: 'F', dob: '14 Mar 1943', nhsNo: '999 654 3210', where: 'Maple View Care Home',
      story: 'Care home resident, breathless, arriving by ambulance', label: 'Margaret Thompson · 82F · COPD, arriving by ambulance',
      prealert: 'Ambulance pre-alert 18:15 · arriving in 15 minutes', dayLabels: { 0: '18 Sep', 1: 'Today' },
      notes: `D0 00:00 | Hospital A respiratory clinic | Asthma–COPD overlap, FEV1 42% predicted, compensated type 2 respiratory failure on last admission. Target oxygen saturation 88–92% with controlled oxygen. Obtain early blood gas on arrival if needing more than 28% oxygen.
D0 00:00 | Hospital A respiratory clinic | Exacerbation plan: controlled oxygen, nebulised salbutamol 5 mg + ipratropium 500 mcg, prednisolone 40 mg PO. Avoid penicillins, documented rash and urticaria; check exact timing and reaction with GP or family before choosing antibiotics. Use the non-penicillin guideline such as doxycycline if infective.
D0 00:00 | Hospital A respiratory clinic | Escalation ceiling: suitable for NIV trial if hypercapnic respiratory acidosis develops; confirm current escalation wishes with daughter Jane Thompson. Moderate dementia: use short simple sentences, allow extra time, explain before touching, low-stimulation bay where possible.
D1 09:00 | GP Dr Mendes | Seen at Maple View Care Home on weekly ward round. Carer reports increased breathlessness, worsening wheeze and more sputum since yesterday evening. Eating and drinking less. Usual moderate dementia baseline, slightly quieter than usual.
D1 09:00 | GP Dr Mendes | Alert, full sentences with mild effort. Scattered bilateral expiratory wheeze, no focal crepitations. RR 22, SpO2 92% on room air, HR 92, BP 134/76, Temp 37.2. NEWS2 2.
D1 09:30 | GP Dr Mendes | Suspected acute exacerbation of COPD/asthma overlap, suitable to remain at care home with close monitoring. Respiratory care plan is with Hospital A respiratory clinic, PDF not attached to GP record. Prescribed prednisolone 40 mg OD for 5 days and salbutamol PRN. Antibiotic deferred pending sputum and clinical course, coded penicillin allergy with no detail recorded. Safety-netted with senior carer: call UCR or 999 if breathlessness worsens, SpO2 below 90% or new confusion. Daughter Jane Thompson (07700 123456) to be updated.
D1 15:30 | Care home senior carer | Much more breathless after lunch, breathing faster, short words only. More confused than her usual baseline, did not recognise evening staff, distressed by noise. Moved to quiet bedroom. UCR team called for urgent assessment.
D1 15:30 | Care home senior carer | Medication record sync is delayed. Prednisolone 40 mg prescribed at 09:30 by GP, whether the first dose was given has not been confirmed. Seven-day baseline observation chart not transmitted.
D1 17:00 | UCR advanced practitioner | Attended after care home call. Sitting upright, visibly breathless, speaking in 3 to 4 word phrases. More confused than morning baseline, calmed when things were explained slowly before examining. Widespread expiratory wheeze, reduced air entry at bases. RR 28, SpO2 90% on room air, HR 104, BP 138/82, Temp 37.6. NEWS2 7.
D1 17:10 | UCR advanced practitioner | Given ipratropium 500 mcg + salbutamol 2.5 mg nebuliser with controlled nasal oxygen 2 L/min. Care staff say target saturation is 88–92% from Hospital A, paper copy not located in room.
D1 17:35 | UCR advanced practitioner | After nebuliser SpO2 91% on 2 L/min, RR still 28. Inadequate response, needs hospital assessment, category 2 ambulance called. Daughter Jane informed by care staff. Unable to confirm whether morning prednisolone was given. Hospital A respiratory plan not directly viewable on community record.
D1 18:00 | Paramedic | Handover from UCR. Tachypnoeic, single phrases, bilateral wheeze, accessory muscle use. Anxious when cuff applied without warning, settles with calm simple explanations. RR 30, SpO2 91% on 2 L/min, HR 110, BP 142/78, Temp 37.8, BM 6.8, GCS 14.
D1 18:05 | Paramedic | Given salbutamol 5 mg nebuliser, nasal oxygen 2 L/min continued. IV access 20G left arm. Antibiotics not given because of penicillin allergy with rash and urticaria, left for ED to decide.
D1 18:15 | Paramedic | Pre-alert to ED: 82F, suspected exacerbation of asthma/COPD overlap, deteriorating despite GP and UCR treatment. Penicillin allergy. Moderate dementia, needs quiet area and simple explanations. Morning steroid dose unconfirmed. ETA 15 minutes.`,
      expectedOpen: ['rx:prednisolone', 'decision:antibiotic', 'confirm:escalation wishes', 'confirm:timing and reaction', 'doc:observation chart'],
      demoEntry: 'D1 18:40 | Care home senior carer | Phoned by ED: prednisolone 40 mg was given at 10:15, signed on the paper chart.'
    },
    {
      id: 'A', name: 'Joan Ashby', age: 84, sex: 'F', dob: '2 Jun 1942', nhsNo: '999 104 2217', where: 'Own home, lives alone', story: 'Pneumonia, intensive care, now at home', label: 'Patient A · 84F · pneumonia, ICU',
      notes: `D1 02:25 | Paramedic | 84F, daughter called 999. Confused, RR 32, sats 79% RA, 91% on 15L. Pre-alert sent. Meds bag brought in: apixaban, bisoprolol, ramipril, atorvastatin.
D1 03:10 | ED SpR | 84F BIBA from home. 3/7 cough, SOB, confusion. Sats 81% RA, RR 34, T 38.9. CXR R lower zone consolidation. Imp: severe CAP, T1RF. PMH: AF (apixaban, bisoprolol), HTN (ramipril), CKD3. NKDA. Lives alone, daughter Karen NOK.
D1 05:40 | ICU SpR | Tiring on NIV, GCS 11. Intubated 05:25 grade 2 view, size 7.0 ETT. R IJ CVC + L radial art line sited. Norad started 0.12. Urinary catheter inserted. Co-amox + clari.
D1 11:00 | ICU cons WR | Severe CAP, septic shock. Plts 68, INR 1.6. Apixaban held – plts + lines. Ramipril held – AKI risk on norad. Continue abx. Daughter updated by phone.
D2 09:30 | ICU SHO | FiO2 0.6 PEEP 10. Norad 0.18. BC x2 + sputum sent. UO 20ml/hr. Creat 168 (baseline 110).
D2 21:00 | Nurse | Turned 2-hrly, pressure areas intact. Daughter phoned, password given.
D3 02:50 | ICU SHO | K 5.9, insulin-dex given. UO <10ml/hr x4h.
D3 10:15 | ICU cons WR | AKI stage 3, creat 312. Escalate abx to tazocin D1. Fluid balance +4.2L.
D4 09:00 | ICU SHO | BCs no growth 48h. Sputum grew S pneumoniae, sens amox. FiO2 0.5. Norad 0.1.
D4 15:30 | Pharmacist | Renal dosing reviewed: tazocin 4.5g BD while eGFR <20.
D5 10:30 | ICU cons WR | Creat 388, anuric overnight. Renal referral – ?RRT. Family meeting planned.
D6 14:00 | ICU SHO | Seen by renal: no RRT for now, UO picking up after furosemide challenge, daily U&E. Norad weaning 0.05.
D6 20:10 | Nurse | Sedation hold tolerated 40 min.
D7 16:20 | ICU SpR | Temp 38.4, WCC up. CT CAP for ?collection: no collection, R basal consolidation improving. Incidental 9mm RUL nodule, radiology advise f/u CT 3/12. Tazocin continues.
D8 09:40 | ICU cons WR | Norad off. FiO2 0.35. Creat 240 improving. SBT tomorrow. Daughter visited, updated at bedside.
D9 11:05 | ICU SpR | SBT passed. Extubated 10:50 to HFNO 40L/0.4. Tazocin stopped D7/7.
D9 19:00 | Physio | Chest clear post-extubation, strong cough.
D10 09:15 | ICU SHO | HFNO 30L/0.35. Art line removed. Delirium overnight, pulling at lines. CAM-ICU +ve.
D11 10:00 | ICU cons WR | Delirium settling. Nasal O2 2L. Creat 176. Physio: sat out 20 min.
D11 15:00 | Dietitian | NG feed stopped, oral intake + supplements.
D12 04:30 | ICU SHO | Fast AF rate 130s, BP 98/60. K 3.4 replaced, Mg given. Bisoprolol 2.5 given. D/w cardiology SpR re rate control + anticoag – will review, await opinion.
D12 10:20 | ICU cons WR | Back in SR after bisoprolol. Rate 80s. Continue bisoprolol 2.5 OD. Ward-fit soon.
D13 09:30 | ICU SHO | TTE requested – new AF + ?LV function. Creat 141. Eating small amounts.
D13 14:00 | Pharmacist | Med rec: home meds apixaban 5 BD, bisoprolol 2.5, ramipril 5, atorvastatin 20. Atorvastatin continues.
D14 11:00 | ICU SHO | TWOC successful, urinary catheter removed. Mobilised to chair w/ 2.
D15 10:10 | ICU cons WR | TTE: LVEF 50%, mild MR, LA dilated. Creat 118 – ramipril restarted 2.5mg. Bed requested ward 12.
D16 09:00 | ICU SHO | Awaiting ward bed. Obs stable. Low mood, daughter aware.
D16 14:30 | OT | Home alone, stairs, will need assessment before discharge.
D17 22:40 | ICU SHO | Temp 38.1, HR 104. BC x2 sent. CXR nil new. Urine dip neg. Observe off abx.
D18 10:00 | ICU cons WR | Afebrile since. CRP 44 falling. SALT review requested – coughing with thin fluids. Fit for ward.
D19 09:20 | ICU SHO | SALT reviewed: normal diet, thin fluids OK with supervision. Mobilising w/ 2 + frame.
D19 15:45 | ICU SpR | Step-down to ward 12 today. Meds: bisoprolol 2.5 OD, ramipril 2.5 OD, lansoprazole, enoxaparin 40 SC. CVC to stay for access – poor veins. Daughter updated.
D20 09:30 | Ward FY1 | Clerked from ICU, 19/7 of notes. Plan per ICU: continue meds, physio, OT. CVC in situ R IJ.
D21 11:15 | Ward nurse | CVC removed, tip intact, site clean. Peripheral cannula L forearm.
D22 10:00 | Ward SpR WR | Medically fit. OT + physio happy. Home tomorrow with home nursing visits. TTO: bisoprolol 2.5, ramipril 2.5, lansoprazole, atorvastatin.
D23 14:20 | Ward FY1 | Discharge letter sent to GP. Dx: severe CAP, AKI resolved, new AF. Plan: GP to repeat U&E in 1/52. Home nursing accepted.
D25 10:40 | Community nurse | Home visit 1. HR 108 irregular, BP 128/74, sats 95% RA. Eating well, daughter present. Pt asks about her blood thinner – apixaban not on TTO list. Message left for GP.
D27 16:05 | Community nurse | Home visit 2. HR 112 irregular. No call back from GP yet. Mild ankle swelling.`,
      expectedOpen: ['drug:apixaban', 'finding:nodule', 'pending:blood cultures', 'referral:cardiology'],
      demoEntry: 'D28 09:00 | GP | Apixaban restarted 5mg BD after call from community nurse.'
    },
    {
      id: 'B', name: 'Derek Bannon', age: 71, sex: 'M', dob: '19 Oct 1955', nhsNo: '999 208 4471', where: 'Own home, lives alone', story: 'Hip fracture, surgery, rehab, now at home', label: 'Patient B · 71M · hip fracture, rehab',
      notes: `D1 14:10 | Paramedic | 71M fall at home, found by neighbour. R leg short + externally rotated. Pain 8/10, morphine 5mg IV. No head injury. Lives alone.
D1 15:05 | ED SHO | 71M mechanical fall. XR: displaced R intracapsular NOF fracture. PMH: T2DM (metformin), HTN (ramipril), BPH. NKDA. Systolic murmur heard. Echo requested pre-op. Fascia iliaca block done.
D1 19:30 | Ward ortho SHO | Clerked. For hemiarthroplasty tomorrow. NBM from midnight. Bloods: creat 96, HbA1c 61. Ramipril held – pre-op. VTE assessment done.
D2 08:15 | Ward ortho SHO | TTE: moderate AS, LVEF 55%. Anaesthetist aware, proceed with spinal.
D2 13:40 | Theatre | R cemented hemiarthroplasty under spinal. Urinary catheter inserted. Wound drain placed. EBL 300ml. Cefuroxime at induction.
D2 18:00 | Ward nurse | Back from theatre. Obs stable. Catheter draining clear urine. PCA morphine.
D3 09:20 | Ward ortho SpR WR | Day 1 post-op. Hb 98. Creat 162 – AKI stage 1. Metformin held – AKI. D/w renal re AKI. Drain removed, 80ml total.
D3 15:00 | Ward ortho SHO | Renal advised: IV fluids, avoid NSAIDs, repeat U&E daily. Physio: stood with frame + 2.
D4 10:00 | Ward ortho SHO | Creat 131 improving. Pain controlled. Enoxaparin 40 SC to continue 28 days post-op.
D5 03:30 | Ward nurse | Confused overnight, pulling at catheter. Temp 37.9. MSU sent. Bladder scan not done.
D5 10:30 | Ward ortho SpR WR | Post-op delirium, 4AT 6. Bloods NAD. Creat 104. Ramipril restarted 2.5mg. D/w orthogeriatrics re bone health + falls – will review.
D6 11:00 | Physio | Walking 10m with frame + 1. Stairs not yet assessed.
D7 09:45 | Ward ortho SHO | Delirium settled. Wound dry. Catheter in situ. Medically fit for rehab. BMs 11–14, on sliding scale insulin PRN.
D8 14:00 | Ward ortho SHO | Transferred to rehab unit. TTO written. Discharge summary to rehab team.
D9 10:00 | Rehab SHO | Admitted from ortho. Meds as per TTO: ramipril 2.5, paracetamol, enoxaparin 40 SC, laxatives. Catheter draining well.
D12 11:30 | Rehab physio | Stairs achieved with rail. Independent transfers.
D15 09:30 | Rehab SpR WR | Progressing well. BMs 13–17 this week. Home at the weekend with district nurses for enoxaparin.
D17 13:00 | Rehab SHO | Discharge letter sent to GP. Dx: R NOF #, hemiarthroplasty, AKI resolved, moderate AS. Home nursing accepted for daily enoxaparin until day 28.
D18 10:15 | Community nurse | Home visit 1. Enoxaparin given. Catheter still in, pt unsure why or who takes it away. BM 16.8. Says his diabetes tablets were not sent home with him.
D20 10:30 | Community nurse | Home visit 2. BM 18.2. Message left for GP re catheter + diabetes tablets.`,
      expectedOpen: ['drug:metformin', 'device:urinary catheter', 'pending:urine culture', 'referral:orthogeriatrics'],
      demoEntry: 'D21 09:00 | GP | Metformin restarted 500mg BD, creat back to baseline.'
    }
  ];
  const data = { PATIENTS };
  if (typeof module !== 'undefined') module.exports = data; else root.RindData = data;
})(typeof window !== 'undefined' ? window : globalThis);
