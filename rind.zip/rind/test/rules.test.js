// Run: node test/rules.test.js
const assert = require('assert');
const { analyse } = require('../js/rules.js');
const { NOTES, EXPECTED_OPEN, DEMO_ENTRY } = require('../js/data.js');

const r = analyse(NOTES);
const open = r.open.map(l => l.key);
assert.strictEqual(r.E.length, 38, 'all 38 entries parse');
assert.strictEqual(r.bad.length, 0, 'no dropped lines');
assert.deepStrictEqual([...open].sort(), [...EXPECTED_OPEN].sort(), 'exactly the planted open loops, no false alarms');
assert.strictEqual(r.closed.length, 9, 'nine closed loops left alone');
assert.strictEqual(r.summary.resus, null, 'resus status is not in the notes and must not be guessed');
assert.deepStrictEqual(r.strip.map(s => s.svc), ['Ambulance', 'ED', 'ICU', 'Ward', 'Home care']);
assert.deepStrictEqual(r.open.find(l => l.key === 'drug:apixaban').path, ['ICU', 'Ward', 'Home care']);

const r2 = analyse(NOTES + '\n' + DEMO_ENTRY);
assert.ok(!r2.open.some(l => l.key === 'drug:apixaban'), 'a restart entry closes the apixaban loop');
assert.strictEqual(r2.open.length, 3);

const r3 = analyse(NOTES + '\nthis line is not in the format');
assert.deepStrictEqual(r3.bad, [39], 'a bad line is reported by number, not silently dropped');

const r4 = analyse(NOTES + '\nD28 10:00 | GP | DNACPR discussed with patient and daughter, form completed.');
assert.ok(/DNACPR/.test(r4.summary.resus.text), 'resus status appears once it is written down');

// known limit, kept as a test so nobody forgets it
const r5 = analyse(NOTES + '\nD28 09:00 | GP | Blood thinner back on.');
assert.ok(r5.open.some(l => l.key === 'drug:apixaban'), 'LIMIT: a restart that does not name the drug is not recognised');

console.log('all checks passed:', r.open.length, 'open,', r.closed.length, 'closed,', r.cover.checked + '/' + r.cover.total, 'sentences touched');
