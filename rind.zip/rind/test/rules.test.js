// Run: node test/rules.test.js
const assert = require('assert');
const { analyse } = require('../js/rules.js');
const { PATIENTS } = require('../js/data.js');
const [S, C, A, B] = PATIENTS;
const keys = r => r.open.map(l => l.key).sort();

// Patient A
const a = analyse(A.notes);
assert.strictEqual(a.E.length, 38, 'A: all 38 entries parse');
assert.strictEqual(a.bad.length, 0, 'A: no dropped lines');
assert.deepStrictEqual(keys(a), [...A.expectedOpen].sort(), 'A: exactly the planted open loops, no false alarms');
assert.strictEqual(a.closed.length, 9, 'A: nine closed loops left alone');
assert.strictEqual(a.summary.resus, null, 'A: resus status is not in the notes and must not be guessed');
assert.deepStrictEqual(a.strip.map(s => s.svc), ['Ambulance', 'ED', 'ICU', 'Ward', 'Home care']);
assert.deepStrictEqual(a.open.find(l => l.key === 'drug:apixaban').path, ['ICU', 'Ward', 'Home care']);
assert.ok(!analyse(A.notes + '\n' + A.demoEntry).open.some(l => l.key === 'drug:apixaban'), 'A: a restart entry closes the apixaban loop');

// Patient B
const b = analyse(B.notes);
assert.strictEqual(b.E.length, 20, 'B: all 20 entries parse');
assert.strictEqual(b.bad.length, 0, 'B: no dropped lines');
assert.deepStrictEqual(keys(b), [...B.expectedOpen].sort(), 'B: exactly the planted open loops, no false alarms');
assert.deepStrictEqual(b.closed.map(l => l.key).sort(), ['device:wound drain', 'drug:ramipril', 'pending:echo', 'referral:renal'], 'B: four closed loops left alone');
assert.deepStrictEqual(b.strip.map(s => s.svc), ['Ambulance', 'ED', 'Ward', 'Theatre', 'Ward', 'Rehab', 'Home care']);
assert.deepStrictEqual(b.open.find(l => l.key === 'device:urinary catheter').path, ['Theatre', 'Ward', 'Rehab', 'Home care']);
assert.ok(!analyse(B.notes + '\n' + B.demoEntry).open.some(l => l.key === 'drug:metformin'), 'B: a restart entry closes the metformin loop');
assert.ok(!analyse(B.notes + '\nD21 10:00 | Community nurse | TWOC done, catheter removed.').open.some(l => l.key === 'device:urinary catheter'), 'B: a removal entry closes the catheter loop');

// summary: problems in order of importance, and medicines reconciliation
assert.deepStrictEqual(a.meds.home.sort(), ['apixaban', 'atorvastatin', 'bisoprolol', 'ramipril'], 'A: home medicines');
assert.deepStrictEqual(a.meds.missing, ['apixaban'], 'A: home medicine missing from the latest discharge list');
assert.deepStrictEqual(a.meds.added, ['lansoprazole'], 'A: new medicine on the discharge list');
assert.deepStrictEqual(b.meds.missing, ['metformin'], 'B: home medicine missing from the latest list');
assert.ok(a.problems.slice(0, 4).every(p => p.loops.length === 1), 'A: the four problems with an open loop come first');
assert.strictEqual(a.open.find(l => l.key === 'drug:apixaban').problem, 'Blood thinning');
assert.strictEqual(a.open.find(l => l.key === 'finding:nodule').problem, 'Incidental findings');
assert.strictEqual(b.open.find(l => l.key === 'device:urinary catheter').problem, 'Lines and catheters');
assert.strictEqual(b.open.find(l => l.key === 'drug:metformin').problem, 'Diabetes');
assert.ok(a.loops.every(l => l.problem), 'A: every loop is filed under a problem');
assert.ok(b.loops.every(l => l.problem), 'B: every loop is filed under a problem');

// the person: next of kin, when family were last told, phone number never guessed
assert.ok(/Karen/.test(a.summary.nok.text), 'A: next of kin comes from the notes');
assert.strictEqual(a.summary.phone, null, 'A: no phone number in the notes, so none is shown');
assert.ok(/lives alone/i.test(a.summary.living.text) && /lives alone/i.test(b.summary.living.text), 'living situation is found');
assert.strictEqual(b.summary.nok, null, 'B: next of kin is not in the notes and is not guessed');

// Patient C: Margaret Thompson, read from the text of five source documents
const c = analyse(C.notes);
assert.strictEqual(c.bad.length, 0, 'C: no dropped lines');
assert.deepStrictEqual(keys(c), [...C.expectedOpen].sort(), 'C: exactly the expected open loops');
assert.deepStrictEqual(c.closed.map(l => l.key).sort(), ['doc:care plan', 'family', 'rx:salbutamol'], 'C: three closed loops');
assert.strictEqual(c.open[0].key, 'rx:prednisolone', 'C: the unconfirmed steroid comes first');
assert.ok(c.closed.find(l => l.key === 'doc:care plan').found, 'C: the care plan nobody could see is found in the record');
assert.deepStrictEqual(c.strip.map(s => s.svc), ['Hospital A', 'GP', 'Care home', 'UCR', 'Ambulance']);
assert.deepStrictEqual(c.obs.map(o => o.rr), ['22', '28', '28', '30'], 'C: breathing rate trend is read from the notes');
assert.ok(/07700/.test(c.summary.phone.text) && /Jane/.test(c.summary.nok.text), 'C: next of kin and phone come from the notes');
assert.ok(/informed/.test(c.summary.familyTold.text), 'C: family last told is the later entry');
assert.ok(/NIV/.test(c.summary.resus.text), 'C: escalation ceiling is found');
assert.ok(!analyse(C.notes + '\n' + C.demoEntry).open.some(l => l.key === 'rx:prednisolone'), 'C: a confirmed dose closes the steroid loop');
assert.ok(analyse(C.notes + '\nD1 18:40 | Care home senior carer | Not sure whether prednisolone was given.').open.some(l => l.key === 'rx:prednisolone'), 'C: an unsure note never closes it');
assert.ok(c.loops.every(l => l.problem), 'C: every loop is filed under a problem');

// behaviour that must hold for any notes
assert.deepStrictEqual(analyse(A.notes + '\nthis line is not in the format').bad, [39], 'a bad line is reported by number, not silently dropped');
assert.ok(/DNACPR/.test(analyse(A.notes + '\nD28 10:00 | GP | DNACPR discussed with patient and daughter, form completed.').summary.resus.text), 'resus status appears once it is written down');

// messy notes: typos, brand names and vague wording
const typoHold = analyse(A.notes.replace('Apixaban held', 'Apixiban held'));
assert.ok(typoHold.open.some(l => l.key === 'drug:apixaban'), 'a typo in the drug name still opens the loop');
assert.ok(/Apixiban held/.test(typoHold.open.find(l => l.key === 'drug:apixaban').detail), 'the quote shows the original spelling');
assert.ok(analyse(A.notes.replace('Apixaban held', 'Eliquis held')).open.some(l => l.key === 'drug:apixaban'), 'a brand name is read as the drug');
for (const vague of ['D28 09:00 | GP | Blood thinner back on.', 'D28 09:00 | GP | Apixiban restarted 5mg BD.', 'D28 09:00 | GP | Anticoag restarted.']) {
  const l = analyse(A.notes + '\n' + vague).open.find(x => x.key === 'drug:apixaban');
  assert.ok(l, 'unclear restart never closes the loop: ' + vague);
  assert.ok(l.maybe && l.maybe.i === 38, 'unclear restart is surfaced as a possible restart: ' + vague);
}
assert.strictEqual(a.open.find(l => l.key === 'drug:apixaban').maybe, null, 'no possible-restart note without evidence');
assert.ok(analyse(B.notes + '\nD21 09:00 | GP | Diabetes tablets restarted.').open.find(l => l.key === 'drug:metformin').maybe, 'B: class wording gives a possible restart, not a close');
assert.ok(!analyse(B.notes + '\nD21 10:00 | Community nurse | Foley removed.').open.some(l => l.key === 'device:urinary catheter'), 'B: foley is read as the catheter');

{
  const { analyse: an, CHECKS: CK } = require('../js/rules.js');
  assert.strictEqual(CK.length, 15, 'fifteen checks');
  const dp = an(C.notes + '\nD1 18:25 | Care home senior carer | Phoned by ED: prednisolone 40 mg was given at 09:45, signed on the paper chart.\nD1 18:40 | ED nurse | Prednisolone 40 mg given.');
  assert.ok(dp.open[0].key === 'dup:prednisolone', 'the same steroid given by two services on one day is the first open loop');
  const rs = an(C.notes + '\nD1 18:25 | Care home senior carer | Prednisolone 40 mg was given at 09:45.\nD1 18:40 | ED nurse | Handover: prednisolone given at 09:45 at the care home.');
  assert.ok(!rs.open.some(l => l.kind === 'dup'), 'a later note restating the same dose is not a second dose');
  assert.ok(!an(A.notes).loops.some(l => l.kind === 'dup') && !an(B.notes).loops.some(l => l.kind === 'dup'), 'no duplicate alarms on the other two patients');
  const rc = an(C.notes); assert.ok(rc.trend && rc.trend.lines.length === 4, 'C is getting worse on four measures');
  assert.strictEqual(an(A.notes).trend, null, 'A has no same-day trend'); assert.strictEqual(an(B.notes).trend, null, 'B has no same-day trend');
  const cf = an(C.notes + '\nD1 18:30 | Paramedic | Given co-amoxiclav 1.2 g IV for presumed chest infection.');
  assert.ok(cf.open[0].key === 'conflict:co-amoxiclav', 'penicillin given against a recorded allergy is the first open loop');
  assert.ok(!an(A.notes).open.some(l => l.kind === 'conflict'), 'no allergy conflict where the record says NKDA');
  const df = an(C.notes + '\nD1 18:30 | ED nurse | Triage: NKDA per ambulance sheet.');
  assert.ok(df.open.some(l => l.key === 'conflict:allergy record'), 'two different allergy records are flagged');
  const av = an(C.notes + '\nD1 18:30 | ED doctor | Avoid co-amoxiclav, given doxycycline instead.');
  assert.ok(!av.open.some(l => l.kind === 'conflict'), 'a note saying to avoid the drug is not a conflict');
}
{
  const rs = analyse(S.notes), got = rs.open.map(l => l.key).sort();
  assert.deepStrictEqual(got, S.expectedOpen.slice().sort(), 'S: exactly the eight expected open loops, got ' + got.join(' | '));
  assert.ok(rs.open[0].key === 'rx:potassium' && rs.open[1].key === 'dup:prednisolone', 'S: potassium first, then the steroid given twice');
  assert.ok(rs.closed.some(l => l.key === 'rx:prednisolone') && rs.closed.some(l => l.key === 'pending:blood tests') && rs.closed.some(l => l.key === 'pending:ECG'), 'S: closed loops stay closed');
  assert.ok(!rs.loops.some(l => l.key === 'dup:salbutamol') && !rs.loops.some(l => l.kind === 'conflict'), 'S: no alarm for as-needed salbutamol or the antibiotic that was not given');
  assert.strictEqual(rs.summary.resus, null, 'S: escalation status not found');
  assert.ok(rs.trend && rs.trend.lines.length === 3, 'S: breathing rate, heart rate and new oxygen');
  { const upTo = k => S.notes.split('\n').slice(0, S.notes.split('\n').findIndex(x => x.startsWith(k + ' ')) + 1).join('\n');
    const pre = analyse(upTo('D1 18:12')).open.map(l => l.key).sort();
    assert.deepStrictEqual(pre, ['confirm:nebuliser product and dose', 'confirm:penicillin reaction', 'confirm:respiratory plan and oxygen target'], 'S at pre-alert: three things open, got ' + pre.join(' | '));
    const ed = analyse(upTo('D1 21:05')).open.map(l => l.key);
    assert.ok(ed.includes('dup:prednisolone') && ed.includes('rx:potassium') && ed.includes('pending:chest imaging'), 'S by 21:05: the hospital has added the duplicate, the potassium and the imaging, got ' + ed.join(' | ')); }
  { const d = rs.open.find(l => l.key === 'dup:prednisolone'); assert.ok(d.known != null && rs.E[d.known].svc === 'ED' && rs.E[d.known].time === '18:32', 'S: ED had the first dose in its own note before giving the second'); assert.ok(d.src.length >= 5, 'S: the notes that carried the first dose forward are all sourced'); }
  assert.ok(!analyse(S.notes + '\n' + S.demoEntry).open.some(l => l.key === 'rx:potassium'), 'S: recording the potassium closes that loop only');
  assert.strictEqual(analyse(S.notes + '\n' + S.demoEntry).open.length, 12);
  assert.ok(analyse(S.notes + '\n' + S.tryEntries[1][1]).open[0].key === 'conflict:co-amoxiclav', 'S: a penicillin prescribed against the allergy goes to the top');
  assert.ok(analyse(S.notes + '\n' + S.tryEntries[3][1]).open[0].key === 'conflict:allergy record', 'S: NKDA from another service is flagged');
  assert.ok(rs.closed.some(l => l.key === 'doc:document' && l.found), 'S: the medicines record ED could not see is in the record');
}
console.log('all checks passed · C:', c.open.length, 'open,', c.closed.length, 'closed · A:', a.open.length, 'open,', a.closed.length, 'closed · B:', b.open.length, 'open,', b.closed.length, 'closed');
